package org.itstep.firebasedemo;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.google.firebase.analytics.FirebaseAnalytics;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    public static final int MINIMUM_SESSION_DURATION = 5;
    private FirebaseAnalytics mFirebaseAnalytics;
    private TextView mStatusTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);

        mFirebaseAnalytics.setMinimumSessionDuration(MINIMUM_SESSION_DURATION);

        findViewById(R.id.btn1).setOnClickListener(this);
        findViewById(R.id.btn2).setOnClickListener(this);

        mStatusTextView = findViewById(R.id.textView);
    }

    @Override
    public void onClick(View view) {
        Bundle param = new Bundle();
        param.putInt("ButtonID", view.getId());
        String btnName;
        switch (view.getId()) {
            case R.id.btn1:
                btnName = "Button1";
                setStatus("btn1 clicked");
                break;
            case R.id.btn2:
                btnName = "Button2";
                setStatus("btn2 clicked");
                break;
            default:
                btnName = "Other button";
                break;
        }
        mFirebaseAnalytics.logEvent(btnName, param);
    }

    public void setStatus(String status) {
        mStatusTextView.setText(status);
    }
}
