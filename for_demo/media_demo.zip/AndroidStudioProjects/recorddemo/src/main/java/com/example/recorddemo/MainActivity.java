package com.example.recorddemo;

import android.media.MediaRecorder;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

import java.io.FileNotFoundException;
import java.io.IOException;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Get RECORD_AUDIO permission

        // Create MediaRecorder, setup audio source, output format, audio encoder, output file
        // https://developer.android.com/reference/android/media/MediaRecorder
    }

    public void recordControl(View view) {
        switch (view.getId()) {
            case R.id.btnRecord:
                break;
            case R.id.btnStop:
                break;
            case R.id.btnPlay:
                break;
        }
    }
}
