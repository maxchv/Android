package com.example.max.lessonsdemo;

import android.media.AudioManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;

import java.io.IOException;

public class MainActivity extends AppCompatActivity {

    public static final String TAG = "MainActivity";

    private ImageButton btnPlay;
    private ImageButton btnPause;
    private ImageButton btnStop;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Log.i(TAG, "onCreate: ");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);


        btnPlay = findViewById(R.id.btnPlay);
        btnPause = findViewById(R.id.btnPause);
        btnStop = findViewById(R.id.btnStop);
//        enableControlButtons(false);
    }

    private void enableControlButtons(boolean enable) {
        Log.d(TAG, "enableControlButtons() called with: enable = [" + enable + "]");
        btnStop.setEnabled(enable);
        btnStop.setClickable(enable);
        btnPlay.setEnabled(enable);
        btnPlay.setClickable(enable);
        btnPause.setEnabled(enable);
        btnPause.setClickable(enable);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

//    private void updateSurfaceViewAspect() {
//        int videoWidth = mediaPlayer.getVideoWidth();
//        int videoHeight = mediaPlayer.getVideoHeight();
//        ViewGroup.LayoutParams layoutParams = surfaceView.getLayoutParams();
//        int width = surfaceView.getWidth();
//        float aspect = (float)width/videoWidth;
//        layoutParams.height = (int) (videoHeight * aspect);
//        surfaceView.setLayoutParams(layoutParams);
//    }


    @Override
    protected void onPause() {
        super.onPause();
        releaseMediaPlayer();
        Log.i(TAG, "onPause: ");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        releaseMediaPlayer();
        Log.i(TAG, "onDestroy: ");
    }

    private void releaseMediaPlayer() {
        Log.i(TAG, "releaseMediaPlayer: ");
    }

    public void mediaPlayerControl(View view) {
        switch (view.getId()) {
            case R.id.btnPlay:
                Log.i(TAG, "mediaPlayerControl: play");
                break;
            case R.id.btnPause:
                Log.i(TAG, "mediaPlayerControl: pause");
                break;
            case R.id.btnStop:
                Log.i(TAG, "mediaPlayerControl: stop");
                break;
        }
    }
}
