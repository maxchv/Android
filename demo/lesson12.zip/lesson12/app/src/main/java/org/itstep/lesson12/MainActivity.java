package org.itstep.lesson12;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;

import com.google.gson.Gson;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.http.GET;

public class MainActivity extends AppCompatActivity {

    public static final String TAG = "MainActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //demo01();
        //demo02();
        demo03();
    }

    public interface PostService {
        @GET("posts")
        Call<List<Post>> listPosts();
    }

    private void demo03() {
        Retrofit retrofit = new Retrofit.Builder()
                .addConverterFactory(GsonConverterFactory.create())
                .baseUrl("https://jsonplaceholder.typicode.com/")
                .build();
        PostService postService = retrofit.create(PostService.class);
        postService.listPosts().enqueue(new Callback<List<Post>>() {
            @Override
            public void onResponse(Call<List<Post>> call, Response<List<Post>> response) {
                if(response.isSuccessful()) {
                    List<Post> posts = response.body();
                    Log.i(TAG, "Posts: " + posts.size());
                    Log.i(TAG, "First post: " + posts.get(0));
                }
            }

            @Override
            public void onFailure(Call<List<Post>> call, Throwable t) {

            }
        });
    }

    public static class Post {
        private int id;
        private int userId;
        private String title;
        private String body;

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public int getUserId() {
            return userId;
        }

        public void setUserId(int userId) {
            this.userId = userId;
        }

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public String getBody() {
            return body;
        }

        public void setBody(String body) {
            this.body = body;
        }

        @Override
        public String toString() {
            return "Post{" +
                    "id=" + id +
                    ", title='" + title + '\'' +
                    '}';
        }
    }

    private void demo02() {
        okhttp3.OkHttpClient client = new okhttp3.OkHttpClient();
        okhttp3.Request request = new okhttp3.Request.Builder().url("https://jsonplaceholder.typicode.com/posts").build();

        client.newCall(request).enqueue(new okhttp3.Callback() {
            @Override
            public void onFailure(okhttp3.Call call, IOException ex) {
                Log.e(TAG, "onFailure: ", ex);
            }

            @Override
            public void onResponse(okhttp3.Call call, okhttp3.Response response) {
                try {
                    String json = response.body().string();
                    Log.i(TAG, "onResponse: " + json);
                    Gson gson = new Gson();
                    Post[] posts = gson.fromJson(json, Post[].class);
                    Log.i(TAG, "Posts: " + posts.length);
                    Log.i(TAG, "First post: " + posts[0]);
                } catch (Throwable ex) {
                    Log.e(TAG, "onResponse: ", ex);
                }
            }
        });

    }

    private void demo01() {
        new Thread(() -> {
            InputStream inputStream = null;
            StringBuilder htmlBuilder = new StringBuilder();
            try {
                URL url = new URL("https://google.com");
                URLConnection urlConnection = url.openConnection();
                inputStream = urlConnection.getInputStream();
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
                String line;
                while ((line = bufferedReader.readLine()) != null) {
                    htmlBuilder.append(line);
                }
                Log.i(TAG, "html: " + htmlBuilder.toString());
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                if (inputStream != null) {
                    try {
                        inputStream.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        }).start();
    }
}