package com.example.hw2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class FailTestActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fail_test);
        TextView textView;
        textView = findViewById(R.id.textViewScore);
        Intent intent = getIntent();
        int arr[] = intent.getIntArrayExtra("score");
        textView.setText(String.valueOf(arr[0])+" / "+String.valueOf(arr[1]));

    }
}