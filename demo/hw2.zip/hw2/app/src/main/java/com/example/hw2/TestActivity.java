package com.example.hw2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class TestActivity extends AppCompatActivity {
    TextView textView;
    Button buttonCheckTest;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test);
        textView = findViewById(R.id.textViewHello);

        buttonCheckTest = findViewById(R.id.buttonCheckTest);

        Intent intent = getIntent();
        textView.setText("Hello: "+intent.getStringExtra("name")+"\nthis test is for you");

        Resources res = getResources();
        int[] radioGroupArr = {R.id.RadioGroupQ1,R.id.RadioGroupQ2,
                R.id.RadioGroupQ3,R.id.RadioGroupQ4,
                R.id.RadioGroupQ5,R.id.RadioGroupQ6};

        int[] qsArr ={R.array.q1,R.array.q2,R.array.q3,
                R.array.q4,R.array.q5,R.array.q6};

        for (int i=0;i<radioGroupArr.length;i++){
            String[] qs = res.getStringArray(qsArr[i]);
            for (String q: qs) {
                RadioGroup radioGroup = findViewById(radioGroupArr[i]);
                RadioButton newRadioButton = new RadioButton(this);
                newRadioButton.setText(q);
                newRadioButton.setTextSize(18);
                radioGroup.addView(newRadioButton);
            }
        }
        buttonCheckTest.setOnClickListener(view -> {
            String[] answers = res.getStringArray(R.array.Test1);
            int score=0;
            for (int i =0 ; i <radioGroupArr.length;i++){

                RadioGroup radioGroup = findViewById(radioGroupArr[i]);
                RadioButton  myRadioButton  = findViewById(radioGroup.getCheckedRadioButtonId());
                int radioID = radioGroup.indexOfChild(myRadioButton);

                if(radioID == Integer.parseInt(answers[i].toString())){
                    score++;
                }
            }
            int arr[]={score,radioGroupArr.length};

            if(score >= ((radioGroupArr.length)/2) +1){
                Intent intentS = new Intent(TestActivity.this, SuccessfullyActivity.class);
                intentS.putExtra("score",arr);
                startActivity(intentS);
            }else {
                Intent intentF = new Intent(TestActivity.this, FailTestActivity.class);
                intentF.putExtra("score",arr);
                startActivity(intentF);
            }
        });


    }
}