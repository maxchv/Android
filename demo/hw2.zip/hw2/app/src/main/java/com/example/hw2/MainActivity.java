package com.example.hw2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText editTextName;
    EditText editTextAge;
    SeekBar seekBarWage;
    TextView textViewWage;
    Button buttonCheck;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editTextName = findViewById(R.id.editTextName);
        editTextAge = findViewById(R.id.editTextAge);
        seekBarWage = findViewById(R.id.seekBarWage);
        textViewWage = findViewById(R.id.textViewWage);
        buttonCheck = findViewById(R.id.buttonGoToTest);

        seekBarWage.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                textViewWage.setText(String.valueOf(i));
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        buttonCheck.setOnClickListener((view -> {
            if (editTextName.getText().length() < 2){
                Toast.makeText(this, "Check name", Toast.LENGTH_SHORT).show();
            }else  if (editTextAge.getText().length() < 1){
                Toast.makeText(this, "Check age", Toast.LENGTH_SHORT).show();
            }else {
                int age = 0;
                int wage = 0;
                try {
                    age =  Integer.parseInt(editTextAge.getText().toString());
                    wage = seekBarWage.getProgress();
                } catch(NumberFormatException nfe) {
                    Toast.makeText(this, "not parse\n"+ nfe, Toast.LENGTH_SHORT).show();
                }
                if ( age >= 21 && 40 > age && wage>800 && wage<1600){
                    Intent intent = new Intent(MainActivity.this, TestActivity.class);
                    intent.putExtra("name",editTextName.getText().toString());
                    startActivity(intent);
                }else {
                    Intent intent = new Intent(MainActivity.this, FailActivity.class);
                    startActivity(intent);
                }
            }

        }));
    }
}