package org.itstep.lesson09;

import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.content.ContentValues;
import android.database.Cursor;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.util.Log;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;

import com.karumi.dexter.Dexter;
import com.karumi.dexter.listener.PermissionGrantedResponse;
import com.karumi.dexter.listener.single.BasePermissionListener;


public class MainActivity extends AppCompatActivity {

    public final static String TAG = "MainActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        /*ContentValues values = new ContentValues();
        values.put("first_name", "Маша");
        values.put("last_name", "Ефросинина");
        values.put("birthdate", "2001-05-01");
        getContentResolver().insert(StudentContentProvider.CONTENT_URI, values);*/

        ListView studentListView = findViewById(R.id.studentListView);
        String[] projection = {"_id", "first_name", "last_name", "birthdate"};
        int[] ids = { R.id.textViewID, R.id.textViewFirstName, R.id.textViewLastName, R.id.textViewBrithDate };
        Cursor cursor = getContentResolver()
                .query(StudentContentProvider.CONTENT_URI, projection, null, null, null);
        SimpleCursorAdapter adapter = new SimpleCursorAdapter(this, R.layout.student_item,
                cursor, projection, ids, SimpleCursorAdapter.FLAG_REGISTER_CONTENT_OBSERVER);
        studentListView.setAdapter(adapter);

        Dexter.withContext(this)
                .withPermission(Manifest.permission.READ_CONTACTS)
                .withListener(new BasePermissionListener(){
                    @Override
                    public void onPermissionGranted(PermissionGrantedResponse permissionGrantedResponse) {
                        readContacts();
                    }
                })
                .check();

    }

    private void readContacts() {
        Cursor query = getContentResolver().query(ContactsContract.Contacts.CONTENT_URI,
                new String[]{ContactsContract.Contacts.DISPLAY_NAME},
                null, null, null);
        while(query.moveToNext()) {
            String displayName = query.getString(0);
            Log.i(TAG, "readContacts: Display Name: " + displayName);
        }
    }
}