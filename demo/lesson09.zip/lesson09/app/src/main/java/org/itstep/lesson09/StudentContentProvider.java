package org.itstep.lesson09;

import android.content.ContentProvider;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.content.UriMatcher;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.net.Uri;

import androidx.annotation.Nullable;

import java.net.URI;

public class StudentContentProvider extends ContentProvider {

    private final static String PROVIDER_NAME = "org.itstep.lesson09.StudentProvider";
    private final static String URL = "content://" + PROVIDER_NAME + "/students";
    public final static Uri CONTENT_URI = Uri.parse(URL);

    private final static UriMatcher uriMatcher = new UriMatcher(UriMatcher.NO_MATCH);

    private final static int STUDENTS_CODE = 1;
    private final static int STUDENT_ID_CODE = 2;

    static {
        uriMatcher.addURI(PROVIDER_NAME, "students", STUDENTS_CODE);
        uriMatcher.addURI(PROVIDER_NAME, "students/#", STUDENT_ID_CODE);
    }

    public StudentContentProvider() {
    }

    private SQLiteDatabase db;

    private static class StudentDbHelper extends SQLiteOpenHelper {

        public StudentDbHelper(@Nullable Context context) {
            super(context, "students.sqlite", null, 1);
        }

        @Override
        public void onCreate(SQLiteDatabase db) {
            db.execSQL("CREATE TABLE students (" +
                    " _id integer primary key autoincrement," +
                    " first_name text not null," +
                    " last_name text not null," +
                    " birthdate text" +
                    ")");
        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            db.execSQL("drop table if exists students");
            onCreate(db);
        }
    }

    @Override
    public boolean onCreate() {
        StudentDbHelper helper = new StudentDbHelper(getContext());
        db = helper.getWritableDatabase();
        return db != null;
    }

    @Override
    public Uri insert(Uri uri, ContentValues values) {
        long id = db.insert("students", null, values);
        if(id > 0) {
            Uri uriNeRecord = ContentUris.withAppendedId(CONTENT_URI, id);
            getContext().getContentResolver().notifyChange(uriNeRecord, null);
            return uriNeRecord;
        }
        throw new SQLException("Can't insert new record into " + uri);
    }

    @Override
    public String getType(Uri uri) {
        switch (uriMatcher.match(uri)) {
            case STUDENTS_CODE: // content://org.itstep.lesson09.StudentProvider/students
                return "vnd.android.cursor.dir/vnd.org.itstep.lesson09.students";
            case STUDENT_ID_CODE:// content://org.itstep.lesson09.StudentProvider/students/1
                return "vnd.android.cursor.item/vnd.org.itstep.lesson09.students";
            default:
                throw new IllegalArgumentException("Wrong uri: " + uri);
        }
    }

    @Override
    public Cursor query(Uri uri, String[] projection, String selection,
                        String[] selectionArgs, String sortOrder) {
        Cursor cursor = null;
        switch (uriMatcher.match(uri)) {
            case STUDENTS_CODE:
                cursor = db.query("students", projection, selection, selectionArgs,
                        null, null, sortOrder);
                break;
            case STUDENT_ID_CODE:
                String id = uri.getLastPathSegment();
                selection = (selection == null || "".equals(selection.trim()))
                            ? "_ID=" + id
                            : selection + " AND _ID=" + id;
                cursor = db.query("students", projection, selection, selectionArgs,
                        null, null, sortOrder);
                break;
            default:
                throw new IllegalArgumentException("Wrong uri: " + uri);
        }
        cursor.setNotificationUri(getContext().getContentResolver(), uri);
        return cursor;
    }

    @Override
    public int delete(Uri uri, String selection, String[] selectionArgs) {
        // Implement this to handle requests to delete one or more rows.
        throw new UnsupportedOperationException("Not yet implemented");
    }

    @Override
    public int update(Uri uri, ContentValues values, String selection,
                      String[] selectionArgs) {
        // TODO: Implement this to handle requests to update one or more rows.
        throw new UnsupportedOperationException("Not yet implemented");
    }
}
