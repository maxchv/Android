package com.itstep.activitiesdemo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class ThirdActivity extends AppCompatActivity {

    public static final String EXTRA_TEXT_KEY = "extra_text_key";

    private TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_third);

        textView = findViewById(R.id.text_view_second_data);

        Intent intent = getIntent();
        String text = intent.getStringExtra(EXTRA_TEXT_KEY);
        textView.setText(text);
    }
}