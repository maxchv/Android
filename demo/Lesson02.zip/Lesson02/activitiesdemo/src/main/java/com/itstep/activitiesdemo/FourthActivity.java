package com.itstep.activitiesdemo;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class FourthActivity extends AppCompatActivity {

    private EditText editText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fourth);
        editText = findViewById(R.id.edit_text_for_main_activity);
    }

    public void setDataAndClose(View view) {
        String text = editText.getText().toString();
        Intent intent = new Intent();
        intent.putExtra(MainActivity.EXTRA_DATA, text);
        setResult(RESULT_OK, intent);
        finish();
    }
}