package com.itstep.activitiesdemo;

import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContract;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    public static final int REQUEST_CODE = 1;
    public static final String EXTRA_DATA = "EXTRA_DATA";
    public static final String TAG = "MainActivity";

    private Button buttonStartActivity;
    private Button buttonStartActivityAndSendData;
    private Button buttonStartActivityForResult;
    private EditText editTextForSecondActivity;
    private TextView textView;

    private final ActivityResultContract<Void, String> startActivityContract =
            new ActivityResultContract<Void, String>() {
        @NonNull
        @Override
        public Intent createIntent(@NonNull Context context, Void input) {
            return new Intent(context, FourthActivity.class);
        }

        @Override
        public String parseResult(int resultCode, @Nullable Intent intent) {
            if(resultCode == Activity.RESULT_OK) {
                return intent != null ? intent.getStringExtra(MainActivity.EXTRA_DATA) : null;
            }
            return null;
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        buttonStartActivity = findViewById(R.id.button_start_activity);
        buttonStartActivity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, SecondActivity.class);
                startActivity(intent);
            }
        });
        buttonStartActivityAndSendData = findViewById(R.id.button_start_activity_send_data);
        editTextForSecondActivity = findViewById(R.id.edit_text_send_data);
        buttonStartActivityAndSendData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String text = editTextForSecondActivity.getText().toString();
                Intent intent = new Intent(MainActivity.this, ThirdActivity.class);
                intent.putExtra(ThirdActivity.EXTRA_TEXT_KEY, text);
                startActivity(intent);
            }
        });
        textView = findViewById(R.id.text_view_received_data);
        buttonStartActivityForResult = findViewById(R.id.button_start_activity_receive_data);

        final ActivityResultLauncher<Void> activityResultLauncher =
                registerForActivityResult(startActivityContract, new ActivityResultCallback<String>() {
            @Override
            public void onActivityResult(String result) {
                Log.d(TAG, "onActivityResult() called with: result = [" + result + "]");
                textView.setText(result);
            }
        });

        buttonStartActivityForResult.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Intent intent = new Intent(MainActivity.this, FourthActivity.class);
                //startActivityForResult(intent, REQUEST_CODE);
                activityResultLauncher.launch(null);
            }
        });
    }

//    @Override
//    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
//        Log.d(TAG, "onActivityResult() called with: requestCode = [" + requestCode + "], resultCode = [" + resultCode + "], data = [" + data + "]");
//        super.onActivityResult(requestCode, resultCode, data);
//        if (requestCode == REQUEST_CODE && resultCode == RESULT_OK) {
//            String text = data != null ? data.getStringExtra(EXTRA_DATA) : null;
//            textView.setText(text);
//        }
//    }
}
