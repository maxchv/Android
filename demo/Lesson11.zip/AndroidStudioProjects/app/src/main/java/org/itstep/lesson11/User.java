package org.itstep.lesson11;


import androidx.databinding.BaseObservable;
import androidx.databinding.Bindable;
import androidx.databinding.Observable;
import androidx.databinding.ObservableField;

public class User extends BaseObservable {
    private String login;
    private ObservableField<String> password;
//    private String password;

    public User() {
    }

    public User(String login, String password) {
        this.login = login;
        this.password =new ObservableField<>(password);
    }

    @Bindable
    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
        notifyPropertyChanged(BR.login);
    }

//    @Bindable
    public ObservableField<String> getPassword() {
        return password;
    }

    public void setPassword(String password) {
//        this.password = password;
//        notifyPropertyChanged(BR.password);
        this.password.set(password);
    }

    @Override
    public String toString() {
        return "User{" +
                "login='" + login + '\'' +
                ", password='" + password + '\'' +
                '}';
    }
}
