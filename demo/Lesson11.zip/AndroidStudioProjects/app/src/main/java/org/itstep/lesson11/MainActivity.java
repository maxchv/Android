package org.itstep.lesson11;

import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;

import android.os.Bundle;
import android.util.Log;
import android.view.View;

import org.itstep.lesson11.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity {

    public static final String TAG = "MainActivity";

    private User admin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_main);
        ActivityMainBinding binding = DataBindingUtil.setContentView(this, R.layout.activity_main);
        binding.setName("Hello binding World!");
        admin = new User("admin", "1234556");
        binding.setUser(admin);
    }

    public void updateUser(View view) {
        admin.setLogin("root");
        admin.setPassword("qwerty");
        Log.i(TAG, "updateUser: " + admin);
    }
}