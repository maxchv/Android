package org.itstep.lesson08.data;

import androidx.room.Database;
import androidx.room.RoomDatabase;

import org.itstep.lesson08.data.entity.Student;

@Database(entities = {Student.class}, version = 1)
public abstract class AcademyDatabase extends RoomDatabase {
    public abstract StudentDao getStudentDao();
}
