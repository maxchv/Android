package org.itstep.lesson08.data;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import org.itstep.lesson08.data.entity.Student;

import java.util.List;

@Dao
public interface StudentDao {
    @Query("SELECT * FROM Student")
    List<Student> findAll();
    @Query("SELECT * FROM Student WHERE first_name like :firstName")
    List<Student> findByFirstName(String firstName);
    @Query("SELECT * FROM Student where id=:id")
    Student getById(Long id);
    @Insert
    void save(Student ...students);
    @Delete
    void delete(Student ...students);
    @Update
    void update(Student ...students);
}
