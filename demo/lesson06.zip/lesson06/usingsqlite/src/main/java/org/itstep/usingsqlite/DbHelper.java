package org.itstep.usingsqlite;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.provider.BaseColumns;
import android.util.Log;

import androidx.annotation.Nullable;

public class DbHelper extends SQLiteOpenHelper {
    public static final String TAG = "DbHelper";

    public static final int VERSION = 1;
    public static final String DB_NAME = "db";
    public static final String TABLE_NAME = "data";

    public interface Fields extends BaseColumns {
        String VALUE    = "value";
        String CREATED  = "created";
        String MODIFIED = "modified";
    }

    private static final String CREATE_TABLE = "CREATE TABLE " + TABLE_NAME
            + "("
            + Fields._ID      + " integer primary key autoincrement,"
            + Fields.VALUE    + " text not null,"
            + Fields.CREATED  + " text not null,"
            + Fields.MODIFIED + " text not null"
            + ")";

    public DbHelper(@Nullable Context context) {
        super(context, DB_NAME, null, VERSION);
        Log.d(TAG, "DbHelper() called with: context = [" + context + "]");
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        Log.d(TAG, "onCreate() called with: db = [" + db + "]");
        db.execSQL(CREATE_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        Log.d(TAG, "onUpgrade() called with: db = [" + db + "], oldVersion = [" + oldVersion + "], newVersion = [" + newVersion + "]");
    }

    @Override
    public void onDowngrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        super.onDowngrade(db, oldVersion, newVersion);
        Log.d(TAG, "onDowngrade() called with: db = [" + db + "], oldVersion = [" + oldVersion + "], newVersion = [" + newVersion + "]");
    }
}
