package org.itstep.usingsqlite;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;

import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.Date;

import static org.itstep.usingsqlite.DbHelper.Fields;

public class MainActivity extends AppCompatActivity {

    public static final String TAG = "MainActivity";

    private DbHelper dbHelper;
    private final String DATE_FORMAT = "yyyy-mm-dd HH:MM:ss";

    private EditText editText;
    private ListView listView;
    private SimpleDateFormat dateFormat;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dbHelper = new DbHelper(this);
        dateFormat = new SimpleDateFormat(DATE_FORMAT);

        editText = findViewById(R.id.editText1);
        listView = findViewById(R.id.listView1);
        loadData();
    }

    private void loadData() {
        Cursor cursor = getCursor();
            /*while (cursor.moveToNext()) {
                int id = cursor.getInt(cursor.getColumnIndex(Fields._ID));
                String value = cursor.getString(cursor.getColumnIndex(Fields.VALUE));
                Date created = dateFormat.parse(cursor.getString(cursor.getColumnIndex(Fields.CREATED)));
                Date modified = dateFormat.parse(cursor.getString(cursor.getColumnIndex(Fields.MODIFIED)));
                Log.i(TAG, "loadData: id " + id + " value: " + value + " created: " + created + " modified: " + modified);
            }*/
        SimpleCursorAdapter adapter = new SimpleCursorAdapter(this,
                android.R.layout.simple_list_item_1,
                cursor,
                new String[]{Fields.VALUE},
                new int[]{android.R.id.text1},
                SimpleCursorAdapter.FLAG_REGISTER_CONTENT_OBSERVER);
        listView.setAdapter(adapter);
        //}
    }

    private Cursor getCursor() {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        String[] columns = {
                Fields._ID,
                Fields.VALUE,
        };
        return db.query(DbHelper.TABLE_NAME, columns, null,
                null, null, null, null);
    }

    private void addValue(String value) {
        try (SQLiteDatabase db = dbHelper.getWritableDatabase()) {
            /*db.execSQL("INSERT INTO " + DbHelper.TABLE_NAME
                    + " ("
                    +   DbHelper.Fields.VALUE + ","
                    +   DbHelper.Fields.CREATED + ","
                    +   DbHelper.Fields.MODIFIED + ""
                    +") VALUES (?, ?, ?)", new Object[]{
                            value,
                            dateFormat.format(new Date()),
                            dateFormat.format(new Date())
            } );*/
            ContentValues contentValues = new ContentValues();
            contentValues.put(Fields.VALUE, value);
            contentValues.put(Fields.CREATED, dateFormat.format(new Date()));
            contentValues.put(Fields.MODIFIED, dateFormat.format(new Date()));
            db.insert(DbHelper.TABLE_NAME, null, contentValues);
        }
    }

    public void addValue(View view) {
        addValue(editText.getText().toString());
        editText.setText("");
        SimpleCursorAdapter adapter = (SimpleCursorAdapter) listView.getAdapter();
        adapter.swapCursor(getCursor());
        adapter.notifyDataSetChanged();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        dbHelper.close();
    }


}
