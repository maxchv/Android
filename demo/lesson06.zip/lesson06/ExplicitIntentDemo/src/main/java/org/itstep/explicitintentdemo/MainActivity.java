package org.itstep.explicitintentdemo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    public static final String TAG = "MainActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


    }

    public void openActivity(View view) {
        Log.d(TAG, "openActivity() called with: view = [" + view + "]");

        //Intent intent = new Intent(this, SimpleTextViewActivity.class);
        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.putExtra(Intent.EXTRA_TEXT, "Hello World");
        intent.setType("text/plain");
        Intent chooser = Intent.createChooser(intent, "Choose application");
        if(chooser != null) {
            startActivity(chooser);
        }
    }
}
