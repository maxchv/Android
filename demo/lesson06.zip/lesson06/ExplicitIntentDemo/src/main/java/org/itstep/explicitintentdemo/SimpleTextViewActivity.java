package org.itstep.explicitintentdemo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import org.w3c.dom.Text;

public class SimpleTextViewActivity extends AppCompatActivity {

    TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_simple_text_view);

        textView = findViewById(R.id.textView2);

        Intent intent = getIntent();
        if (intent != null) {
            String stringExtra = intent.getStringExtra(Intent.EXTRA_TEXT);
            textView.setText(stringExtra);
        }
    }
}