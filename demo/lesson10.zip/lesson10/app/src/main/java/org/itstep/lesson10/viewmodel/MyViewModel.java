package org.itstep.lesson10.viewmodel;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class MyViewModel extends ViewModel {
    private MutableLiveData<Integer> count;

    public MyViewModel() {
        count = new MutableLiveData<>(0);
    }

    public LiveData<Integer> getCount() {
        return count;
    }

    public void incrementCount() {
        count.setValue(count.getValue() + 1);
    }
}
