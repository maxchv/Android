package org.itstep.lesson10;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleObserver;
import androidx.lifecycle.OnLifecycleEvent;
import androidx.lifecycle.ViewModelProvider;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import org.itstep.lesson10.viewmodel.MyViewModel;

public class MainActivity extends AppCompatActivity {

    private MyViewModel viewModel;
    private TextView textViewCount;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getLifecycle().addObserver(new MyObserver());
        textViewCount = findViewById(R.id.textViewCount);
        viewModel = new ViewModelProvider(this).get(MyViewModel.class);

        viewModel.getCount().observe(this, count -> {
            textViewCount.setText(String.valueOf(viewModel.getCount().getValue()));
        });
    }

    public void countUpHandler(View view) {
        viewModel.incrementCount();
    }
}

class MyObserver implements LifecycleObserver {

    public static final String TAG = "MyObserver";

    @OnLifecycleEvent(Lifecycle.Event.ON_START)
    public void onStart() {
        Log.i(TAG, "onStart: ");
    }
}


