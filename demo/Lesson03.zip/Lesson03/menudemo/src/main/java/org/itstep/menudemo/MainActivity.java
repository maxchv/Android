package org.itstep.menudemo;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {
    public static final String TAG = MainActivity.class.getSimpleName();

    private View view;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Log.d(TAG, "onCreate() called with: savedInstanceState = [" + savedInstanceState + "]");
        super.onCreate(savedInstanceState);
        View linearLayout = getLayoutInflater().inflate(R.layout.activity_main, null, false);
        setContentView(linearLayout);
        //setContentView(R.layout.activity_main);
        TextView textView = findViewById(R.id.textView);
        registerForContextMenu(textView); // регистрируем TextView для контекстного меню

        populateData(findViewById(R.id.linearLayout));
    }

    private void populateData(View view) {
        if(view instanceof ViewGroup) {
            for(int i=0; i<15; i++) {
                TextView item = (TextView) getLayoutInflater()
                        .inflate(R.layout.item, (ViewGroup) view, false);
                item.setText("Hello Android " + i);
                registerForContextMenu(item);
                ((ViewGroup) view).addView(item);
            }
//            LinearLayout viewGroup = (LinearLayout) view;
//            TextView textView = new TextView(this);
//            textView.setText("New item");
//            textView.setTextSize(18f);
//            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT,
//                    LinearLayout.LayoutParams.MATCH_PARENT);
//            layoutParams.setMargins(12, 12, 12, 12);
//            viewGroup.addView(textView, layoutParams);
        }
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        view = v;
        getMenuInflater().inflate(R.menu.congext_menu, menu);
    }

    @Override
    public boolean onContextItemSelected(@NonNull MenuItem item) {
        if (view == null) {
            return false;
        }
        switch (item.getItemId()) {
            case R.id.menu_item_change_foreground:
                if (view instanceof TextView) {
                    ((TextView) view).setTextColor(Color.rgb(255, 255, 0));
                }
                break;
            case R.id.menu_item_change_background:
                if (view instanceof TextView) {
                    ((TextView) view).setBackgroundColor(Color.rgb(0, 0, 255));
                }
                break;
            default:
                break;
        }
        view = null;
        return super.onContextItemSelected(item);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        Log.d(TAG, "onCreateOptionsMenu() called with: menu = [" + menu + "]");
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        Toast.makeText(this, "Selected " + item.getTitle(), Toast.LENGTH_SHORT).show();
        switch (item.getItemId()) {
            case R.id.menu_item_1:
                break;
        }
        item.setChecked(!item.isChecked());
        return super.onOptionsItemSelected(item);
    }
}
