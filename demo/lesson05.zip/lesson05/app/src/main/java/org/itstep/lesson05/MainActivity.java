package org.itstep.lesson05;

import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.snackbar.Snackbar;
import com.karumi.dexter.Dexter;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.PermissionDeniedResponse;
import com.karumi.dexter.listener.PermissionGrantedResponse;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.single.BasePermissionListener;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.io.Reader;

public class MainActivity extends AppCompatActivity {

    public final static String TAG = "MainActivity";

    private ActivityResultLauncher<String> requestPermissionLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), isGranted -> {
                if (isGranted) {
                    showExternalPublicDirectory();
                } else {
                    Toast.makeText(this, "It need permission to get access external storage",
                            Toast.LENGTH_SHORT).show();
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        TextView textView = findViewById(R.id.textView);

        // internalStorageDemo();
//        try {
//            // Open internal file for read
//            InputStream in = openFileInput("file.txt");
//            // Opent internal file for write
//            OutputStream out = openFileOutput("file2.txt", MODE_PRIVATE);
//            String[] listFilesAndDirs = fileList();
//            deleteFile("file.txt");
//        } catch (FileNotFoundException e) {
//            e.printStackTrace();
//        }

        // externalStorageDemo();

        // Public Folders
//        if(checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
//            showExternalPublicDirectory();
//        } else if(shouldShowRequestPermissionRationale(Manifest.permission.READ_EXTERNAL_STORAGE)) {
//            //Toast.makeText(this, "Pleas give me permission", Toast.LENGTH_SHORT).show();
//            Snackbar.make(textView, "Pleas give me permission", Snackbar.LENGTH_INDEFINITE)
//                    .setAction("OK", view -> {
//                        requestPermissionLauncher.launch(Manifest.permission.READ_EXTERNAL_STORAGE);
//                    })
//                    .show();
//        } else {
//            Log.e(TAG, "onCreate: Permission not granted");
//            requestPermissionLauncher.launch(Manifest.permission.READ_EXTERNAL_STORAGE);
//        }
        Dexter.withContext(this)
                .withPermission(Manifest.permission.READ_EXTERNAL_STORAGE)
                .withListener(new BasePermissionListener() {
                    @Override
                    public void onPermissionGranted(PermissionGrantedResponse permissionGrantedResponse) {
                        showExternalPublicDirectory();
                    }

                    @Override
                    public void onPermissionDenied(PermissionDeniedResponse permissionDeniedResponse) {
                        Toast.makeText(MainActivity.this, "It need permission to get access external storage",
                                Toast.LENGTH_SHORT).show();
                    }

                    @Override
                    public void onPermissionRationaleShouldBeShown(PermissionRequest permissionRequest, PermissionToken permissionToken) {
                        Snackbar.make(textView, "Pleas give me permission", Snackbar.LENGTH_INDEFINITE)
                                .setAction("OK", view -> {
                                    requestPermissionLauncher.launch(Manifest.permission.READ_EXTERNAL_STORAGE);
                                })
                                .show();
                    }
                }).check();
    }

    private void showExternalPublicDirectory() {
        if (isExtenalStorageMounted()) {
            File externalStoragePublicDirectory = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
            Log.i(TAG, "onCreate: external public storage dir " + externalStoragePublicDirectory.getAbsolutePath());
            for (File file : externalStoragePublicDirectory.listFiles()) {
                Log.i(TAG, "onCreate: file: " + file.getAbsolutePath());
            }
        }
    }

    private void externalStorageDemo() {
        if (isExtenalStorageMounted()) {
            File externalFilesDir = getExternalFilesDir(null);
            Log.i(TAG, "onCreate: External storage path: " + externalFilesDir.getAbsolutePath());
            File externalDownloadDir = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
            Log.i(TAG, "onCreate: External download path: " + externalDownloadDir.getAbsolutePath());
        } else {
            Log.e(TAG, "onCreate: External storage unmounted");
        }
    }

    private boolean isExtenalStorageMounted() {
        return Environment.MEDIA_MOUNTED.equals(Environment.getExternalStorageState());
    }

    private void internalStorageDemo() {
        File filesDir = getFilesDir();
        File file = new File(getFilesDir(), "file.txt");
        try (OutputStream out = new FileOutputStream(file.getAbsolutePath());
             PrintStream print = new PrintStream(out)) {
            print.println("Hello World!");
        } catch (IOException e) {
            e.printStackTrace();
            Log.e(TAG, "onCreate: " + e.getMessage(), e);
        }
        try (Reader reader = new FileReader(file.getAbsolutePath());
             BufferedReader bufferedReader = new BufferedReader(reader)) {
            String line;
            while ((line = bufferedReader.readLine()) != null) {
                Log.i(TAG, "Read line: " + line);
            }
        } catch (IOException e) {
            e.printStackTrace();
            Log.e(TAG, "onCreate: " + e.getMessage(), e);
        }
        Log.i(TAG, "onCreate: filesDir: " + filesDir.getAbsolutePath());
        for (File item : filesDir.listFiles()) {
            Log.i(TAG, "item " + item.getName() + " is file? " + item.isFile()
                    + " is dir? " + item.isDirectory());
        }
    }
}