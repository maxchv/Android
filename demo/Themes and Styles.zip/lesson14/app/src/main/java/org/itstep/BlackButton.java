package org.itstep;


import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.AppCompatButton;

public class BlackButton extends AppCompatButton {

    public static final String TAG = "BlackButton";

    public BlackButton(@NonNull Context context) {
        super(context);
        defaultAttrs();
    }

    private void defaultAttrs() {
        setBackgroundColor(Color.BLACK);
        setText("Black button");
        setTextColor(Color.WHITE);
    }

    public BlackButton(@NonNull Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        defaultAttrs();
    }

    public BlackButton(@NonNull Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        defaultAttrs();
    }

}
