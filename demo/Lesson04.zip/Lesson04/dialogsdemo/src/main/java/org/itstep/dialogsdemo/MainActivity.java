package org.itstep.dialogsdemo;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btn = findViewById(R.id.button);
        final View dialog = getLayoutInflater().inflate(R.layout.dialog, null, false);
        Button dlgButton = dialog.findViewById(R.id.button2);
        dlgButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this, "Clicked", Toast.LENGTH_SHORT).show();
            }
        });
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog alertDialog = new AlertDialog
                        .Builder(MainActivity.this)
                        /*.setTitle("Hello World")
                        .setMessage("Some useful message")
                        .setPositiveButton("OK", null)
                        .setNegativeButton("Reject", null)
                        .setNeutralButton("Cancel", null)*/
                        .setView(dialog)
                        .create();
                alertDialog.show();
            }
        });
    }
}
