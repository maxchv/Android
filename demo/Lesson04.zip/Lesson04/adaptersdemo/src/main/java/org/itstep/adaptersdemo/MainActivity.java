package org.itstep.adaptersdemo;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class MainActivity extends AppCompatActivity {

    public final static String TAG = "MainActivity";

    private static class Student {
        String firstName;
        String lastName;
        int photoId;

        @Override
        public String toString() {
            return "Student{" +
                    "firstName='" + firstName + '\'' +
                    ", lastName='" + lastName + '\'' +
                    ", photoId=" + photoId +
                    '}';
        }

        Student(String firstName, String lastName, int photoId) {
            this.firstName = firstName;
            this.lastName = lastName;
            this.photoId = photoId;


        }
    }

    private List<Student> students = new ArrayList<>();

    private String[] countries = {
        "Germany", "France", "Great Britain"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Spinner spinner = findViewById(R.id.spinner2);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this,
                R.layout.spinner_item, //android.R.layout.simple_list_item_1,
                countries
        );
        spinner.setAdapter(adapter);

        students.add(new Student("Вася",
                "Пупкин",
                R.drawable.barak));
        students.add(new Student("Рома",
                "Васильев", R.drawable.john));
        List<Map<String, ?>> map = students.stream()
                .map(s -> {
                    Map<String, Object> m = new HashMap<>();
                    m.put("firstName", s.firstName);
                    m.put("lastName", s.lastName);
                    m.put("photoId", s.photoId);
                    return m;
                }).collect(Collectors.toList());
        SimpleAdapter adapter2 = new SimpleAdapter(this,
                map,
                R.layout.spinner_item2,
                new String[]{"firstName", "lastName", "photoId"},
                new int[]{R.id.textViewFirstName,
                          R.id.textViewLastName,
                          R.id.imageViewPhoto});
        adapter2.setDropDownViewResource(R.layout.spinner_item2_drop_down);
        Spinner spinner3 = findViewById(R.id.spinner3);
        spinner3.setAdapter(adapter2);
        spinner3.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                Log.d(TAG, "onItemSelected: " + parent.getSelectedItem());
                Toast.makeText(MainActivity.this, "Selected item: " + position, Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        Spinner spinner4 = findViewById(R.id.spinner4);
        spinner4.setAdapter(new CustomAdapter(this, students));

        ListView listView = findViewById(R.id.listView1);
        listView.setAdapter(adapter2);
    }

    static class CustomAdapter extends ArrayAdapter<Student> {

        public CustomAdapter(@NonNull Context context, @NonNull List<Student> objects) {
            super(context, 0, objects);
        }

        @NonNull
        @Override
        public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
            View view = LayoutInflater
                    .from(getContext())
                    .inflate(R.layout.spinner_item2, parent, false);
            Student student = getItem(position);
            TextView tvFirstName = view.findViewById(R.id.textViewFirstName);
            tvFirstName.setText(student.firstName);
            TextView tvLastName = view.findViewById(R.id.textViewLastName);
            tvLastName.setText(student.lastName);
            return view;
        }

        @Override
        public View getDropDownView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
            View view = LayoutInflater
                    .from(getContext())
                    .inflate(R.layout.spinner_item2_drop_down, parent, false);
            Student student = getItem(position);
            TextView tvFirstName = view.findViewById(R.id.textViewFirstName);
            tvFirstName.setText(student.firstName);
            TextView tvLastName = view.findViewById(R.id.textViewLastName);
            tvLastName.setText(student.lastName);
            ImageView imageView = view.findViewById(R.id.imageViewPhoto);
            imageView.setImageResource(student.photoId);
            return view;
        }
    }
}
