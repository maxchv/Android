package com.borovskoy.trafficlight;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ToggleButton;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class SettingsActivity extends AppCompatActivity {

    public static final int REQUEST_CODE_SETTINGS = 100;
    public static final String TIME_EXTRA = "extra time";
    @BindView(R.id.button_red_light)
    ToggleButton mButtonRedLight;
    @BindView(R.id.button_yellow_light)
    ToggleButton mButtonYellowLight;
    @BindView(R.id.button_green_light)
    ToggleButton mButtonGreenLight;
    @BindView(R.id.edit_time_red)
    EditText mEditTimeRed;
    @BindView(R.id.edit_time_yellow)
    EditText mEditTimeYellow;
    @BindView(R.id.edit_time_green)
    EditText mEditTimeGreen;
    @BindView(R.id.button)
    Button mButton;
    private int[] mTimeLight;
    private int red, yellow, green;
    private Intent intent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
        ButterKnife.bind(this);

        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
        }

        mTimeLight = new int[3];

        intent = getIntent();

        mTimeLight = intent.getIntArrayExtra(MainActivity.CUR_TIME_EXTRA);
        red = mTimeLight[0];
        yellow = mTimeLight[1];
        green = mTimeLight[2];
        mButtonRedLight.setText(String.valueOf(mTimeLight[0]));
        mButtonYellowLight.setText(String.valueOf(mTimeLight[1]));
        mButtonGreenLight.setText(String.valueOf(mTimeLight[2]));

        mEditTimeRed.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

                mButtonRedLight.setText(s.toString());
                if (s.toString().equals("")) {
                    mButtonRedLight.setText(String.valueOf(mTimeLight[0]));
                }
            }

            @Override
            public void afterTextChanged(Editable s) {
                if (!s.toString().equals("")) {
                    red = Integer.parseInt(s.toString());
                } else if (s.toString().equals("")) {
                    red = mTimeLight[0];
                }
            }
        });

        mEditTimeYellow.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                mButtonYellowLight.setText(s.toString());
                if (s.toString().equals("")) {
                    mButtonYellowLight.setText(String.valueOf(mTimeLight[1]));
                }
            }

            @Override
            public void afterTextChanged(Editable s) {
                if (!s.toString().equals("")) {
                    yellow = Integer.parseInt(s.toString());
                } else if (s.toString().equals("")) {
                    yellow = mTimeLight[1];
                }
            }
        });

        mEditTimeGreen.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                mButtonGreenLight.setText(s.toString());
                if (s.toString().equals("")) {
                    mButtonGreenLight.setText(String.valueOf(mTimeLight[2]));
                }
            }

            @Override
            public void afterTextChanged(Editable s) {
                if (!s.toString().equals("")) {
                    green = Integer.parseInt(s.toString());
                } else if (s.toString().equals("")) {
                    green = mTimeLight[2];
                }
            }
        });
    }

    @OnClick(R.id.button)
    public void onViewClicked() {

        mTimeLight[0] = red;
        mTimeLight[1] = yellow;
        mTimeLight[2] = green;

        intent = new Intent();
        intent.putExtra(TIME_EXTRA, mTimeLight);
        setResult(RESULT_OK, intent);
        finish();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                intent = new Intent();

                setResult(RESULT_CANCELED, intent);
                finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
}