package com.borovskoy.trafficlight;

import android.animation.Animator;
import android.animation.ObjectAnimator;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ToggleButton;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class MainActivity extends AppCompatActivity {

    @BindView(R.id.button_red_light)
    ToggleButton mButtonRedLight;
    @BindView(R.id.button_yellow_light)
    ToggleButton mButtonYellowLight;
    @BindView(R.id.button_green_light)
    ToggleButton mButtonGreenLight;
    @BindView(R.id.fab)
    FloatingActionButton mFab;
    @BindView(R.id.toolbar)
    Toolbar mToolbar;
    private Thread mWorkerThread;
    private boolean isPlay;
    private int[] timeLight;
    private Handler handler;
    final static String CUR_TIME_EXTRA = "current time";
    private int curLight;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ButterKnife.bind(this);
        setSupportActionBar(mToolbar);

        isPlay = false;
        timeLight = new int[3];
        setDefaultTimeLight();
        curLight = 2;


        handler = new Handler(new Handler.Callback() {
            @Override
            public boolean handleMessage(Message msg) {

                if (curLight != msg.arg1) {
                    checkedLight().setText("");
                    checkedLightOff();
                    curLight = msg.arg1;
                    changeLight(msg.arg1);
                }
                checkedLight().setText(String.valueOf(msg.what));
                if (!mWorkerThread.isAlive()) {
                    isPlay = false;
                    translationFab(mFab);
                    checkedLight().setText("");
                }
                return true;
            }
        });
    }

    private void checkedLightOff() {
        if (curLight == 2) {
            mButtonGreenLight.setChecked(false);
        } else if (curLight == 1) {
            mButtonYellowLight.setChecked(false);
        } else {
            mButtonRedLight.setChecked(false);
        }
    }

    private void changeLight(int i) {

        switch (i) {
            case 0:
                mButtonRedLight.setChecked(true);
                break;
            case 1:
                mButtonYellowLight.setChecked(true);
                break;
            case 2:
                mButtonGreenLight.setChecked(true);
            default:
                break;
        }
    }

    private void setDefaultTimeLight() {
        timeLight[0] = 6;  //Red Light Time
        timeLight[1] = 2; //Yellow Light Time
        timeLight[2] = 6; //Green Light Time
    }

    private void translationFab(final FloatingActionButton fab) {
        int paddingBottomFab = fab.getBottom();
        int heightFab = fab.getHeight();
        int paddingBottom = fab.getPaddingBottom();
        int translationY = paddingBottomFab + paddingBottom + heightFab;
        float startFabPosition = fab.getTop();

        ObjectAnimator animY = ObjectAnimator.ofFloat(fab, "y", translationY);
        animY.setDuration(500);
        animY.start();

        animY = ObjectAnimator.ofFloat(fab, "y", startFabPosition);
        animY.setStartDelay(500);
        animY.setDuration(500);
        animY.start();
        animY.addListener(new Animator.AnimatorListener() {
            @Override
            public void onAnimationStart(Animator animation) {
                setFabIcon(fab);
            }

            @Override
            public void onAnimationEnd(Animator animation) {

            }

            @Override
            public void onAnimationCancel(Animator animation) {

            }

            @Override
            public void onAnimationRepeat(Animator animation) {

            }
        });
    }

    private void setFabIcon(FloatingActionButton fab) {
        if (isPlay) {
            fab.setImageResource(R.drawable.ic_stop_white_24dp);
        } else {
            fab.setImageResource(R.drawable.ic_play_arrow_white_24dp);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.menu_item_settings:
                Intent intent = new Intent(MainActivity.this, SettingsActivity.class);
                intent.putExtra(CUR_TIME_EXTRA, timeLight);
                startActivityForResult(intent, SettingsActivity.REQUEST_CODE_SETTINGS);
                return true;
            default:
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (data == null) {
            return;
        }

        switch (resultCode) {
            case RESULT_OK:
                timeLight = data.getIntArrayExtra(SettingsActivity.TIME_EXTRA);
                break;
            default:
                break;
        }

        super.onActivityResult(requestCode, resultCode, data);
    }

    @OnClick({R.id.button_red_light, R.id.button_yellow_light, R.id.button_green_light})
    public void onViewClicked(View view) {
        isRunWorkerThread();
        if (checkedLight() != null && !checkedLight().getText().equals("")) {
            checkedLight().setText("");
        }
        checkedLightOff();

        switch (view.getId()) {
            case R.id.button_red_light:
                curLight = 0;
                mButtonRedLight.setChecked(true);
                break;
            case R.id.button_yellow_light:
                curLight = 1;
                mButtonYellowLight.setChecked(true);
                break;
            case R.id.button_green_light:
                curLight = 2;
                mButtonGreenLight.setChecked(true);
                break;
            default:
                break;
        }
    }

    @OnClick(R.id.fab)
    public void onViewClicked() {
        translationFab(mFab);
        if (!isPlay) {
            runWorkerThread();
            isPlay = true;
        } else {
            mWorkerThread.interrupt();
            isPlay = false;
            translationFab(mFab);
        }
    }

    private void runWorkerThread() {
        mWorkerThread = new Thread(new Runnable() {
            @Override
            public void run() {
                boolean isIncrement = false;
                int i = 2;
                while (true) {
                    int timeCur = timeLight[i];
                    if (!Thread.interrupted()) {
                        while (timeCur > 0) {
                            try {
                                Thread.sleep(1000);
                            } catch (InterruptedException e) {
                                return;
                            }
                            Message message = new Message();
                            message.what = timeCur;
                            message.arg1 = i;
                            handler.sendMessage(message);
                            timeCur--;
                        }
                    } else {
                        return;
                    }

                    if (!isIncrement) {
                        i--;
                    } else {
                        i++;
                    }

                    if (i == 0) {
                        isIncrement = true;
                    } else if (i == 2) {
                        isIncrement = false;
                    }

                }
            }
        });
        mWorkerThread.start();
    }

    private ToggleButton checkedLight() {
        ToggleButton cur = null;
        if (mButtonGreenLight.isChecked()) {
            cur = mButtonGreenLight;
        } else if (mButtonRedLight.isChecked()) {
            cur = mButtonRedLight;
        } else if (mButtonYellowLight.isChecked()) {
            cur = mButtonYellowLight;
        }
        return cur;
    }

    @Override
    protected void onPause() {
        isRunWorkerThread();
        super.onPause();
    }

    private void isRunWorkerThread() {
        if (mWorkerThread != null && mWorkerThread.isAlive()) {
            mWorkerThread.interrupt();
            isPlay = false;
            translationFab(mFab);
        }
    }
}