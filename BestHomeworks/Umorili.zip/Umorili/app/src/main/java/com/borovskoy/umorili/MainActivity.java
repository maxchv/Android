package com.borovskoy.umorili;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.borovskoy.umorili.adapter.JokeAdapter;
import com.borovskoy.umorili.model.Joke;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private List<PlaceholderFragment> pageList = new ArrayList<>(11);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        SectionsPagerAdapter mSectionsPagerAdapter = new SectionsPagerAdapter(getSupportFragmentManager(), this);

        ViewPager mViewPager = findViewById(R.id.container);
        mViewPager.setAdapter(mSectionsPagerAdapter);
        mViewPager.setOffscreenPageLimit(1);

        pageList.add(new PlaceholderFragment());
        pageList.add(new PlaceholderFragment());
        pageList.add(new PlaceholderFragment());
        pageList.add(new PlaceholderFragment());
        pageList.add(new PlaceholderFragment());
        pageList.add(new PlaceholderFragment());
        pageList.add(new PlaceholderFragment());
        pageList.add(new PlaceholderFragment());
        pageList.add(new PlaceholderFragment());
        pageList.add(new PlaceholderFragment());
        pageList.add(new PlaceholderFragment());

        TabLayout tabLayout = findViewById(R.id.tabs);

        mViewPager.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(tabLayout));
        tabLayout.addOnTabSelectedListener(new TabLayout.ViewPagerOnTabSelectedListener(mViewPager));
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onMessageEvent(EventMessage event) {
        pageList.get(event.getPosition()).setPageListData(event.getJokes(), event.getPosition());

    }

    @Override
    public void onStart() {
        super.onStart();
        EventBus.getDefault().register(this);
    }

    @Override
    public void onStop() {
        super.onStop();
        EventBus.getDefault().unregister(this);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }


    public static class PlaceholderFragment extends Fragment {

        private RecyclerView mRecyclerView;
        private List<Joke> jokeList = new ArrayList<>();
        private String title;
        private JokeAdapter mAdapter;
        private TextView mTextView;

        public PlaceholderFragment() {
        }

        @Override
        public void onCreate(@Nullable Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
        }

        @Override
        public View onCreateView(LayoutInflater inflater, ViewGroup container,
                                 Bundle savedInstanceState) {
            View rootView = inflater.inflate(R.layout.fragment_main, container, false);
            mRecyclerView = rootView.findViewById(R.id.recyclerView);
            mRecyclerView.setHasFixedSize(true);
            mRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
            mAdapter = new JokeAdapter(jokeList);
            mRecyclerView.setAdapter(mAdapter);
            mTextView = rootView.findViewById(R.id.section_label);
            mTextView.setText(title);
            return rootView;
        }

        public void setPageListData(List<Joke> jokes, int position) {
            jokeList.addAll(jokes);
            if (position == 0) {
                title = getString(R.string.res_title_all);
                mTextView.setText(title);
            } else {
                title = jokeList.get(0).getDesc();
                mTextView.setText(title);
            }
            mAdapter = new JokeAdapter(jokeList);
            mRecyclerView.setAdapter(mAdapter);
        }
    }

    public class SectionsPagerAdapter extends FragmentPagerAdapter {
        private int pageCount = 11;
        private int jokeCount = 50;
        private Context context;

        public SectionsPagerAdapter(FragmentManager fm, Context context) {
            super(fm);
            this.context = context;
        }

        @Override
        public Fragment getItem(int position) {
            if (pageList.get(position).jokeList.size() == 0) {
                switch (position) {
                    case 0:
                        loadData(position, context.getString(R.string.random_res));
                    case 1:
                        loadData(position, context.getString(R.string.bash_resource_name));
                    case 2:
                        loadData(position, context.getString(R.string.abyss_resource_name));
                    case 3:
                        loadData(position, context.getString(R.string.zadolbali_resource_name));
                    case 4:
                        loadData(position, context.getString(R.string.new_anekdot_resource_name));
                    case 5:
                        loadData(position, context.getString(R.string.new_story_resource_name));
                    case 6:
                        loadData(position, context.getString(R.string.new_aforizm_resource_name));
                    case 7:
                        loadData(position, context.getString(R.string.new_stihi_resource_name));
                    case 8:
                        loadData(position, context.getString(R.string.ideer_resource_name));
                    case 9:
                        loadData(position, context.getString(R.string.deti_resource_name));
                    case 10:
                        loadData(position, context.getString(R.string.xkcdb_resource_name));
                }
            }
            return pageList.get(position);
        }

        @Override
        public int getCount() {
            return pageCount;
        }

        private void loadData(int position, String resName) {
            if (resName.equals(context.getString(R.string.random_res))) {
                JokeService.startActionLoadRandom(context);
            } else {
                JokeService.startActionLoad(context, resName,
                        jokeCount, position);
            }
        }
    }
}
