package com.borovskoy.umorili.adapter;

import android.os.Build;
import android.support.v7.widget.RecyclerView;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.borovskoy.umorili.R;
import com.borovskoy.umorili.model.Joke;

import java.util.List;

public class JokeAdapter extends RecyclerView.Adapter<JokeAdapter.ViewHolder> {

    List<Joke> jokes;

    public JokeAdapter(List<Joke> jokes) {
        this.jokes = jokes;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_data, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            holder.joke.setText(Html.fromHtml(jokes.get(position).getElementPureHtml(), Html.FROM_HTML_MODE_LEGACY));
        } else {
            holder.joke.setText(Html.fromHtml(jokes.get(position).getElementPureHtml()));
        }
    }

    @Override
    public int getItemCount() {
        return jokes.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView joke;

        public ViewHolder(View itemView) {
            super(itemView);
            joke = itemView.findViewById(R.id.joke_text);
        }
    }
}
