package com.borovskoy.umorili;

import com.borovskoy.umorili.model.Joke;

import java.util.List;

public class EventMessage {

    private List<Joke> jokes;
    private int position;

    public EventMessage(int position, List<Joke> jokes) {
        this.position = position;
        this.jokes = jokes;
    }

    public List<Joke> getJokes() {
        return jokes;
    }

    public int getPosition() {
        return position;
    }
}
