package com.borovskoy.umorili;

import android.app.IntentService;
import android.content.Context;
import android.content.Intent;

import com.borovskoy.umorili.model.Joke;

import org.greenrobot.eventbus.EventBus;

import java.io.IOException;
import java.util.List;

import retrofit2.Response;


public class JokeService extends IntentService {

    private static final String ACTION_LOAD = "com.borovskoy.umorili.action.LOAD";
    private static final String ACTION_RANDOM = "com.borovskoy.umorili.action.RANDOM";
    private static final String EXTRA_RES_NAME = "com.borovskoy.umorili.extra.RES_NAME";
    private static final String EXTRA_COUNT = "com.borovskoy.umorili.extra.COUNT";
    private static final String EXTRA_POSITION = "com.borovskoy.umorili.extra.POSITION";

    public JokeService() {
        super("JokeService");
    }


    public static void startActionLoad(Context context, String name, int count, int position) {
        Intent intent = new Intent(context, JokeService.class);
        intent.setAction(ACTION_LOAD);
        intent.putExtra(EXTRA_RES_NAME, name);
        intent.putExtra(EXTRA_COUNT, count);
        intent.putExtra(EXTRA_POSITION, position);
        context.startService(intent);
    }

    public static void startActionLoadRandom(Context context) {
        Intent intent = new Intent(context, JokeService.class);
        intent.setAction(ACTION_RANDOM);
        context.startService(intent);
    }

    @Override
    protected void onHandleIntent(Intent intent) {
        if (intent != null) {
            final String action = intent.getAction();
            if (ACTION_LOAD.equals(action)) {
                final String name = intent.getStringExtra(EXTRA_RES_NAME);
                final int count = intent.getIntExtra(EXTRA_COUNT, 1);
                final int position = intent.getIntExtra(EXTRA_POSITION, 1);
                handleActionLoad(name, count, position);
            } else if (ACTION_RANDOM.equals(action)) {
                handleActionLoadRandom();
            }
        }
    }

    private void handleActionLoadRandom() {
        try {
            Response<List<Joke>> response = AppUtil.getApi().getData().execute();
            List<Joke> jokes = response.body();
            EventBus.getDefault().post(new EventMessage(0, jokes));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void handleActionLoad(String name, int count, int position) {
        try {
            Response<List<Joke>> response = AppUtil.getApi().getData(name, count).execute();
            List<Joke> jokes = response.body();
            EventBus.getDefault().post(new EventMessage(position, jokes));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
