package com.borovskoy.a2048;

import android.animation.Animator;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.support.v4.view.GestureDetectorCompat;
import android.support.v7.app.AppCompatActivity;
import android.util.DisplayMetrics;
import android.util.SparseArray;
import android.view.GestureDetector;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewTreeObserver;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    private FrameLayout mFrameLayout;
    private TextView textTile;
    private TextView mScoreTextView;
    private TextView mEndGameTextView;
    private int mScore;
    private SparseArray<TextView> mTileSparseArray;
    private Game game;
    private int mWidthTextView;
    private GestureDetectorCompat mDetector;
    private int frameWidth;
    private boolean oneMove;
    private boolean mEndGame;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mScore = 0;
        mEndGame = true;
        mScoreTextView = (TextView) findViewById(R.id.textViewScore);
        mScoreTextView.setText(String.valueOf(mScore));
        mEndGameTextView = (TextView) findViewById(R.id.textViewEndGame);
        mFrameLayout = (FrameLayout) findViewById(R.id.frameLayout);
        mTileSparseArray = new SparseArray<>(16);

        setSizeFrameLayout();
        game = new Game();

        mDetector = new GestureDetectorCompat(this,
                new GestureDetector.SimpleOnGestureListener() {
                    @Override
                    public boolean onFling(MotionEvent e1, MotionEvent e2,
                                           float velocityX, float velocityY) {

                        moveButton(getDirection(e1, e2));

                        return true;
                    }
                });


        mFrameLayout.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
            @Override
            public void onGlobalLayout() {
                frameWidth = mFrameLayout.getWidth();
                mWidthTextView = frameWidth / 4;
            }
        });
    }

    private void setSizeFrameLayout() {
        DisplayMetrics displayMetrics = MainActivity.this.getResources().getDisplayMetrics();
        int parent = (int) (32 * displayMetrics.density);

        int pxWidth = (displayMetrics.widthPixels - parent);
        RelativeLayout.LayoutParams pa = new RelativeLayout.LayoutParams(pxWidth, pxWidth);
        pa.addRule(RelativeLayout.CENTER_IN_PARENT);
        mFrameLayout.setLayoutParams(pa);
    }

    private Direction getDirection(MotionEvent e1, MotionEvent e2) {
        float dx = e1.getX() - e2.getX();
        float dy = e1.getY() - e2.getY();

        Direction direction;
        if (Math.abs(dx) > Math.abs(dy)) {
            if (dx > 0) {
                direction = Direction.LEFT;
            } else {
                direction = Direction.RIGHT;
            }
        } else {
            if (dy > 0) {
                direction = Direction.UP;
            } else {
                direction = Direction.DOWN;
            }
        }
        return direction;
    }

    private void setTile(Tile tile) {
        textTile = new TextView(this);
        textTile.setGravity(Gravity.CENTER);
        textTile.setId(tile.getId());
        textTile.setBackgroundResource(R.drawable.cell_rectangle_2);
        textTile.setText(String.valueOf(tile.getTileValue()));
        textTile.setBackgroundResource(setColorTile(tile));
        textTile.setTextSize(20);
        int colorText = ContextCompat.getColor(this, android.R.color.white);
        textTile.setTextColor(colorText);
        RelativeLayout.LayoutParams param = new RelativeLayout.LayoutParams(mWidthTextView, mWidthTextView);
        mFrameLayout.addView(textTile, param);
        setBtnAnim(textTile, tile);
        mTileSparseArray.put(tile.getId(), textTile);
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        mDetector.onTouchEvent(ev);
        return super.dispatchTouchEvent(ev);
    }

    private void moveButton(Direction direction) {

        if (game.fieldIsEmpty() && !mEndGame) {
            mEndGameTextView.setVisibility(View.VISIBLE);
        } else if (game.isWin()) {
            mEndGameTextView.setText(getString(R.string.win));
            mEndGameTextView.setVisibility(View.VISIBLE);
        } else {
            mEndGame = game.move(direction);
            moveButtonAnim(game.getListMove());
            movePlusAnim(game.getTilesPlusList(), game.getDeleteTilesList());
        }
    }

    public void onClickNewGame(View view) {
        mFrameLayout.removeAllViews();
        game.clearField();
        mEndGameTextView.setVisibility(View.INVISIBLE);
        mEndGameTextView.setText(getString(R.string.end_game));
        setTile(game.setTileToField());
        setTile(game.setTileToField());
    }

    private void setBtnAnim(final TextView textTile, Tile tile) {
        textTile.animate()
                .x(mWidthTextView * tile.getX())
                .y(mWidthTextView * tile.getY())
                .setDuration(0);
    }

    private void moveButtonAnim(List<Tile> tiles) {

        oneMove = true;
        if (mTileSparseArray.size() == 0) {
            return;
        }
        for (Tile tile : tiles) {
            int id = tile.getId();
            textTile = mTileSparseArray.get(id);
            textTile.animate()
                    .x(mWidthTextView * tile.getX())
                    .y(mWidthTextView * tile.getY())
                    .setInterpolator(new AccelerateDecelerateInterpolator())
                    .setDuration(200)
                    .setListener(new Animator.AnimatorListener() {
                        @Override
                        public void onAnimationStart(Animator animation) {

                        }

                        @Override
                        public void onAnimationEnd(Animator animation) {
                            if (oneMove) {
                                setTile(game.setTileToField());
                                oneMove = false;
                            }
                        }

                        @Override
                        public void onAnimationCancel(Animator animation) {

                        }

                        @Override
                        public void onAnimationRepeat(Animator animation) {

                        }
                    });
        }
        oneMove = true;
    }

    private void movePlusAnim(List<Tile> plus, List<Tile> delete) {
        oneMove = true;
        if (plus.isEmpty() && delete.isEmpty()) {
            return;
        }
        TextView tilePlus;
        for (int i = 0; i < delete.size(); i++) {
            textTile = mTileSparseArray.get(delete.get(i).getId());
            tilePlus = mTileSparseArray.get(plus.get(i).getId());
            tilePlus.setText(String.valueOf(plus.get(i).getTileValue()));
            tilePlus.setBackgroundResource(setColorTile(plus.get(i)));
            mScore += plus.get(i).getTileValue();
            mScoreTextView.setText(String.valueOf(mScore));
            mFrameLayout.removeView(textTile);

            Animation shakeAnimation = AnimationUtils.loadAnimation(this, R.anim.shake);
            tilePlus.startAnimation(shakeAnimation);
            Animation anim = AnimationUtils.loadAnimation(MainActivity.this, R.anim.fade);
            textTile.startAnimation(anim);
            if (game.getListMove().isEmpty() && oneMove) {
                setTile(game.setTileToField());
                oneMove = false;
            }
        }
    }

    private int setColorTile(Tile t) {

        switch (t.getTileValue()) {
            case 2:
                return R.drawable.cell_rectangle_2;
            case 4:
                return R.drawable.cell_rectangle_4;
            case 8:
                return R.drawable.cell_rectangle_8;
            case 16:
                return R.drawable.cell_rectangle_16;
            case 32:
                return R.drawable.cell_rectangle_32;
            case 64:
                return R.drawable.cell_rectangle_64;
            case 128:
                return R.drawable.cell_rectangle_128;
            case 256:
                return R.drawable.cell_rectangle_256;
            case 521:
                return R.drawable.cell_rectangle_512;
            case 1024:
                return R.drawable.cell_rectangle_1024;
            case 2048:
                return R.drawable.cell_rectangle_2048;
            default:
                return R.drawable.cell_rectangle_2;
        }
    }

}
