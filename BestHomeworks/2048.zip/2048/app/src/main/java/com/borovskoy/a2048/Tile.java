package com.borovskoy.a2048;

import java.util.Random;

public class Tile {

    private int x;
    private int y;
    private int mTileValue;
    private int id;
    private static int count;

    public Tile(int x, int y) {
        this.x = x;
        this.y = y;
        mTileValue = getNumForTile();
        id = ++count;
    }

    public int getTileValue() {
        return mTileValue;
    }

    public void setTileValue(int tileValue) {
        mTileValue = tileValue;
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public void setX(int x) {
        this.x = x;
    }

    public void setY(int y) {
        this.y = y;
    }

    private int getNumForTile() {
        Random random = new Random();
        return ((random.nextInt(2) + 1) * 2);
    }

    public int getId() {
        return id;
    }

    @Override
    public String toString() {
        return "Tile{" +
                "x=" + x +
                ", y=" + y +
                ", mTileValue=" + mTileValue +
                '}';
    }
}
