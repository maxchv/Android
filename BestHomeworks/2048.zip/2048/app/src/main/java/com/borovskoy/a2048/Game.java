package com.borovskoy.a2048;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

class Game {

    private List<Tile> mTilesList;
    private List<Tile> mDeleteTilesList;
    private List<Tile> mTilesPlusList;
    private Tile[][] field = new Tile[4][4];
    private int id;
    private Tile tmp;

    Game() {
        mTilesList = new ArrayList<>(16);
        mDeleteTilesList = new ArrayList<>(8);
        mTilesPlusList = new ArrayList<>(8);
    }

    Tile setTileToField() {
        int x, y;
        Random random = new Random();
        Tile tile;
        while (true) {
            x = random.nextInt(4);
            y = random.nextInt(4);
            if (field[x][y] == null) {
                tile = new Tile(x, y);
                field[x][y] = tile;
                break;
            }
        }
        return tile;
    }

    boolean fieldIsEmpty() {
        for (Tile[] aField : field) {
            for (int j = 0; j < field.length; j++) {

                if (aField[j] == null) {
                    return false;
                }
            }
        }
        return true;
    }

    boolean move(Direction direction) {
        mTilesList.clear();
        mDeleteTilesList.clear();
        mTilesPlusList.clear();

        switch (direction) {

            case LEFT:
                moveLeft();
                break;
            case RIGHT:
                moveRight();
                break;
            case UP:
                moveUp();
                break;
            case DOWN:
                moveDown();
                break;
            default:
                break;
        }
        return isMove();
    }

    private void moveDown() {

        for (int k = 0; k < field.length; k++) {
            id = -1;
            for (int i = 0; i < field.length; i++) {
                for (int j = field.length - 1; j > i; j--) {
                    if (field[k][j - 1] != null && field[k][j] == null) {
                        tmp = field[k][j - 1];
                        field[k][j - 1] = null;
                        field[k][j] = tmp;
                        tmp.setY(j);
                        addSwapTile(tmp);
                    } else if (field[k][j - 1] != null && field[k][j] != null
                            && field[k][j - 1].getTileValue() == field[k][j].getTileValue()) {
                        if (field[k][j - 1].getId() != id && field[k][j].getId() != id) {
                            mDeleteTilesList.add(field[k][j - 1]);
                            field[k][j - 1] = null;
                            field[k][j].setTileValue(field[k][j].getTileValue() * 2);
                            id = field[k][j].getId();
                            mTilesPlusList.add(field[k][j]);
                            System.out.println("del list" + mDeleteTilesList.toString());
                            System.out.println("plus list" + mTilesPlusList.toString());
                        }
                    }
                }
            }
        }
    }

    private void moveRight() {

        for (int k = 0; k < field.length; k++) {
            id = -1;
            for (int i = 0; i < field.length; i++) {
                for (int j = field.length - 1; j > i; j--) {

                    if (field[j - 1][k] != null && field[j][k] == null) {
                        tmp = field[j - 1][k];
                        field[j - 1][k] = null;
                        field[j][k] = tmp;
                        tmp.setX(j);
                        addSwapTile(tmp);
                    } else if (field[j - 1][k] != null && field[j][k] != null
                            && field[j - 1][k].getTileValue() == field[j][k].getTileValue()) {
                        if (field[j - 1][k].getId() != id && field[j][k].getId() != id) {
                            mDeleteTilesList.add(field[j - 1][k]);
                            field[j - 1][k] = null;
                            field[j][k].setTileValue(field[j][k].getTileValue() * 2);
                            id = field[j][k].getId();
                            mTilesPlusList.add(field[j][k]);
                        }
                    }
                }
            }
        }
    }

    private void moveLeft() {
        for (int k = 0; k < field.length; k++) {
            id = -1;
            for (int i = 0; i < field.length; i++) {
                for (int j = field.length - 1; j > i; j--) {

                    if (field[j][k] != null && field[j - 1][k] == null) {
                        tmp = field[j][k];
                        field[j][k] = null;
                        field[j - 1][k] = tmp;
                        tmp.setX(j - 1);
                        addSwapTile(tmp);
                    } else if (field[j - 1][k] != null && field[j][k] != null
                            && field[j - 1][k].getTileValue() == field[j][k].getTileValue()) {
                        if (field[j - 1][k].getId() != id && field[j][k].getId() != id) {
                            mDeleteTilesList.add(field[j][k]);
                            field[j][k] = null;
                            field[j - 1][k].setTileValue(field[j - 1][k].getTileValue() * 2);
                            id = field[j - 1][k].getTileValue();
                            mTilesPlusList.add(field[j - 1][k]);
                        }
                    }
                }
            }
        }
    }

    private void moveUp() {
        for (int k = 0; k < field.length; k++) {
            id = -1;
            for (int i = 0; i < field.length; i++) {
                for (int j = field.length - 1; j > i; j--) {
                    if (field[k][j] != null && field[k][j - 1] == null) {
                        tmp = field[k][j];
                        field[k][j] = null;
                        field[k][j - 1] = tmp;
                        tmp.setY(j - 1);
                        addSwapTile(tmp);
                    } else if (field[k][j] != null && field[k][j - 1] != null
                            && field[k][j].getTileValue() == field[k][j - 1].getTileValue()) {
                        if (field[k][j - 1].getId() != id && field[k][j].getId() != id) {
                            mDeleteTilesList.add(field[k][j]);
                            field[k][j] = null;
                            field[k][j - 1].setTileValue(field[k][j - 1].getTileValue() * 2);
                            id = field[k][j - 1].getId();
                            mTilesPlusList.add(field[k][j - 1]);
                        }
                    }
                }
            }
        }
    }

    private void addSwapTile(Tile tile) {

        if (tile != null && mTilesList.isEmpty()) {
            mTilesList.add(tile);
            return;
        }
        int ind = isContainsTile(tile);
        if (ind > -1) {
            mTilesList.set(ind, tile);
        } else {
            mTilesList.add(tile);
        }
    }

    private int isContainsTile(Tile tile) {
        for (int i = 0; i < mTilesList.size(); i++) {
            if (mTilesList.get(i).getId() == tile.getId()) {
                mTilesList.set(i, tile);
                return i;
            }
        }
        return -1;
    }

    void clearField() {
        for (int i = 0; i < field.length; i++) {
            for (int j = 0; j < field.length; j++) {
                field[i][j] = null;
            }
        }
    }

    List<Tile> getListMove() {
        return mTilesList;
    }

    List<Tile> getDeleteTilesList() {
        return mDeleteTilesList;
    }

    List<Tile> getTilesPlusList() {
        return mTilesPlusList;
    }

    private boolean isMove() {

        if (!mTilesList.isEmpty()) {
            return true;
        }

        if (!mDeleteTilesList.isEmpty()) {
            return true;
        }

        if (!mTilesPlusList.isEmpty()) {
            return true;
        }
        return false;
    }

    boolean isWin() {
        for (int i = 0; i < field.length; i++) {
            for (int j = 0; j < field.length; j++) {
                if (field[i][j] != null && field[i][j].getTileValue() > 2044) {
                    return true;
                }
            }
        }
        return false;
    }
}
