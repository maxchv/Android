package com.borovskoy.a2048;

public enum Direction {
    UP, DOWN, LEFT, RIGHT
}
