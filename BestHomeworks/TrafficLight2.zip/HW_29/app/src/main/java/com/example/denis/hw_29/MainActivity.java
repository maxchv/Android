package com.example.denis.hw_29;

import android.content.Intent;
import android.graphics.Typeface;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;


public class MainActivity extends AppCompatActivity implements View.OnClickListener, MenuItem.OnMenuItemClickListener {

    static final String RED = "red";
    static final String YELLOW = "yellow";
    static final String GREEN = "green";
    static final int REQUEST_CODE = 100;
    ImageView red, yellow, green;
    int redTimer = 3, yellowTimer = 3, greenTimer = 3, current = 0;
    Handler handler;
    Thread thread;
    boolean b;
    TextView textView;
    Toolbar toolbar;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        red = findViewById(R.id.red);
        yellow = findViewById(R.id.yellow);
        green = findViewById(R.id.green);
        textView = findViewById(R.id.text);
        toolbar = findViewById(R.id.toolbar_actionbar);
        setSupportActionBar(toolbar);


        Typeface face = Typeface.createFromAsset(getAssets(), "digital.ttf");
        textView.setTypeface(face);
        textView.setTextColor(getResources().getColor(R.color.colorPrimary));
        yellow.setOnClickListener(this);
        red.setOnClickListener(this);
        green.setOnClickListener(this);

        handler = new Handler(new Handler.Callback() {
            @Override
            public boolean handleMessage(Message msg) {
                if (current <= greenTimer) {
                    textView.setText("" + (greenTimer - current));
                    green();
                } else if (current <= greenTimer + yellowTimer) {
                    textView.setText("" + (greenTimer + yellowTimer - current));
                    yellow();
                } else if (current <= greenTimer + yellowTimer + redTimer) {
                    textView.setText("" + (greenTimer + yellowTimer + redTimer - current));
                    red();
                } else current = 0;
                return true;
            }
        });
        grey();

    }

    public void green() {
        red.setImageDrawable(getResources().getDrawable(R.drawable.grey));
        yellow.setImageDrawable(getResources().getDrawable(R.drawable.grey));
        green.setImageDrawable(getResources().getDrawable(R.drawable.green));
    }

    public void yellow() {
        red.setImageDrawable(getResources().getDrawable(R.drawable.grey));
        yellow.setImageDrawable(getResources().getDrawable(R.drawable.yellow));
        green.setImageDrawable(getResources().getDrawable(R.drawable.grey));
    }

    public void red() {
        red.setImageDrawable(getResources().getDrawable(R.drawable.red));
        yellow.setImageDrawable(getResources().getDrawable(R.drawable.grey));
        green.setImageDrawable(getResources().getDrawable(R.drawable.grey));
    }

    public void grey() {
        red.setImageDrawable(getResources().getDrawable(R.drawable.grey));
        yellow.setImageDrawable(getResources().getDrawable(R.drawable.grey));
        green.setImageDrawable(getResources().getDrawable(R.drawable.grey));
        textView.setText("0");
        current = 0;
    }


    @Override
    public void onClick(View v) {

        switch (v.getId()) {

            case R.id.red:
                stop();
                red();
                break;
            case R.id.yellow:
                stop();
                yellow();
                break;
            case R.id.green:
                stop();
                green();
                break;
        }
    }


    void stop() {
        if (thread != null && !thread.isInterrupted()) {
            thread = null;
            b = false;
            grey();
        } else grey();
    }

    @Override
    public boolean onMenuItemClick(MenuItem item) {

        switch (item.getItemId()) {
            case R.id.start:
                if (thread == null) {
                    thread = new Thread(new Run());
                    thread.start();
                }
                b = true;
                break;
            case R.id.stop:
                stop();
                break;
            case R.id.settings:
                Intent intent = new Intent(MainActivity.this, SecondaryActivity.class);
                intent.putExtra(RED, redTimer);
                intent.putExtra(YELLOW, yellowTimer);
                intent.putExtra(GREEN, greenTimer);
                startActivityForResult(intent, REQUEST_CODE);
                stop();
                break;
        }
        return true;
    }

    public class Run implements Runnable {

        @Override
        public void run() {
            long temp = System.currentTimeMillis();
            while (b) {
                if (temp == System.currentTimeMillis()) {
                    current++;
                    handler.sendEmptyMessage(0);
                    temp += 1000;
                }
            }

        }
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);

        MenuItem settings = menu.findItem(R.id.settings);
        MenuItem start = menu.findItem(R.id.start);
        MenuItem stop = menu.findItem(R.id.stop);

        settings.setOnMenuItemClickListener(this);
        start.setOnMenuItemClickListener(this);
        stop.setOnMenuItemClickListener(this);


        return true;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if(requestCode==MainActivity.REQUEST_CODE && resultCode==RESULT_OK){
            redTimer = data.getIntExtra(RED,0);
            yellowTimer = data.getIntExtra(YELLOW,0);
            greenTimer = data.getIntExtra(GREEN,0);
        }
    }
}

