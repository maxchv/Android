package com.example.denis.hw_29;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class SecondaryActivity extends AppCompatActivity implements View.OnClickListener {

    EditText red, yellow, green;
    Button ok, cancel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_secondary);

        red = findViewById(R.id.editRed);
        yellow = findViewById(R.id.editYellow);
        green = findViewById(R.id.editGreen);
        ok = findViewById(R.id.ok);
        cancel = findViewById(R.id.cancel);

        ok.setOnClickListener(this);
        cancel.setOnClickListener(this);
        red.setText("" + getIntent().getIntExtra(MainActivity.RED, 0));
        yellow.setText("" + getIntent().getIntExtra(MainActivity.YELLOW, 0));
        green.setText("" + getIntent().getIntExtra(MainActivity.GREEN, 0));
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.ok:
                Intent intent = new Intent();
                if (red.getText().length() == 0) {
                    intent.putExtra(MainActivity.RED, 0);
                } else
                    intent.putExtra(MainActivity.RED, Integer.parseInt(red.getText().toString()));

                if (yellow.getText().length() == 0) {
                    intent.putExtra(MainActivity.YELLOW, 0);
                } else
                    intent.putExtra(MainActivity.YELLOW, Integer.parseInt(yellow.getText().toString()));

                if (green.getText().length() == 0) {
                    intent.putExtra(MainActivity.GREEN, 0);
                } else
                    intent.putExtra(MainActivity.GREEN, Integer.parseInt(green.getText().toString()));

                setResult(RESULT_OK, intent);

                finish();
                break;
            case R.id.cancel:
                finish();
                break;
        }
    }
}
