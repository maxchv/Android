package com.yana.raceapplication;

import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {
    public final static int RUN_TO_RACE = 1;
    public final static int END_TO_RACE = 0;
    public final static int GO_TO_START = -1000;

    GameResults mGameResults;
    private GameState gameState;

    private Handler handlerNext;
    List<CarRace> listCar;

    private FrameLayout frameLayout;
    TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        gameState = GameState.ON_START;
        initView();

        handlerNext = new Handler(new Handler.Callback() {
            @Override
            public boolean handleMessage(Message msg) {
                return goToNextPos((CarRace) msg.obj, msg.what);
            }
        });
        initCarList();

        if (savedInstanceState != null) {
            mGameResults = new GameResults(savedInstanceState);
        } else {
            mGameResults = new GameResults();
        }
        showResults(false);
    }

    private void initView() {
        frameLayout = findViewById(R.id.frameLayout);
        textView = findViewById(R.id.textView);
    }

    private void initCarList() {
        int i = 0;
        listCar = new ArrayList<>();

        listCar.add(new CarRace(++i, getString(R.string.blue), findViewById(R.id.imageViewOne), handlerNext));
        listCar.add(new CarRace(++i, getString(R.string.red), findViewById(R.id.imageViewTwo), handlerNext));
        listCar.add(new CarRace(++i, getString(R.string.yellow), findViewById(R.id.imageViewThree), handlerNext));
    }

    private boolean goToNextPos(CarRace car, int what) {
        if (car == null || gameState == GameState.ON_FINISH && what != GO_TO_START) {
            return false;
        }
        ImageView obj = car.getImageView();

        FrameLayout.LayoutParams params = (FrameLayout.LayoutParams) obj.getLayoutParams();
        if (params.leftMargin + obj.getWidth() + what >= frameLayout.getWidth()) {
            stopRace(car.getId());
            return false;
        }
        if (what == GO_TO_START) {
            params.leftMargin = 0;
        } else {
            params.leftMargin += what;
            gameState = GameState.RUNNING;
        }
        obj.setLayoutParams(params);
        return true;
    }

    private void sendGoToStart(int what) {
        for (int i = 0; i < listCar.size(); i++) {
            goToNextPos(listCar.get(i), what);
        }
        gameState = GameState.ON_START;
    }

    private void stopRace(int winnerId) {
        sendToAll(END_TO_RACE);

        gameState = GameState.ON_FINISH;
        mGameResults.setCurWinNum(winnerId);
        showResults(true);
    }

    private void showResults(boolean isWon) {
        textView.setText(mGameResults.showResults(isWon));
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        switch (mGameResults.mCurUserChoose){
            case 1: menu.findItem(R.id.item_1).setChecked(true);
                break;
            case 2:menu.findItem(R.id.item_2).setChecked(true);
                break;
            case 3:menu.findItem(R.id.item_3).setChecked(true);
                break;
        }
        return super.onPrepareOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.itemGo:
                if (gameState != GameState.ON_START) {
                    return false;
                }
                sendToAll(RUN_TO_RACE);
                break;
            case R.id.itemNew:
                if (gameState != GameState.ON_FINISH) {
                    return false;
                }
                sendGoToStart(GO_TO_START);
                break;
            case R.id.item_1:
                mGameResults.setCurUserChoose(1, gameState);
                break;
            case R.id.item_2:
                mGameResults.setCurUserChoose(2, gameState);
                break;
            case R.id.item_3:
                mGameResults.setCurUserChoose(3, gameState);
        }
        showResults(false);
        return super.onOptionsItemSelected(item);
    }

    private void sendToAll(int what) {
        for (int i = 0; i < listCar.size(); i++) {
            listCar.get(i).doActionCar(what);
        }
    }

    @Override
    protected void onDestroy() {
        CarRace carRace;
        for (int i = 0; i < listCar.size(); i++) {
            carRace = listCar.get(i);
            if (carRace != null) {
                carRace.quitThread();
            }
        }
        super.onDestroy();
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        mGameResults.saveResults(outState);
    }

    class GameResults {
        static final String CUR_USER_CHOOSE = "curUserChoose";
        static final String GAMES_COUNT = "gamesCount";
        static final String GAMES_QUESSED_COUNT = "gamesQuessedCount";

        private int mCurWinNum;
        private int mCurUserChoose;
        private int mGamesCount;
        private int mGamesQuessedCount;

        GameResults() {
            mCurUserChoose = 2;
        }

        GameResults(Bundle savedInstanceState) {
            mCurUserChoose = savedInstanceState.getInt(CUR_USER_CHOOSE);
            mGamesCount = savedInstanceState.getInt(GAMES_COUNT);
            mGamesQuessedCount = savedInstanceState.getInt(GAMES_QUESSED_COUNT);
        }

        void setCurWinNum(int curWinNum) {
            mCurWinNum = curWinNum;
            if (mCurWinNum == mCurUserChoose) {
                mGamesQuessedCount++;
            }
            mGamesCount++;
        }

        void setCurUserChoose(int curUserChoose, GameState state) {
            if (state != GameState.RUNNING) {
                mCurUserChoose = curUserChoose;
            }
        }

        String showResults(boolean isWon) {
            String str = String.format(Locale.getDefault(), "Score %d : %d", mGamesQuessedCount,
                    mGamesCount - mGamesQuessedCount);
            if (isWon && mCurWinNum == mCurUserChoose) {
                str = String.format("%s  You Won!", str);
            }
            str = String.format("%s%nYou choose %s car as future winner car.", str,
                    listCar.get(mCurUserChoose - 1).getName());
            if (isWon) {
                str = String.format("%s Won %s car.", str, listCar.get(mCurWinNum - 1).getName());
            }
            return str;
        }

        void saveResults(Bundle outState) {
            outState.putInt(CUR_USER_CHOOSE, mCurUserChoose);
            outState.putInt(GAMES_COUNT, mGamesCount);
            outState.putInt(GAMES_QUESSED_COUNT, mGamesQuessedCount);
        }
    }
}

enum GameState {
    ON_START, RUNNING, ON_FINISH;
}
