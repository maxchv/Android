package com.yana.raceapplication;

import android.os.Handler;
import android.os.HandlerThread;
import android.os.Message;
import android.widget.ImageView;

import java.util.Random;

public class CarRace {
    private int mId;
    private String mName;
    private ImageView mImageView;
    private Handler mHandler;
    private CarClassHandlerThread mCarHandlerThread;

    public CarRace(int id, String name, ImageView imageView, Handler handler) {
        mId = id;
        mName = name;
        mImageView = imageView;
        mHandler = handler;

        mCarHandlerThread = new CarClassHandlerThread("Thread " + mName);
        mCarHandlerThread.start();
    }

    public int getId() {
        return mId;
    }

    public String getName() {
        return mName;
    }

    public ImageView getImageView() {
        return mImageView;
    }

    public void doActionCar(int what) {
        mCarHandlerThread.handlerCar.obtainMessage(what).sendToTarget();
    }

    public void quitThread() {
        if (mCarHandlerThread != null) {
            mCarHandlerThread.handlerCar.removeMessages(0);
            mCarHandlerThread.quit();
        }
    }

    class CarClassHandlerThread extends HandlerThread {
        private static final int MAX_RAND_VAL = 10;
        private static final int MAX_TIME_VAL = 1000 / 75;

        Handler handlerCar;

        CarClassHandlerThread(String name) {
            super(name);
        }

        @Override
        protected void onLooperPrepared() {
            super.onLooperPrepared();

            handlerCar = new Handler((new Handler.Callback() {
                @Override
                public boolean handleMessage(Message msg) {
                    switch (msg.what) {
                        case MainActivity.RUN_TO_RACE:
                            handlerCar.post(runnable);
                            return true;
                        case MainActivity.END_TO_RACE:
                            handlerCar.removeCallbacks(runnable);
                            return true;
                        default:
                            return false;
                    }
                }
            }));
        }

        Runnable runnable = new Runnable() {
            @Override
            public void run() {
                mHandler.obtainMessage(new Random().nextInt(MAX_RAND_VAL),
                        CarRace.this).sendToTarget();
                handlerCar.postDelayed(runnable, MAX_TIME_VAL);
            }
        };
    }
}
