package com.borovskoy.dialerdemo;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.helper.ItemTouchHelper;
import android.view.View;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    private RecyclerView mRecyclerView;
    private List<Contact> mContactList;
    private Paint p = new Paint();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mContactList = Contacts.getInstance().getContactList();
        mRecyclerView = findViewById(R.id.recycler);
        initViews();

        ItemTouchHelper touchHelper = new ItemTouchHelper(new ItemTouchHelper.SimpleCallback(
                0, ItemTouchHelper.RIGHT | ItemTouchHelper.LEFT) {

            Intent intent;
            Uri number;
            String stringNumber;

            @Override
            public boolean onMove(RecyclerView recyclerView,
                                  RecyclerView.ViewHolder viewHolder,
                                  RecyclerView.ViewHolder target) {
                return false;
            }

            @Override
            public void onSwiped(RecyclerView.ViewHolder viewHolder, int direction) {

                int ind = viewHolder.getAdapterPosition();
                stringNumber = mContactList.get(ind).getNumber();

                if (direction == ItemTouchHelper.RIGHT) {
                    number = Uri.parse("tel:" + stringNumber);
                    intent = new Intent(Intent.ACTION_DIAL, number);
                    startActivity(intent);
                } else if (direction == ItemTouchHelper.LEFT) {
                    number = Uri.parse("smsto:" + stringNumber);
                    intent = new Intent(Intent.ACTION_SENDTO, number);
                    startActivity(intent);
                }
            }

            @Override
            public void onChildDraw(Canvas c, RecyclerView recyclerView,
                                    RecyclerView.ViewHolder viewHolder,
                                    float dX, float dY, int actionState,
                                    boolean isCurrentlyActive) {

                Bitmap iconCall;
                Bitmap iconSms;

                if (actionState == ItemTouchHelper.ACTION_STATE_SWIPE) {

                    View itemView = viewHolder.itemView;
                    float height = itemView.getBottom() - itemView.getTop();
                    float width = height / 3;
                    p.setColor(ContextCompat.getColor(
                            MainActivity.this, R.color.colorAccent));

                    if (dX > 0) {
                        RectF background = new RectF((float) itemView.getLeft(),
                                (float) itemView.getTop(), dX, (float) itemView.getBottom());
                        c.drawRect(background, p);
                        iconCall = BitmapFactory.decodeResource(getResources(),
                                R.drawable.ic_call_white_24dp);
                        RectF icon_dest = new RectF((float) itemView.getLeft() + width,
                                (float) itemView.getTop() + width,
                                (float) itemView.getLeft() + 2 * width,
                                (float) itemView.getBottom() - width);
                        c.drawBitmap(iconCall, null, icon_dest, p);
                    } else {
                        RectF background = new RectF((float) itemView.getRight() + dX,
                                (float) itemView.getTop(), (float) itemView.getRight(),
                                (float) itemView.getBottom());
                        c.drawRect(background, p);
                        iconSms = BitmapFactory.decodeResource(getResources(),
                                R.drawable.ic_sms_white_24dp);
                        RectF icon_dest = new RectF((float) itemView.getRight() - 2 * width,
                                (float) itemView.getTop() + width,
                                (float) itemView.getRight() - width,
                                (float) itemView.getBottom() - width);
                        c.drawBitmap(iconSms, null, icon_dest, p);
                    }
                }
                super.onChildDraw(c, recyclerView, viewHolder, dX,
                        dY, actionState, isCurrentlyActive);
            }
        });
        touchHelper.attachToRecyclerView(mRecyclerView);
    }

    private void initViews() {
        SimpleRecyclerAdapter adapter = new SimpleRecyclerAdapter(mContactList);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        mRecyclerView.setLayoutManager(layoutManager);
        mRecyclerView.setAdapter(adapter);
        DividerItemDecoration dividerItemDecoration = new DividerItemDecoration(
                mRecyclerView.getContext(), layoutManager.getOrientation());
        mRecyclerView.addItemDecoration(dividerItemDecoration);
    }

    @Override
    protected void onPause() {
        super.onPause();
        initViews();
    }
}
