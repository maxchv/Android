package com.borovskoy.dialerdemo;

class Contact {

    private String name;
    private String number;
    private int id;
    private int photoId;
    private static int sCount;

    public Contact(String name, String number, int photoId) {
        this.name = name;
        this.number = number;
        this.photoId = photoId;
        id = ++sCount;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public int getId() {
        return id;
    }

    public int getPhotoId() {
        return photoId;
    }

    public void setPhotoId(int photoId) {
        this.photoId = photoId;
    }
}
