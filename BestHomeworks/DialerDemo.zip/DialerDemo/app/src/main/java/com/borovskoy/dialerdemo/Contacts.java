package com.borovskoy.dialerdemo;

import java.util.ArrayList;
import java.util.List;

class Contacts {
    private static Contacts ourInstance;
    private List<Contact> mContactList;

    static Contacts getInstance() {
        if (ourInstance == null){
            ourInstance = new Contacts();
        }
        return ourInstance;
    }

    private Contacts() {
        mContactList = new ArrayList<>();
        mContactList.add(new Contact("Bill Cortny", "+380981234673", R.mipmap.boy1));
        mContactList.add(new Contact("Mick Fisher", "+380981286673", R.mipmap.boy2));
        mContactList.add(new Contact("Tim Baden", "+380964237679", R.mipmap.boy3));
        mContactList.add(new Contact("Sharon Cold", "+380995234664", R.mipmap.girl1));
        mContactList.add(new Contact("Liza North ", "+380736733554", R.mipmap.girl2));
    }

    public List<Contact> getContactList() {
        return mContactList;
    }
}
