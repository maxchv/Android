package com.borovskoy.musicplayer;

import android.content.Context;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

public class Playlist {

    private static Playlist instance;
    private List<Song> mSongs;

    public static Playlist getInstance(Context context){
        if(instance == null){
            instance = new Playlist(context);
        }
        return instance;
    }

    private Playlist(Context context) {
        this.mSongs = new ArrayList<>();
        loadMusic(context);
    }

    private void loadMusic(Context context) {
        Field[] fields = R.raw.class.getFields();

        for (int i = 0; i < fields.length - 1; i++) {
            String fileName = fields[i].getName();
            String name = fileName.replace("_", " ");
            int resId = 0;
            try {
                resId = R.raw.class.getField(fileName).getInt(context.getResources());
                mSongs.add(new Song(name, resId));
            } catch (IllegalAccessException | NoSuchFieldException e) {
                e.printStackTrace();
            }
        }
    }

    public List<Song> getSongs() {
        return mSongs;
    }
}

