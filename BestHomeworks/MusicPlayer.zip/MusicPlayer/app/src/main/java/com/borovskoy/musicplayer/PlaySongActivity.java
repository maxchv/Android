package com.borovskoy.musicplayer;

import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.ToggleButton;

import com.borovskoy.musicplayer.MediaPlayerService.MusicBinder;

public class PlaySongActivity extends AppCompatActivity {

    private static final String TAG = "PlaySongActivity";
    public static final int SELECTED_SONG_REQUEST_CODE = 100;
    private ImageButton mPlay;
    private ImageButton mPause;
    private TextView mSongTitle;
    private TextView mSongTimeLength;
    private TextView mSongCurTime;
    private ToggleButton mRepeatOne;
    private ToggleButton mRepeat;
    private SeekBar seekBar;

    private MediaPlayerService mediaPlayerService;
    private Intent playIntent;
    private boolean musicBound = false;

    private Song mCurSong;
    private boolean isPlaying, isPause;
    private Utils utils;

    BroadcastReceiver receiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (seekBar != null) {
                int currTime = intent.getIntExtra(MediaPlayerService.CURR_TIME_EXTRA, 0);
                seekBar.setProgress(utils.getProgressPercentage(currTime, mediaPlayerService.getSongDuration()));
                mSongCurTime.setText(utils.milliSecondsToTimer(currTime));
                mSongTimeLength.setText(utils.milliSecondsToTimer(mediaPlayerService.getSongDuration()));
            }
            if (intent.hasExtra(MediaPlayerService.CURR_SONG_EXTRA)) {
                mCurSong = (Song) intent.getSerializableExtra(MediaPlayerService.CURR_SONG_EXTRA);
                mSongTitle.setText(mCurSong.getName());
            }
        }
    };

    @Override
    protected void onStart() {
        playIntent = new Intent(this, MediaPlayerService.class);
        if (mCurSong != null) {
            playIntent.putExtra(MediaPlayerService.CURR_SONG_EXTRA, mCurSong);
        }
        bindService(playIntent, musicConnection, Context.BIND_AUTO_CREATE);
        LocalBroadcastManager.getInstance(this)
                .registerReceiver(receiver, new IntentFilter(MediaPlayerService.MEDIA_PLAYER_SERVICE));
        Log.i(TAG, "onStart: ");
        super.onStart();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_play_song);
        Log.i(TAG, "onCreate: ");

        initUI();
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {

            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                LocalBroadcastManager.getInstance(PlaySongActivity.this)
                        .unregisterReceiver(receiver);
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                int totalDuration = mediaPlayerService.getSongDuration();
                int currentPosition = utils.progressToTimer(seekBar.getProgress(), totalDuration);
                mediaPlayerService.seekTo(currentPosition);
                LocalBroadcastManager.getInstance(PlaySongActivity.this)
                        .registerReceiver(receiver, new IntentFilter(MediaPlayerService.MEDIA_PLAYER_SERVICE));
            }
        });
    }

    private ServiceConnection musicConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            MusicBinder binder = (MediaPlayerService.MusicBinder) service;
            mediaPlayerService = binder.getService();
            if (mediaPlayerService != null) {
                switchPlayPauseButton();
                switchPlayMode();
                mCurSong = mediaPlayerService.getCurrSong();
                Log.i(TAG, "onServiceConnected:  curSong - " + mCurSong.getName());
                mSongTimeLength.setText(utils.milliSecondsToTimer(mediaPlayerService.getSongDuration()));
                mRepeatOne.setChecked(mediaPlayerService.isRepeatOne());
                isPlaying = mediaPlayerService.isPlaying();
            }
            mSongTitle.setText(mCurSong.getName());
            musicBound = true;
            Log.i(TAG, "onServiceConnected");
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            musicBound = false;
            Log.i(TAG, "onServiceDisconnected");
        }
    };

    private void initUI() {
        utils = new Utils();
        mPlay = findViewById(R.id.btn_play);
        seekBar = findViewById(R.id.seekBar);
        mPause = findViewById(R.id.btn_pause);
        mSongTitle = findViewById(R.id.tv_song_title);
        mSongCurTime = findViewById(R.id.tv_song_cur_time);
        mSongTimeLength = findViewById(R.id.tv_song_length_time);
        mRepeatOne = findViewById(R.id.tb_repeat_one);
        mRepeat = findViewById(R.id.tb_repeat);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.play_song_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.menu_item_playlist) {
            Intent intent = new Intent(this, PlayListActivity.class);
            startActivityForResult(intent, SELECTED_SONG_REQUEST_CODE);
        }
        return super.onOptionsItemSelected(item);
    }

    public void onClickControlButton(View view) {
        switch (view.getId()) {
            case R.id.btn_play:
                if (!isPause) {
                    playIntent.setAction(MediaPlayerService.ACTION_PLAY);
                } else {
                    playIntent.setAction(MediaPlayerService.ACTION_RESTORE_PLAYBACK);
                    putExtrasData();
                    isPlaying = false;
                }
                mPlay.setVisibility(View.INVISIBLE);
                mPause.setVisibility(View.VISIBLE);
                startService(playIntent);
                Log.i(TAG, "onClickControlButton: Button Play");
                break;
            case R.id.btn_next:
                mediaPlayerService.playNextSong();
                Log.i(TAG, "Click Button Next song");
                break;
            case R.id.btn_previous:
                mediaPlayerService.playPreviousSong();
                Log.i(TAG, "Click Button Previous song");
                break;
            case R.id.btn_pause:
                isPause = true;
                mediaPlayerService.pause();
                mPlay.setVisibility(View.VISIBLE);
                mPause.setVisibility(View.INVISIBLE);
                isPlaying = false;
                Log.i(TAG, "onClickControlButton: Button Pause");
                break;
            case R.id.tb_repeat_one:
                mediaPlayerService.setRepeatOne(mRepeatOne.isChecked());
                mRepeatOne.setChecked(mRepeatOne.isChecked());
                mRepeat.setChecked(!mRepeatOne.isChecked());
                Log.i(TAG, "onClickControlButton: repeat_one " + mRepeatOne.isChecked());
                break;
            case R.id.tb_repeat:
                mediaPlayerService.setRepeat(mRepeat.isChecked());
                mRepeat.setChecked(mRepeatOne.isChecked());
                mRepeatOne.setChecked(!mRepeat.isChecked());
                Log.i(TAG, "onClickControlButton: repeat " + mRepeatOne.isChecked());
                break;
            default:
                break;
        }
    }

    private void switchPlayPauseButton() {
        if (mediaPlayerService.isPlaying()) {
            mPlay.setVisibility(View.INVISIBLE);
            mPause.setVisibility(View.VISIBLE);
            Log.i(TAG, "switchPlayPauseButton: mediaPlayerService isPlaying");
        } else {
            mPlay.setVisibility(View.VISIBLE);
            mPause.setVisibility(View.INVISIBLE);
            Log.i(TAG, "switchPlayPauseButton: mediaPlayerService not play");
        }
    }

    private void switchPlayMode() {
        if (mediaPlayerService.isRepeat()) {
            mRepeat.setChecked(true);
            mRepeatOne.setChecked(false);
            Log.i(TAG, "switchPlayMode: Repeat");
        } else if (mediaPlayerService.isRepeatOne()) {
            mRepeatOne.setChecked(true);
            mRepeat.setChecked(false);
            Log.i(TAG, "switchPlayMode: Repeat One");
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (data == null) {
            return;
        }
        if (requestCode == SELECTED_SONG_REQUEST_CODE) {
            mCurSong = (Song) data.getSerializableExtra(PlayListActivity.KEY_SONG);
            mediaPlayerService.setSong(mCurSong);
            mediaPlayerService.playSong();
            isPlaying = true;
            mSongTitle.setText(mCurSong.getName());
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (musicBound) {
            unbindService(musicConnection);
            Log.i(TAG, "onStop: ");
            musicBound = false;
            LocalBroadcastManager.getInstance(this)
                    .unregisterReceiver(receiver);
        }
    }

    @Override
    protected void onDestroy() {
        Log.i(TAG, "onDestroy: service is stop");
        super.onDestroy();
        if (!isPlaying) {
            stopService(playIntent);
            mediaPlayerService = null;
            Log.i(TAG, "onDestroy: not play");
        } else {
            putExtrasData();
            playIntent.setAction(MediaPlayerService.ACTION_RESTORE_PLAYBACK);
            stopService(playIntent);
            startService(playIntent);
        }
    }

    private void putExtrasData() {
        playIntent.putExtra(MediaPlayerService.ACTION_IS_REPEAT, mRepeat.isChecked());
        playIntent.putExtra(MediaPlayerService.ACTION_IS_REPEAT_ONE, mRepeatOne.isChecked());
        playIntent.putExtra(MediaPlayerService.CURR_SONG_EXTRA, mediaPlayerService.getCurrSong());
        playIntent.putExtra(MediaPlayerService.CURR_TIME_EXTRA, mediaPlayerService.getCurrTime());
    }
}
