package com.borovskoy.musicplayer;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.Menu;
import android.view.MenuItem;

public class PlayListActivity extends AppCompatActivity implements SongAdapter.OnSongClickListener {

    static final String KEY_SONG = "key song";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        SongAdapter.OnSongClickListener listener = this;
        RecyclerView recyclerView = findViewById(R.id.recycler_view);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.addItemDecoration(
                new DividerItemDecoration(recyclerView.getContext(),
                        layoutManager.getOrientation()));

        recyclerView.setAdapter(new SongAdapter(listener, Playlist.getInstance(this).getSongs()));
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.menu_item_cur_track) {
            finish();
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onSongClick(Song song) {
        Intent intent = new Intent(this, PlaySongActivity.class);
        intent.putExtra(KEY_SONG, song);
        setResult(PlaySongActivity.SELECTED_SONG_REQUEST_CODE, intent);
        finish();
    }
}
