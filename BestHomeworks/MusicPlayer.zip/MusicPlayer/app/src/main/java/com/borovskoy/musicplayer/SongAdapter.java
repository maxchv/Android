package com.borovskoy.musicplayer;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

public class SongAdapter extends RecyclerView.Adapter<SongAdapter.ViewHolder>{

    public interface OnSongClickListener{
        void onSongClick(Song song);
    }

    private final OnSongClickListener listener;
    private final List<Song> songs;
    private int lastSelectedPosition = -1;

    public SongAdapter(OnSongClickListener listener, List<Song> songs) {
        this.listener = listener;
        this.songs = songs;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View item = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.playlist_item, parent, false);
        return new ViewHolder(item);
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, int position) {
        final Song song = songs.get(position);
        holder.title.setText(song.getName());
        if (lastSelectedPosition == position) {
            holder.playSign.setVisibility(View.VISIBLE);
        }
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                if (listener != null){
                    listener.onSongClick(song);
                    lastSelectedPosition = holder.getAdapterPosition();
                    notifyDataSetChanged();
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return songs.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        ImageView playSign;
        TextView title;
        public ViewHolder(View itemView){
            super(itemView);
            playSign = itemView.findViewById(R.id.iv_play_sign);
            title = itemView.findViewById(R.id.tv_name);
        }
    }
}
