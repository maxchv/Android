package com.borovskoy.musicplayer;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.media.MediaPlayer;
import android.os.Binder;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Message;
import android.support.v4.app.NotificationCompat;
import android.support.v4.content.LocalBroadcastManager;
import android.util.Log;

import java.util.List;

public class MediaPlayerService extends Service implements MediaPlayer.OnCompletionListener {

    public static final String TAG = "MediaPlayerService";
    public static final String MEDIA_PLAYER_SERVICE = "MediaPlayerService";
    public static final String CURR_SONG_EXTRA = "currSong";
    public static final String ACTION_IS_REPEAT = "replay";
    public static final String ACTION_IS_REPEAT_ONE = "replay one";
    public static final String ACTION_PLAY = "PLAY";
    public static final String CURR_TIME_EXTRA = "time";
    public static final String ACTION_RESTORE_PLAYBACK = "restore playback";
    private static final int NOTIFY_ID = 0;
    private NotificationManager notificationManager;
    private Thread workThread;
    private HandlerThread handlerThread;
    private MediaPlayer mp;
    private List<Song> songs;
    private Song currSong;
    private Song lastSong;
    private boolean isRepeatOne = false;
    private boolean isRepeat = true;
    private boolean isPlay;

    public MediaPlayerService() {
    }

    @Override
    public void onCreate() {
        super.onCreate();
        notificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        Log.i(TAG, "onCreate: ");
        Playlist playlist = Playlist.getInstance(this);
        setPlayList(playlist.getSongs());
        currSong = playlist.getSongs().get(0);
        playSong();
        pause();
        lastSong = currSong;
        handlerThread = new HandlerThread("Service Thread");
        handlerThread.start();
        Handler handler = new Handler(handlerThread.getLooper()) {
            @Override
            public void handleMessage(Message msg) {
                while (!handlerThread.isInterrupted()) {
                    try {
                        Thread.sleep(100);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    Intent intent = new Intent(MEDIA_PLAYER_SERVICE);
                    if (mp != null) {
                        intent.putExtra(CURR_TIME_EXTRA, mp.getCurrentPosition());
                        if (mp.getCurrentPosition() == mp.getDuration() || currSong != lastSong) {
                            intent.putExtra(CURR_SONG_EXTRA, currSong);
                            lastSong = currSong;
                        }
                    }
                    LocalBroadcastManager.getInstance(getApplicationContext())
                            .sendBroadcast(intent);
                }
            }
        };
        handler.sendEmptyMessage(0);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.i(TAG, "onStartCommand: ");

        if (intent.getAction() != null) {
            String action = intent.getAction();

            switch (action) {
                case ACTION_PLAY:
                    playSong();
                    break;
                case ACTION_RESTORE_PLAYBACK:
                    setMediaPlayerRestart(intent);
                    break;
            }
            sendNotification();
            workThread = new Thread(new Runnable() {
                @Override
                public void run() {
                    while (true) {
                        sendNotification();
                        try {
                            Thread.sleep(1000);
                        } catch (InterruptedException e) {
                            workThread.interrupt();
                            e.printStackTrace();
                        }
                    }
                }
            });
            workThread.start();
            Log.i(TAG, "onStartCommand: START_REDELIVER_INTENT; startId = " + startId);
            return START_REDELIVER_INTENT;
        } else {
            Log.i(TAG, "onStartCommand: startId = " + startId);
            return super.onStartCommand(null, flags, startId);
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        if (intent.hasExtra(CURR_SONG_EXTRA)) {
            Log.i(TAG, "onBind: set Song");
            currSong = (Song) intent.getSerializableExtra(CURR_SONG_EXTRA);
        }
        Log.i(TAG, "onBind");
        return new MusicBinder();
    }

    private void setMediaPlayerRestart(Intent intent) {
        isRepeat = intent.getBooleanExtra(ACTION_IS_REPEAT, true);
        isRepeatOne = intent.getBooleanExtra(ACTION_IS_REPEAT_ONE, false);
        currSong = (Song) intent.getSerializableExtra(CURR_SONG_EXTRA);
        int currTime = intent.getIntExtra(CURR_TIME_EXTRA, 0);
        playSong();
        isPlay = true;
        Log.i(TAG, "setMediaPlayerRestart: currTime Extra = "
                + intent.getIntExtra(CURR_TIME_EXTRA, 0));
        if (currTime > 0) {
            mp.seekTo(currTime);
        }
    }

    @Override
    public void onCompletion(MediaPlayer mp) {
        Log.i(TAG, "onCompletion: ");
        if (isRepeat()) {
            playNextSong();
        } else if (isRepeatOne()) {
            mp.start();
            Log.i(TAG, "onCompletion: looping " + currSong.getName());
        } else {
            mp.stop();
            mp.release();
            Log.i(TAG, "onCompletion: Stop");
        }
    }

    public void setPlayList(List<Song> songs) {
        this.songs = songs;
    }

    public int getCurrTime() {
        if (mp != null) {
            return mp.getCurrentPosition();
        } else {
            return 0;
        }
    }

    public int getSongDuration() {
        if (mp != null) {
            return mp.getDuration();
        } else {
            return 0;
        }
    }

    public void seekTo(int currentPosition) {
        mp.seekTo(currentPosition);
    }

    public class MusicBinder extends Binder {
        MediaPlayerService getService() {
            return MediaPlayerService.this;
        }
    }

    @Override
    public boolean onUnbind(Intent intent) {
        Log.i(TAG, "onUnbind: ");
        return super.onUnbind(intent);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.i(TAG, "onDestroy: ");
        if (mp != null) {
            mp.stop();
            mp.release();
        }
        if (workThread.isAlive()) {
            workThread.interrupt();
            notificationManager.cancelAll();
        }
        handlerThread.interrupt();
    }

    public void playSong() {
        if (mp != null) {
            mp.reset();
        }
        int resId = currSong.getIdRes();
        mp = MediaPlayer.create(this, resId);
        mp.start();
        isPlay = true;
        mp.setOnCompletionListener(this);
        Log.i(TAG, "playSong: " + currSong.getName());
    }

    public void playNextSong() {
        if (currSong.getIdSong() < songs.size() - 1) {
            currSong = songs.get((currSong.getIdSong() + 1));
        } else {
            currSong = songs.get(0);
        }
        Log.i(TAG, "playNextSong: " + currSong.getName());
        playSong();
    }

    public void playPreviousSong() {
        if (currSong.getIdSong() == 0) {
            currSong = songs.get(songs.size() - 1);
        } else {
            currSong = songs.get((currSong.getIdSong() - 1));
        }
        Log.i(TAG, "playPreviousSong: " + currSong.getName());
        playSong();
    }

    public void pause() {
        if (mp != null && mp.isPlaying()) {
            mp.pause();
            isPlay = false;
            Log.i(TAG, "pause: ");
        }
    }

    public boolean isRepeatOne() {
        return isRepeatOne;
    }

    public void setRepeatOne(boolean isChecked) {
        isRepeat = !isChecked;
        isRepeatOne = isChecked;
    }

    public boolean isRepeat() {
        return isRepeat;
    }

    public void setRepeat(boolean isChecked) {
        isRepeatOne = !isChecked;
        isRepeat = isChecked;
    }

    public void setSong(Song song) {
        currSong = song;
    }

    public Song getCurrSong() {
        return currSong;
    }

    public boolean isPlaying() {
        return isPlay;
    }

    private void sendNotification() {
        Intent intent = new Intent(this, PlaySongActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0,
                intent, PendingIntent.FLAG_UPDATE_CURRENT);

        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, NotificationChannel.DEFAULT_CHANNEL_ID);

        builder.setContentIntent(pendingIntent)
                .setSmallIcon(R.drawable.ic_play_arrow_black_24dp)
                .setContentTitle("MediaPlayer")
                .setContentText(currSong.getName())
                .setLargeIcon(BitmapFactory.decodeResource(getResources(), R.drawable.ic_music_note_black_24dp))
                .setProgress(mp.getDuration(), mp.getCurrentPosition(), false)
                .setWhen(System.currentTimeMillis())
                .setAutoCancel(true);

        notificationManager.notify(NOTIFY_ID, builder.build());
    }
}
