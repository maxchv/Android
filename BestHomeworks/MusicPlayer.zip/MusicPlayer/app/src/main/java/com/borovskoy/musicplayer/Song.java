package com.borovskoy.musicplayer;

import java.io.Serializable;

public class Song implements Serializable{

    private String mName;
    private int idRes;
    private int idSong;
    private static int count = 0;

    public int getIdSong() {
        return idSong;
    }


    public Song(String mName, int idRes) {
        this.mName = mName;
        this.idRes = idRes;
        idSong = count++;
    }

    public String getName() {
        return mName;
    }

    public int getIdRes() {
        return idRes;
    }
}
