package com.yana.mynotificationapplication;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private NotificationManager manager;
    private EditText mEditTextTitle, mEditTextSimple, mEditTextNumber, mEditTextID, mEditTextDelay;
    Spinner mSpinner, mSpinnerChannel, mSpinnerUri;
    Switch mSwitch;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initNotificationChannel();
        initViews();
    }

    private void initNotificationChannel() {
        manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);

        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            String[] id, name;
            id = getResources().getStringArray(R.array.channel_id);
            name = getResources().getStringArray(R.array.channel_name);

            for (int i = 0; i < id.length; i++) {
                manager.createNotificationChannel(new NotificationChannel(id[i], name[i],
                        NotificationManager.IMPORTANCE_DEFAULT));
            }
        }
    }

    private void initViews() {
        mEditTextTitle = findViewById(R.id.text_title);
        mEditTextSimple = findViewById(R.id.text_text);
        mEditTextNumber = findViewById(R.id.text_number);
        mEditTextID = findViewById(R.id.text_id);
        mEditTextDelay = findViewById(R.id.text_delay);

        mSpinner = findViewById(R.id.spinner);
        mSpinnerChannel = findViewById(R.id.spinner_shannel);
        mSpinnerUri = findViewById(R.id.spinner_uri);
        mSwitch = findViewById(R.id.swstyle);

        findViewById(R.id.button_notify).setOnClickListener((v) -> {
            Notification notification = getNewNotification();
            int id = getNumberOrId(mEditTextID);
            int delay = 1_000 * getNumberOrId(mEditTextDelay);

            if (delay > 0) {
                setTimeOut(id, notification, delay);
            } else {
                manager.notify(id, notification);
            }
        });

        findViewById(R.id.button_clear).setOnClickListener(v -> {
            manager.cancelAll();
        });
    }

    private void setTimeOut(int id, Notification notification, int msec) {
        Runnable runnable = new Runnable() {
            @Override
            public void run() {
                try {
                    Thread.sleep(msec);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                manager.notify(id, notification);
            }
        };
        new Thread(runnable).start();
    }

    private Notification getNewNotification() {
        Notification.Builder builder = new Notification.Builder(this)
                .setSmallIcon(R.drawable.ic_touch_name)
                .setContentTitle(mEditTextTitle.getText())
                .setContentText(mEditTextSimple.getText())
                .setColor(getColor())
                .addAction(R.drawable.ic_stat_name, getString(R.string.first), getPendingIntent(MainActivity.class))
                .addAction(R.drawable.ic_middle_name, getString(R.string.secomd), getPendingIntent(SecondActivity.class))
                .addAction(R.drawable.ic_end_name, getString(R.string.third), getPendingIntent(ThirdActivity.class))
                .setAutoCancel(true)
                .setContentIntent(getPendingIntent(null))
                .setNumber(getNumberOrId(mEditTextNumber));

        if (mSwitch.isChecked()) {
            builder.setStyle(new Notification.MediaStyle());
        }
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            builder.setChannelId(getResources().getStringArray(R.array.channel_id)[mSpinnerChannel.getSelectedItemPosition()]);
        }
        return builder.build();
    }

    private int getColor() {
        return getResources().getIntArray(R.array.colors)[mSpinner.getSelectedItemPosition()];
    }

    private int getNumberOrId(TextView tv) {
        return tv.getText().toString().isEmpty() ? 0 : Integer.parseInt(tv.getText().toString());
    }

    private PendingIntent getPendingIntent(Class<?> clazz) {
        Intent intent;
        if (clazz != null) {
            intent = new Intent(this, clazz);
        } else {
            intent = new Intent(Intent.ACTION_VIEW, Uri.parse(mSpinnerUri.getSelectedItem().toString()));
        }
//      intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);//fb

        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, intent,
                PendingIntent.FLAG_UPDATE_CURRENT);
        return pendingIntent;
    }
}
