package com.example.denis.a2048;

import android.support.v4.view.GestureDetectorCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.GestureDetector;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewTreeObserver;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements  Animation.AnimationListener {

    FrameLayout frameLayout;
    int frameHeight, frameWidth, fieldSize = 4, temp, newGame = 0;
    FrameLayout.LayoutParams[][] params = new FrameLayout.LayoutParams[fieldSize][fieldSize];
    CustomButton[][] buttons = new CustomButton[fieldSize][fieldSize];
    boolean random;
    TextView textView, textView2;
    GestureDetectorCompat mDetector;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        frameLayout = findViewById(R.id.frame_layout);



        textView = findViewById(R.id.temp);
        textView2 = findViewById(R.id.temp2);
        textView.setVisibility(View.INVISIBLE);
        textView2.setVisibility(View.INVISIBLE);




        start();


        mDetector = new GestureDetectorCompat(this, new GestureDetector.SimpleOnGestureListener() {
            @Override
            public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {

                float veloX = e1.getX() - e2.getX();
                float veloY = e1.getY() - e2.getY();

                if (Math.abs(veloX) > Math.abs(veloY) & veloX < 0) {
                    moveRight();
                    if (random) {
                        newRandom();
                    }
                } else if (Math.abs(veloX) > Math.abs(veloY) & veloX > 0) {
                    moveLeft();
                    if (random) {
                        newRandom();
                    }
                    toast();
                } else if(Math.abs(veloY)>Math.abs(veloX) & veloY>0){
                    moveUp();
                    if (random) {
                        newRandom();
                    }
                }else if(Math.abs(veloY)>Math.abs(veloX) & veloY<0){
                    if (newGame > 0) {
                        start();
                        newGame = 0;
                        temp = 0;
                    } else {
                        moveDown();
                        if (random) {
                            newRandom();
                        }
                    }
                }



                return super.onFling(e1, e2, velocityX, velocityY);
            }
        });

    }

        @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        mDetector.onTouchEvent(ev);
        return true;
    }

    private void start() {
        frameLayout.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
            @Override
            public void onGlobalLayout() {
                if (temp == 0) {
                    frameHeight = frameLayout.getHeight();
                    frameWidth = frameLayout.getWidth();
                    if(buttons[0][0]==null) {
                        for (int i = 0; i < fieldSize; i++) {
                            for (int j = 0; j < fieldSize; j++) {
                                buttons[i][j] = new CustomButton(getBaseContext(), 0, 0, 0, 0, 0);
                                params[i][j] = new FrameLayout.LayoutParams((int) (frameWidth / (fieldSize * 1.1)), (int) (frameWidth / (fieldSize * 1.1)));
                                params[i][j].setMargins((int) ((0.25 * i * frameWidth) + (frameWidth * 0.05 / fieldSize)), (int) (((frameHeight - (0.25 * fieldSize * frameWidth)) / 2) + (0.25 * j * frameWidth)), 0, 0);
                                buttons[i][j].setBackgroundColor(getResources().getColor(R.color.colorGrey300));
                                buttons[i][j].setGravity(Gravity.CENTER);
                                frameLayout.addView(buttons[i][j]);
                                buttons[i][j].setTextSize(50);
                            }
                        }
                        for (int i = 0; i < fieldSize; i++) {
                            for (int j = 0; j < fieldSize; j++) {
                                buttons[i][j].setLayoutParams(params[j][i]);
                            }
                        }
                    } else {
                        for (int i = 0; i <fieldSize ; i++) {
                            for (int j = 0; j <fieldSize ; j++) {
                                buttons[i][j].setText("");
                                buttons[i][j].setValue(0);
                                buttons[i][j].setBackgroundColor(getResources().getColor(R.color.colorGrey300));
                                buttons[i][j].setTextColor(getResources().getColor(R.color.colorBlack));
                            }
                        }
                    }
                    random = true;
                    newRandom();
                    random = true;
                    newRandom();
                    correctView();
                    temp++;
                    toast();
                }
            }
        });
    }

    void newRandom() {
        boolean temp = false;
        for (int i = 0; i < fieldSize; i++) {
            for (int j = 0; j < fieldSize; j++) {
                if (buttons[i][j].getValue() == 0) {
                    temp = true;
                }
            }
        }

        if (random) {
            int x = (int) (Math.random() * 4);
            int y = (int) (Math.random() * 4);
            int z = (int) (1 + Math.random() * 100);


            if (buttons[x][y].getValue() == 0) {
                if (z < 90) {
                    buttons[x][y].setText("" + 2);
                    buttons[x][y].setValue(2);
                } else {
                    buttons[x][y].setText("" + 4);
                    buttons[x][y].setValue(4);
                }
            } else if (temp) {
                newRandom();
            }


            random = false;
        }
    }

    void toast() {
        String temp = "";
        for (int i = 0; i < fieldSize; i++) {
            for (int j = 0; j < fieldSize; j++) {

                temp += " " + buttons[i][j].getValue();
            }
            temp += "\n";
        }
        textView.setText(temp);
    }

    void moveLeft() {
        if (endGame()) {
            for (int k = 0; k < 3; k++) {
                for (int i = 0; i < fieldSize; i++) {
                    for (int j = 0; j < fieldSize; j++) {
                        if (buttons[i][j].getValue() > 0 & j > 2) {
                            if (buttons[i][j - 3].getValue() == 0) {
                                buttons[i][j].setXx(+3);
                                buttons[i][j - 3].setValue(buttons[i][j].getValue());
                                buttons[i][j].setValue(0);

                            } else if (buttons[i][j - 2].getValue() == 0) {
                                buttons[i][j].setXx(+2);
                                buttons[i][j - 2].setValue(buttons[i][j].getValue());
                                buttons[i][j].setValue(0);

                            } else if (buttons[i][j - 1].getValue() == 0) {
                                buttons[i][j].setXx(+1);
                                buttons[i][j - 1].setValue(buttons[i][j].getValue());
                                buttons[i][j].setValue(0);

                            }
                        } else if (buttons[i][j].getValue() > 0 & j > 1) {
                            if (buttons[i][j - 2].getValue() == 0) {
                                buttons[i][j].setXx(+2);
                                buttons[i][j - 2].setValue(buttons[i][j].getValue());
                                buttons[i][j].setValue(0);

                            } else if (buttons[i][j - 1].getValue() == 0) {
                                buttons[i][j].setXx(+1);
                                buttons[i][j - 1].setValue(buttons[i][j].getValue());
                                buttons[i][j].setValue(0);

                            }
                        } else if (buttons[i][j].getValue() > 0 & j > 0) {
                            if (buttons[i][j - 1].getValue() == 0) {
                                buttons[i][j].setXx(+1);
                                buttons[i][j - 1].setValue(buttons[i][j].getValue());
                                buttons[i][j].setValue(0);

                            }
                        }

                    }
                }
            }
            for (int i = 0; i < fieldSize; i++) {
                for (int j = 0; j < fieldSize; j++) {
                    if (buttons[i][j].getValue() > 0 & j < 3) {
                        if (buttons[i][j].getValue() == buttons[i][j + 1].getValue()) {
                            buttons[i][j].setValue(buttons[i][j + 1].getValue() * 2);
                            buttons[i][j + 1].setValue(0);
                            buttons[i][j + 1].setXx(+1);
                        }
                    }
                }
            }

            for (int k = 0; k < 3; k++) {
                for (int i = 0; i < fieldSize; i++) {
                    for (int j = 0; j < fieldSize; j++) {
                        if (buttons[i][j].getValue() > 0 & j > 2) {
                            if (buttons[i][j - 3].getValue() == 0) {
                                buttons[i][j].setXx(+3);
                                buttons[i][j - 3].setValue(buttons[i][j].getValue());
                                buttons[i][j].setValue(0);

                            } else if (buttons[i][j - 2].getValue() == 0) {
                                buttons[i][j].setXx(+2);
                                buttons[i][j - 2].setValue(buttons[i][j].getValue());
                                buttons[i][j].setValue(0);

                            } else if (buttons[i][j - 1].getValue() == 0) {
                                buttons[i][j].setXx(+1);
                                buttons[i][j - 1].setValue(buttons[i][j].getValue());
                                buttons[i][j].setValue(0);

                            }
                        } else if (buttons[i][j].getValue() > 0 & j > 1) {
                            if (buttons[i][j - 2].getValue() == 0) {
                                buttons[i][j].setXx(+2);
                                buttons[i][j - 2].setValue(buttons[i][j].getValue());
                                buttons[i][j].setValue(0);

                            } else if (buttons[i][j - 1].getValue() == 0) {
                                buttons[i][j].setXx(+1);
                                buttons[i][j - 1].setValue(buttons[i][j].getValue());
                                buttons[i][j].setValue(0);

                            }
                        } else if (buttons[i][j].getValue() > 0 & j > 0) {
                            if (buttons[i][j - 1].getValue() == 0) {
                                buttons[i][j].setXx(+1);
                                buttons[i][j - 1].setValue(buttons[i][j].getValue());
                                buttons[i][j].setValue(0);

                            }
                        }

                    }
                }
            }

            for (int i = 0; i < fieldSize; i++) {
                for (int j = 0; j < fieldSize; j++) {
                    if (buttons[i][j].getXx() > 0) {
                        switch (buttons[i][j].getXx()) {
                            case 1:
                                Animation animation1 = AnimationUtils.loadAnimation(this, R.anim.left_q);
                                buttons[i][j].setAnimation(animation1);
                                animation1.setAnimationListener(this);
                                buttons[i][j].setXx(0);
                                random = true;
                                break;
                            case 2:
                                Animation animation2 = AnimationUtils.loadAnimation(this, R.anim.left_h);
                                buttons[i][j].setAnimation(animation2);
                                animation2.setAnimationListener(this);
                                buttons[i][j].setXx(0);
                                random = true;
                                break;
                            case 3:
                                Animation animation3 = AnimationUtils.loadAnimation(this, R.anim.left_f);
                                buttons[i][j].setAnimation(animation3);
                                animation3.setAnimationListener(this);
                                buttons[i][j].setXx(0);
                                random = true;
                                break;
                        }
                    }
                }
            }

            toast();

        } else gameOver();
    }

    void moveUp() {
        if (endGame()) {
            for (int k = 0; k < 3; k++) {
                for (int i = 0; i < fieldSize; i++) {
                    for (int j = 0; j < fieldSize; j++) {
                        if (buttons[i][j].getValue() > 0 & i > 2) {
                            if (buttons[i - 3][j].getValue() == 0) {
                                buttons[i][j].setYyy(+3);
                                buttons[i - 3][j].setValue(buttons[i][j].getValue());
                                buttons[i][j].setValue(0);
                            } else if (buttons[i - 2][j].getValue() == 0) {
                                buttons[i][j].setYyy(+2);
                                buttons[i - 2][j].setValue(buttons[i][j].getValue());
                                buttons[i][j].setValue(0);
                            } else if (buttons[i - 1][j].getValue() == 0) {
                                buttons[i][j].setYyy(+1);
                                buttons[i - 1][j].setValue(buttons[i][j].getValue());
                                buttons[i][j].setValue(0);
                            }
                        } else if (buttons[i][j].getValue() > 0 & i > 1) {
                            if (buttons[i - 2][j].getValue() == 0) {
                                buttons[i][j].setYyy(+2);
                                buttons[i - 2][j].setValue(buttons[i][j].getValue());
                                buttons[i][j].setValue(0);
                            } else if (buttons[i - 1][j].getValue() == 0) {
                                buttons[i][j].setYyy(+1);
                                buttons[i - 1][j].setValue(buttons[i][j].getValue());
                                buttons[i][j].setValue(0);
                            }
                        } else if (buttons[i][j].getValue() > 0 & i > 0) {
                            if (buttons[i - 1][j].getValue() == 0) {
                                buttons[i][j].setYyy(+1);
                                buttons[i - 1][j].setValue(buttons[i][j].getValue());
                                buttons[i][j].setValue(0);
                            }
                        }

                    }
                }
            }
            for (int i = 0; i < fieldSize; i++) {
                for (int j = 0; j < fieldSize; j++) {
                    if (buttons[i][j].getValue() > 0 & i < 3) {
                        if (buttons[i][j].getValue() == buttons[i + 1][j].getValue()) {
                            buttons[i][j].setValue(buttons[i + 1][j].getValue() * 2);
                            buttons[i + 1][j].setValue(0);
                            buttons[i + 1][j].setYyy(+1);
                        }
                    }
                }
            }

            for (int k = 0; k < 3; k++) {
                for (int i = 0; i < fieldSize; i++) {
                    for (int j = 0; j < fieldSize; j++) {
                        if (buttons[i][j].getValue() > 0 & i > 2) {
                            if (buttons[i - 3][j].getValue() == 0) {
                                buttons[i][j].setYyy(+3);
                                buttons[i - 3][j].setValue(buttons[i][j].getValue());
                                buttons[i][j].setValue(0);
                            } else if (buttons[i - 2][j].getValue() == 0) {
                                buttons[i][j].setYyy(+2);
                                buttons[i - 2][j].setValue(buttons[i][j].getValue());
                                buttons[i][j].setValue(0);
                            } else if (buttons[i - 1][j].getValue() == 0) {
                                buttons[i][j].setYyy(+1);
                                buttons[i - 1][j].setValue(buttons[i][j].getValue());
                                buttons[i][j].setValue(0);
                            }
                        } else if (buttons[i][j].getValue() > 0 & i > 1) {
                            if (buttons[i - 2][j].getValue() == 0) {
                                buttons[i][j].setYyy(+2);
                                buttons[i - 2][j].setValue(buttons[i][j].getValue());
                                buttons[i][j].setValue(0);
                            } else if (buttons[i - 1][j].getValue() == 0) {
                                buttons[i][j].setYyy(+1);
                                buttons[i - 1][j].setValue(buttons[i][j].getValue());
                                buttons[i][j].setValue(0);
                            }
                        } else if (buttons[i][j].getValue() > 0 & i > 0) {
                            if (buttons[i - 1][j].getValue() == 0) {
                                buttons[i][j].setYyy(+1);
                                buttons[i - 1][j].setValue(buttons[i][j].getValue());
                                buttons[i][j].setValue(0);
                            }
                        }

                    }
                }
            }


            for (int i = 0; i < fieldSize; i++) {
                for (int j = 0; j < fieldSize; j++) {
                    if (buttons[i][j].getYyy() > 0) {
                        switch (buttons[i][j].getYyy()) {
                            case 1:
                                Animation animation1 = AnimationUtils.loadAnimation(this, R.anim.up_q);
                                buttons[i][j].setAnimation(animation1);
                                animation1.setAnimationListener(this);
                                buttons[i][j].setYyy(0);
                                random = true;
                                break;
                            case 2:
                                Animation animation2 = AnimationUtils.loadAnimation(this, R.anim.up_h);
                                buttons[i][j].setAnimation(animation2);
                                animation2.setAnimationListener(this);
                                buttons[i][j].setYyy(0);
                                random = true;
                                break;
                            case 3:
                                Animation animation3 = AnimationUtils.loadAnimation(this, R.anim.up_f);
                                buttons[i][j].setAnimation(animation3);
                                animation3.setAnimationListener(this);
                                buttons[i][j].setYyy(0);
                                random = true;
                                break;
                        }
                    }
                }
            }

            toast();
        } else gameOver();
    }

    void moveDown() {
        if (endGame()) {

            for (int k = 0; k < 3; k++) {
                for (int i = fieldSize - 1; i > -1; i--) {
                    for (int j = fieldSize - 1; j > -1; j--) {
                        if (buttons[i][j].getValue() > 0 & i < 1) {
                            if (buttons[i + 3][j].getValue() == 0) {
                                buttons[i][j].setYy(+3);
                                buttons[i + 3][j].setValue(buttons[i][j].getValue());
                                buttons[i][j].setValue(0);
                            } else if (buttons[i + 2][j].getValue() == 0) {
                                buttons[i][j].setYy(+2);
                                buttons[i + 2][j].setValue(buttons[i][j].getValue());
                                buttons[i][j].setValue(0);
                            } else if (buttons[i + 1][j].getValue() == 0) {
                                buttons[i][j].setYy(+1);
                                buttons[i + 1][j].setValue(buttons[i][j].getValue());
                                buttons[i][j].setValue(0);
                            }
                        } else if (buttons[i][j].getValue() > 0 & i < 2) {
                            if (buttons[i + 2][j].getValue() == 0) {
                                buttons[i][j].setYy(+2);
                                buttons[i + 2][j].setValue(buttons[i][j].getValue());
                                buttons[i][j].setValue(0);
                            } else if (buttons[i + 1][j].getValue() == 0) {
                                buttons[i][j].setYy(+1);
                                buttons[i + 1][j].setValue(buttons[i][j].getValue());
                                buttons[i][j].setValue(0);
                            }
                        } else if (buttons[i][j].getValue() > 0 & i < 3) {
                            if (buttons[i + 1][j].getValue() == 0) {
                                buttons[i][j].setYy(+1);
                                buttons[i + 1][j].setValue(buttons[i][j].getValue());
                                buttons[i][j].setValue(0);
                            }
                        }

                    }
                }
            }
            for (int i = fieldSize - 1; i > -1; i--) {
                for (int j = fieldSize - 1; j > -1; j--) {
                    if (buttons[i][j].getValue() > 0 & i > 0) {
                        if (buttons[i][j].getValue() == buttons[i - 1][j].getValue()) {
                            buttons[i][j].setValue(buttons[i - 1][j].getValue() * 2);
                            buttons[i - 1][j].setValue(0);
                            buttons[i - 1][j].setYy(+1);
                        }
                    }
                }
            }

            for (int k = 0; k < 3; k++) {
                for (int i = fieldSize - 1; i > -1; i--) {
                    for (int j = fieldSize - 1; j > -1; j--) {
                        if (buttons[i][j].getValue() > 0 & i < 1) {
                            if (buttons[i + 3][j].getValue() == 0) {
                                buttons[i][j].setYy(+3);
                                buttons[i + 3][j].setValue(buttons[i][j].getValue());
                                buttons[i][j].setValue(0);
                            } else if (buttons[i + 2][j].getValue() == 0) {
                                buttons[i][j].setYy(+2);
                                buttons[i + 2][j].setValue(buttons[i][j].getValue());
                                buttons[i][j].setValue(0);
                            } else if (buttons[i + 1][j].getValue() == 0) {
                                buttons[i][j].setYy(+1);
                                buttons[i + 1][j].setValue(buttons[i][j].getValue());
                                buttons[i][j].setValue(0);
                            }
                        } else if (buttons[i][j].getValue() > 0 & i < 2) {
                            if (buttons[i + 2][j].getValue() == 0) {
                                buttons[i][j].setYy(+2);
                                buttons[i + 2][j].setValue(buttons[i][j].getValue());
                                buttons[i][j].setValue(0);
                            } else if (buttons[i + 1][j].getValue() == 0) {
                                buttons[i][j].setYy(+1);
                                buttons[i + 1][j].setValue(buttons[i][j].getValue());
                                buttons[i][j].setValue(0);
                            }
                        } else if (buttons[i][j].getValue() > 0 & i < 3) {
                            if (buttons[i + 1][j].getValue() == 0) {
                                buttons[i][j].setYy(+1);
                                buttons[i + 1][j].setValue(buttons[i][j].getValue());
                                buttons[i][j].setValue(0);
                            }
                        }

                    }
                }
            }


            for (int i = 0; i < fieldSize; i++) {
                for (int j = 0; j < fieldSize; j++) {
                    if (buttons[i][j].getYy() > 0) {
                        switch (buttons[i][j].getYy()) {
                            case 1:
                                Animation animation1 = AnimationUtils.loadAnimation(this, R.anim.down_q);
                                buttons[i][j].setAnimation(animation1);
                                animation1.setAnimationListener(this);
                                buttons[i][j].setYy(0);
                                random = true;
                                break;
                            case 2:
                                Animation animation2 = AnimationUtils.loadAnimation(this, R.anim.down_h);
                                buttons[i][j].setAnimation(animation2);
                                animation2.setAnimationListener(this);
                                buttons[i][j].setYy(0);
                                random = true;
                                break;
                            case 3:
                                Animation animation3 = AnimationUtils.loadAnimation(this, R.anim.down_f);
                                buttons[i][j].setAnimation(animation3);
                                animation3.setAnimationListener(this);
                                buttons[i][j].setYy(0);
                                random = true;
                                break;
                        }
                    }
                }
            }

            toast();
        } else gameOver();
    }

    void moveRight() {
        if (endGame()) {

            for (int k = 0; k < 3; k++) {
                for (int i = fieldSize - 1; i > -1; i--) {
                    for (int j = fieldSize - 1; j > -1; j--) {
                        if (buttons[i][j].getValue() > 0 & j < 1) {
                            if (buttons[i][j + 3].getValue() == 0) {
                                buttons[i][j].setXxx(+3);
                                buttons[i][j + 3].setValue(buttons[i][j].getValue());
                                buttons[i][j].setValue(0);
                            } else if (buttons[i][j + 2].getValue() == 0) {
                                buttons[i][j].setXxx(+2);
                                buttons[i][j + 2].setValue(buttons[i][j].getValue());
                                buttons[i][j].setValue(0);
                            } else if (buttons[i][j + 1].getValue() == 0) {
                                buttons[i][j].setXxx(+1);
                                buttons[i][j + 1].setValue(buttons[i][j].getValue());
                                buttons[i][j].setValue(0);
                            }
                        } else if (buttons[i][j].getValue() > 0 & j < 2) {
                            if (buttons[i][j + 2].getValue() == 0) {
                                buttons[i][j].setXxx(+2);
                                buttons[i][j + 2].setValue(buttons[i][j].getValue());
                                buttons[i][j].setValue(0);
                            } else if (buttons[i][j + 1].getValue() == 0) {
                                buttons[i][j].setXxx(+1);
                                buttons[i][j + 1].setValue(buttons[i][j].getValue());
                                buttons[i][j].setValue(0);
                            }
                        } else if (buttons[i][j].getValue() > 0 & j < 3) {
                            if (buttons[i][j + 1].getValue() == 0) {
                                buttons[i][j].setXxx(+1);
                                buttons[i][j + 1].setValue(buttons[i][j].getValue());
                                buttons[i][j].setValue(0);
                            }
                        }

                    }
                }
            }
            for (int i = fieldSize - 1; i > -1; i--) {
                for (int j = fieldSize - 1; j > -1; j--) {
                    if (buttons[i][j].getValue() > 0 & j > 0) {
                        if (buttons[i][j].getValue() == buttons[i][j - 1].getValue()) {
                            buttons[i][j].setValue(buttons[i][j - 1].getValue() * 2);
                            buttons[i][j - 1].setValue(0);
                            buttons[i][j - 1].setXxx(+1);
                        }
                    }
                }
            }

            for (int k = 0; k < 3; k++) {
                for (int i = fieldSize - 1; i > -1; i--) {
                    for (int j = fieldSize - 1; j > -1; j--) {
                        if (buttons[i][j].getValue() > 0 & j < 1) {
                            if (buttons[i][j + 3].getValue() == 0) {
                                buttons[i][j].setXxx(+3);
                                buttons[i][j + 3].setValue(buttons[i][j].getValue());
                                buttons[i][j].setValue(0);
                            } else if (buttons[i][j + 2].getValue() == 0) {
                                buttons[i][j].setXxx(+2);
                                buttons[i][j + 2].setValue(buttons[i][j].getValue());
                                buttons[i][j].setValue(0);
                            } else if (buttons[i][j + 1].getValue() == 0) {
                                buttons[i][j].setXxx(+1);
                                buttons[i][j + 1].setValue(buttons[i][j].getValue());
                                buttons[i][j].setValue(0);
                            }
                        } else if (buttons[i][j].getValue() > 0 & j < 2) {
                            if (buttons[i][j + 2].getValue() == 0) {
                                buttons[i][j].setXxx(+2);
                                buttons[i][j + 2].setValue(buttons[i][j].getValue());
                                buttons[i][j].setValue(0);
                            } else if (buttons[i][j + 1].getValue() == 0) {
                                buttons[i][j].setXxx(+1);
                                buttons[i][j + 1].setValue(buttons[i][j].getValue());
                                buttons[i][j].setValue(0);
                            }
                        } else if (buttons[i][j].getValue() > 0 & j < 3) {
                            if (buttons[i][j + 1].getValue() == 0) {
                                buttons[i][j].setXxx(+1);
                                buttons[i][j + 1].setValue(buttons[i][j].getValue());
                                buttons[i][j].setValue(0);
                            }
                        }

                    }
                }
            }


            for (int i = 0; i < fieldSize; i++) {
                for (int j = 0; j < fieldSize; j++) {
                    if (buttons[i][j].getXxx() > 0) {
                        switch (buttons[i][j].getXxx()) {
                            case 1:
                                Animation animation1 = AnimationUtils.loadAnimation(this, R.anim.right_q);
                                buttons[i][j].setAnimation(animation1);
                                animation1.setAnimationListener(this);
                                buttons[i][j].setXxx(0);
                                random = true;
                                break;
                            case 2:
                                Animation animation2 = AnimationUtils.loadAnimation(this, R.anim.right_h);
                                buttons[i][j].setAnimation(animation2);
                                animation2.setAnimationListener(this);
                                buttons[i][j].setXxx(0);
                                random = true;
                                break;
                            case 3:
                                Animation animation3 = AnimationUtils.loadAnimation(this, R.anim.right_f);
                                buttons[i][j].setAnimation(animation3);
                                animation3.setAnimationListener(this);
                                buttons[i][j].setXxx(0);
                                random = true;
                                break;
                        }
                    }
                }
            }

            toast();
        } else gameOver();
    }

    void correctView() {
        for (int i = 0; i < fieldSize; i++) {
            for (int j = 0; j < fieldSize; j++) {
                if (buttons[i][j].getValue() > 0) {
                    buttons[i][j].setText("" + buttons[i][j].getValue());
                } else {
                    buttons[i][j].setText("");
                }
                if (buttons[i][j].getValue() < 3) {
                    buttons[i][j].setBackgroundColor(getResources().getColor(R.color.colorGrey300));
                    buttons[i][j].setTextColor(getResources().getColor(R.color.colorBlack));
                    buttons[i][j].setTextSize(50);
                } else if (buttons[i][j].getValue() == 4) {
                    buttons[i][j].setBackgroundColor(getResources().getColor(R.color.colorYellow200));
                    buttons[i][j].setTextColor(getResources().getColor(R.color.colorBlack));
                    buttons[i][j].setTextSize(50);
                } else if (buttons[i][j].getValue() == 8) {
                    buttons[i][j].setBackgroundColor(getResources().getColor(R.color.colorYellow300));
                    buttons[i][j].setTextColor(getResources().getColor(R.color.colorBlack));
                    buttons[i][j].setTextSize(50);
                } else if (buttons[i][j].getValue() == 16) {
                    buttons[i][j].setBackgroundColor(getResources().getColor(R.color.colorYellow600));
                    buttons[i][j].setTextColor(getResources().getColor(R.color.colorBlack));
                    buttons[i][j].setTextSize(50);
                } else if (buttons[i][j].getValue() == 32) {
                    buttons[i][j].setBackgroundColor(getResources().getColor(R.color.colorYellow700));
                    buttons[i][j].setTextColor(getResources().getColor(R.color.colorBlack));
                    buttons[i][j].setTextSize(50);
                } else if (buttons[i][j].getValue() == 64) {
                    buttons[i][j].setBackgroundColor(getResources().getColor(R.color.colorYellow800));
                    buttons[i][j].setTextColor(getResources().getColor(R.color.colorBlack));
                    buttons[i][j].setTextSize(50);
                } else if (buttons[i][j].getValue() == 128) {
                    buttons[i][j].setBackgroundColor(getResources().getColor(R.color.colorRed500));
                    buttons[i][j].setTextSize(40);
                    buttons[i][j].setTextColor(getResources().getColor(R.color.colorWhite));
                }else if(buttons[i][j].getValue() == 256) {
                    buttons[i][j].setBackgroundColor(getResources().getColor(R.color.colorRed600));
                    buttons[i][j].setTextSize(40);
                    buttons[i][j].setTextColor(getResources().getColor(R.color.colorWhite));
                }else if(buttons[i][j].getValue() == 512) {
                    buttons[i][j].setBackgroundColor(getResources().getColor(R.color.colorRed700));
                    buttons[i][j].setTextSize(40);
                    buttons[i][j].setTextColor(getResources().getColor(R.color.colorWhite));
                }else if(buttons[i][j].getValue() == 1024) {
                    buttons[i][j].setBackgroundColor(getResources().getColor(R.color.colorRed800));
                    buttons[i][j].setTextSize(30);
                    buttons[i][j].setTextColor(getResources().getColor(R.color.colorWhite));
                }else if(buttons[i][j].getValue() >= 2048) {
                    buttons[i][j].setBackgroundColor(getResources().getColor(R.color.colorRed900));
                    buttons[i][j].setTextSize(30);
                    buttons[i][j].setTextColor(getResources().getColor(R.color.colorWhite));
                }
            }
        }
    }

    boolean endGame() {
        int count = 0;
        for (int i = 0; i < fieldSize; i++) {
            for (int j = 0; j < fieldSize; j++) {
                if (i > 0) {
                    if (buttons[i][j].getValue() == buttons[i - 1][j].getValue() || buttons[i - 1][j].getValue() == 0) {
                        count++;
                    }
                }
                if (i < 3) {
                    if (buttons[i][j].getValue() == buttons[i + 1][j].getValue() || buttons[i + 1][j].getValue() == 0) {
                        count++;
                    }
                }
                if (j > 0) {
                    if (buttons[i][j].getValue() == buttons[i][j - 1].getValue() || buttons[i][j - 1].getValue() == 0) {
                        count++;
                    }
                }
                if (j < 3) {
                    if (buttons[i][j].getValue() == buttons[i][j + 1].getValue() || buttons[i][j + 1].getValue() == 0) {
                        count++;
                    }
                }
            }
        }
        textView2.setText("" + count);
        if (count > 0) {

            return true;

        } else return false;
    }

    void gameOver() {


        newGame++;
        buttons[1][0].setText("G");
        buttons[1][1].setText("A");
        buttons[1][2].setText("M");
        buttons[1][3].setText("E");
        buttons[2][0].setText("O");
        buttons[2][1].setText("V");
        buttons[2][2].setText("E");
        buttons[2][3].setText("R");
        buttons[0][0].setText("");
        buttons[0][1].setText("");
        buttons[0][2].setText("");
        buttons[0][3].setText("");
        buttons[3][0].setText("");
        buttons[3][1].setText("");
        buttons[3][2].setText("");
        buttons[3][3].setText("");


    }





    @Override
    public void onAnimationStart(Animation animation) {

    }

    @Override
    public void onAnimationEnd(Animation animation) {
        correctView();


    }

    @Override
    public void onAnimationRepeat(Animation animation) {

    }
}
