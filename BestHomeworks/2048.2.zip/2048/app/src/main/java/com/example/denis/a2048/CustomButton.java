package com.example.denis.a2048;

import android.content.Context;




public class CustomButton extends android.support.v7.widget.AppCompatButton {

    public int getXx() {
        return xx;
    }

    public void setXx(int xx) {
        this.xx = xx;
    }

    public int getXxx() {
        return xxx;
    }

    public void setXxx(int xxx) {
        this.xxx = xxx;
    }

    public int getYy() {
        return yy;
    }

    public void setYy(int yy) {
        this.yy = yy;
    }

    public int getYyy() {
        return yyy;
    }

    public void setYyy(int yyy) {
        this.yyy = yyy;
    }

    public int getValue() {
        return value;
    }

    public void setValue(int value) {
        this.value = value;
    }

    int xx, xxx, yy, yyy, value;

    public CustomButton(Context context, int xx, int xxx, int yy, int yyy, int value) {
        super(context);
        this.xx = xx;
        this.xxx = xxx;
        this.yy = yy;
        this.yyy = yyy;
        this.value = value;
    }
}
