package com.borovskoy.autosale;

import android.support.v7.util.DiffUtil;

import com.borovskoy.autosale.model.Car;

import java.util.List;


public class CarDiffCallback extends DiffUtil.Callback {

    private List<Car> oldList;
    private List<Car> newList;

    public CarDiffCallback(List<Car> oldList, List<Car> newList) {
        this.oldList = oldList;
        this.newList = newList;
    }

    @Override
    public int getOldListSize() {
        return oldList.size();
    }

    @Override
    public int getNewListSize() {
        return newList.size();
    }

    @Override
    public boolean areItemsTheSame(int oldItemPosition, int newItemPosition) {
        Car old = oldList.get(oldItemPosition);
        Car _new = newList.get(newItemPosition);
        return old.getId() == _new.getId();
    }

    @Override
    public boolean areContentsTheSame(int oldItemPosition, int newItemPosition) {
        return oldList.get(oldItemPosition).equals(newList.get(newItemPosition));
    }
}
