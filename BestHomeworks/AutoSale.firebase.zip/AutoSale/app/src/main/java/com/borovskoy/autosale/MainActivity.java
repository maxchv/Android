package com.borovskoy.autosale;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.borovskoy.autosale.adapter.CarAdapter;
import com.borovskoy.autosale.model.*;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import static android.content.ContentValues.TAG;

public class MainActivity extends AppCompatActivity {

    public static final String TAG = "TAG";
    public static final int REQUEST_CODE = 101;
    private CarAdapter adapter;
    private TextView mShowSearchAuto;
    private RecyclerView recyclerView;
    private List<Car> searchCarList, mGarage;
    private Toolbar toolbar;
    private Menu menu;
    private String model = "";
    private String brand = "";
    private String yearFrom, yearTo;
    private Set<String> mBrandsSet, mModelSet;
    private List<String> mYearList;
    private int costTo, costFrom;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

//        Garage.getInstance();
        recyclerView = findViewById(R.id.recyclerView);
        toolbar = findViewById(R.id.toolBar);
        setSupportActionBar(toolbar);
        mGarage = new ArrayList<>();

        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        menu = toolbar.getMenu();
        FirebaseDatabase database = FirebaseDatabase.getInstance();

        DatabaseReference myRef = database.getReference().child("Cars");
        myRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                for (DataSnapshot singleSnapshot : dataSnapshot.getChildren()) {
                    String carId = singleSnapshot.getKey();
                    Car snapshot = singleSnapshot.getValue(Car.class);
                    snapshot.setId(carId);
                    mGarage.add(snapshot);
                    int count = adapter.getItemCount();
                    adapter.notifyItemInserted(count - 1);
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                Toast.makeText(MainActivity.this, "Error, please try again", Toast.LENGTH_SHORT).show();
            }
        });

        adapter = new CarAdapter(mGarage);
        recyclerView.setAdapter(adapter);


    }

    @Override
    protected void onResume() {
        super.onResume();
        DatabaseReference connectedRef = FirebaseDatabase.getInstance().getReference(".info/connected");
        connectedRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                boolean connected = snapshot.getValue(Boolean.class);
                if (connected) {
                    Log.d(TAG, "onDataChange: connected");
                    Toast.makeText(MainActivity.this, "connected", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(MainActivity.this, "Internet not connected", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(DatabaseError error) {
                Log.e(TAG, "Listener was cancelled", error.toException());
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.menu_search:
                showSearchDialog();
                break;
            case R.id.menu_cancel:
                changedMenu(false, getString(R.string.app_name));
                adapter.swapList(searchCarList, mGarage);
            default:
                break;
        }
        return super.onOptionsItemSelected(item);
    }

//    @Override
//    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
//        super.onActivityResult(requestCode, resultCode, data);
//        if (resultCode == RESULT_OK) {
//            switch (requestCode) {
//                case REQUEST_CODE:
//                    Bundle bundleCarList = data.getExtras();
////                    searchCar = new ArrayList<>();
//
////                    searchCar = bundleCarList.getParcelableArrayList(CarSearchActivity.SEARCH_CAR_LIST);
//
////                    changedMenu(true, getString(R.string.search_results)
////                            + " (" + searchCar.size() + " items)");
//                    adapter.swapList(Garage.getInstance().getCars(), searchCarList);
//                    break;
//                default:
//                    break;
//            }
//        }
//    }

    private void changedMenu(boolean b, String s) {
        MenuItem itemCancel = menu.findItem(R.id.menu_cancel);
        itemCancel.setVisible(b);
        MenuItem itemSearch = menu.findItem(R.id.menu_search);
        itemSearch.setVisible(!b);
        toolbar.setTitle(s);
    }

    private void showSearchDialog() {
        View dialogLayout = LayoutInflater.from(this).inflate(R.layout.search_dialog, null);

        AutoCompleteTextView mAutoTextBrand = dialogLayout.findViewById(R.id.autoTextBrand);
        AutoCompleteTextView mAutoTextModel = dialogLayout.findViewById(R.id.autoTextModel);
        final Spinner mSpinnerYearTo = dialogLayout.findViewById(R.id.spinnerYearTo);
        final Spinner mSpinnerYearFrom = dialogLayout.findViewById(R.id.spinnerYearFrom);
        mShowSearchAuto = dialogLayout.findViewById(R.id.tvShowSearch);
        EditText mEtextCostFrom = dialogLayout.findViewById(R.id.eTextCostFrom);
        EditText mEtextCostTo = dialogLayout.findViewById(R.id.eTextCostTo);
        costTo =Integer.MAX_VALUE;
        costFrom = 0;
        model = "";
        brand = "";
        yearFrom = "";
        yearTo = "";
        mBrandsSet = new TreeSet<>();
        mModelSet = new TreeSet<>();
        mYearList = new ArrayList<>();
        searchCarList = new ArrayList<>();
        List<Car> originalList = mGarage;

        parseBrandModelYear(originalList);
        Collections.sort(mYearList);
        mYearList.add(0, "");
        filterCars();
        mAutoTextBrand.setAdapter(new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1, new ArrayList<>(mBrandsSet)));

        mAutoTextBrand.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                brand = s.toString().toLowerCase();
                filterCars();
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });

        mAutoTextModel.setAdapter(new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1, new ArrayList<>(mModelSet)));
        mAutoTextModel.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                model = s.toString().toLowerCase();
                filterCars();
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        final ArrayAdapter<String> spinnerAdapter = new ArrayAdapter(this,
                android.R.layout.simple_spinner_item, mYearList);
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        mSpinnerYearFrom.setAdapter(spinnerAdapter);
        mSpinnerYearFrom.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String year = spinnerAdapter.getItem(position);
                if (!year.isEmpty() && !yearTo.isEmpty()) {
                    if (Integer.parseInt(year) > Integer.parseInt(yearTo)) {
                        mSpinnerYearTo.setSelection(position);
                    }
                }
                yearFrom = spinnerAdapter.getItem(position);
                filterCars();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                yearFrom = (String) mSpinnerYearFrom.getSelectedItem();
                filterCars();
            }
        });

        mSpinnerYearTo.setAdapter(spinnerAdapter);
        mSpinnerYearTo.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String year = spinnerAdapter.getItem(position);
                if (!year.isEmpty() && !yearFrom.isEmpty()) {
                    if (Integer.parseInt(year) < Integer.parseInt(yearFrom)) {
                        mSpinnerYearFrom.setSelection(position);
                    }
                }
                yearTo = spinnerAdapter.getItem(position);
                filterCars();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                yearTo = (String) mSpinnerYearTo.getSelectedItem();
                filterCars();
            }
        });

        yearFrom = (String) mSpinnerYearFrom.getSelectedItem();
        yearTo = (String) mSpinnerYearTo.getSelectedItem();

        mEtextCostFrom.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

                if (s.length() != 0) {
                    costFrom = Integer.parseInt(s.toString());
                } else {
                    costFrom = 0;
                }
                filterCars();
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });

        mEtextCostTo.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (s.length() != 0) {
                    costTo = Integer.parseInt(s.toString());
                } else {
                    costTo = Integer.MAX_VALUE;
                }
                filterCars();
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setView(dialogLayout)
                .setTitle(R.string.car_search)
                .setCancelable(false)
                .setPositiveButton(R.string.search, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        adapter.swapList(mGarage, searchCarList);
                        changedMenu(true, getString(R.string.search_results)
                                + " (" + searchCarList.size() + " items)");
                    }
                })
                .setNegativeButton(android.R.string.cancel, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.cancel();
                    }
                });

        AlertDialog dialog = builder.create();
        dialog.show();
    }

    private void parseBrandModelYear(List<Car> parseList) {
        for (int i = 0; i < parseList.size(); i++) {
            String brand = parseList.get(i).getBrand();
            String model = parseList.get(i).getModel();
            String year = parseList.get(i).getYear();
            if (!mYearList.contains(year)) {
                mYearList.add(year);
            }
            mBrandsSet.add(brand);
            mModelSet.add(model);
        }
    }

    private void filterCars() {
        searchCarList.clear();
        searchCarList.addAll(mGarage);
        if (!brand.isEmpty()) {
            for (int i = searchCarList.size() - 1; i >= 0; i--) {
                if (searchCarList.get(i).getBrand().toLowerCase().indexOf(brand) == -1) {
                    searchCarList.remove(i);
                }
            }
        }

        if (!model.isEmpty()) {
            for (int i = searchCarList.size() - 1; i >= 0; i--) {
                if (searchCarList.get(i).getModel().toLowerCase().indexOf(model) == -1) {
                    searchCarList.remove(i);
                }
            }
        }
        if (!yearFrom.isEmpty() || !yearTo.isEmpty()) {
            for (int i = searchCarList.size() - 1; i >= 0; i--) {
                Car c = searchCarList.get(i);
                if (!yearFrom.isEmpty() && !yearTo.isEmpty()) {
                    if (Integer.parseInt(c.getYear()) < Integer.parseInt(yearFrom) ||
                            Integer.parseInt(c.getYear()) > Integer.parseInt(yearTo)) {
                        searchCarList.remove(i);
                    }
                } else if (!yearFrom.isEmpty()) {
                    if (Integer.parseInt(c.getYear()) < Integer.parseInt(yearFrom)) {
                        searchCarList.remove(i);
                    }
                } else if (!yearTo.isEmpty()) {
                    if (Integer.parseInt(c.getYear()) > Integer.parseInt(yearTo)) {
                        searchCarList.remove(i);
                    }
                }
            }
        }

        if (costFrom > 0 | costTo > 0) {
            for (int i = searchCarList.size() - 1; i >= 0; i--) {
                if (searchCarList.get(i).getCost() < costFrom || searchCarList.get(i).getCost() > costTo) {
                    searchCarList.remove(i);
                }
            }
        }
        mShowSearchAuto.setText(String.valueOf(searchCarList.size()) + " " + getString(R.string.matches));
    }
}
