package com.borovskoy.autosale.model;


import android.os.Parcel;
import android.os.Parcelable;

import com.google.firebase.database.Exclude;
import com.google.firebase.database.IgnoreExtraProperties;

import java.util.HashMap;
import java.util.Map;

@IgnoreExtraProperties
public class Car implements Parcelable {

    private String mBrand;
    private String mModel;
    private String mYear;
    private String mDescription;
    private int mCost;
    private String id;
    private String mPhotoUrl;

    public Car() {
    }

    public Car(String mBrand, String mModel, String mYear, String mDescription, int mCost, String mPhotoUrl) {
        this.mBrand = mBrand;
        this.mModel = mModel;
        this.mYear = mYear;
        this.mDescription = mDescription;
        this.mCost = mCost;
        this.mPhotoUrl = mPhotoUrl;
    }

    protected Car(Parcel in) {
        mBrand = in.readString();
        mModel = in.readString();
        mYear = in.readString();
        mDescription = in.readString();
        mCost = in.readInt();
        id = in.readString();
        mPhotoUrl = in.readString();
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(mBrand);
        dest.writeString(mModel);
        dest.writeString(mYear);
        dest.writeString(mDescription);
        dest.writeInt(mCost);
        dest.writeString(id);
        dest.writeString(mPhotoUrl);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<Car> CREATOR = new Creator<Car>() {
        @Override
        public Car createFromParcel(Parcel in) {
            return new Car(in);
        }

        @Override
        public Car[] newArray(int size) {
            return new Car[size];
        }
    };

    @Exclude
    public Map<String, Object> toMap(){
        HashMap<String, Object> result = new HashMap<>();
        result.put("mBrand", mBrand);
        result.put("mModel",mModel);
        result.put("mYear", mYear);
        result.put("mDescription", mDescription);
        result.put("mCost", mCost);
        result.put("mPhotoUrl", mPhotoUrl);
        result.put("id", id);
        return result;
    }

    public String getBrand() {
        return mBrand;
    }

    public void setBrand(String mBrand) {
        this.mBrand = mBrand;
    }

    public String getModel() {
        return mModel;
    }

    public void setModel(String mModel) {
        this.mModel = mModel;
    }

    public String getYear() {
        return mYear;
    }

    public void setYear(String mYear) {
        this.mYear = mYear;
    }

    public String getDescription() {
        return mDescription;
    }

    public void setDescription(String mDescription) {
        this.mDescription = mDescription;
    }

    public int getCost() {
        return mCost;
    }

    public void setCost(int mCost) {
        this.mCost = mCost;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPhotoUrl() {
        return mPhotoUrl;
    }

    public void setPhotoUrl(String mPhotoUrl) {
        this.mPhotoUrl = mPhotoUrl;
    }
}