package com.borovskoy.autosale.adapter;

import android.content.Context;
import android.support.v7.util.DiffUtil;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.borovskoy.autosale.CarDiffCallback;
import com.borovskoy.autosale.R;
import com.borovskoy.autosale.model.Car;
import com.bumptech.glide.Glide;

import java.util.List;

public class CarAdapter extends RecyclerView.Adapter<CarAdapter.ViewHolder> {

    private List<Car> mCarList;
    private Context context;

    public CarAdapter(List<Car> carList) {
        mCarList = carList;

    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        context = parent.getContext();
        View viewItem = LayoutInflater.from(parent.getContext()).inflate(
                R.layout.item_auto, parent, false);
        return new ViewHolder(viewItem);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        Car car = mCarList.get(position);
        Glide.with(context).load(car.getPhotoUrl()).into(holder.photo);
        holder.brand.setText(car.getBrand());
        holder.model.setText(car.getModel());
        holder.year.setText(String.valueOf(car.getYear()));
        holder.description.setText(car.getDescription());
        holder.cost.setText(String.valueOf(car.getCost()));

    }

    @Override
    public int getItemCount() {
        return mCarList.size();
    }

    public void swapList(List<Car> cars, List<Car> searchCar) {
        DiffUtil.Callback callback = new CarDiffCallback(cars, searchCar);
        DiffUtil.DiffResult result = DiffUtil.calculateDiff(callback);
        mCarList = searchCar;
        result.dispatchUpdatesTo(this);
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView photo;
        TextView brand;
        TextView model;
        TextView year;
        TextView description;
        TextView cost;

        public ViewHolder(View itemView) {
            super(itemView);
            photo = itemView.findViewById(R.id.imegeViewPhoto);
            brand = itemView.findViewById(R.id.textBrand);
            model = itemView.findViewById(R.id.textModel);
            year = itemView.findViewById(R.id.textYear);
            description = itemView.findViewById(R.id.textDescription);
            cost = itemView.findViewById(R.id.textCost);
        }
    }
}
