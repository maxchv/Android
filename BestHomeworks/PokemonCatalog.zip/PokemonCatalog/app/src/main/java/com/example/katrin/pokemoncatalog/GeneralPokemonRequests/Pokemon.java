package com.example.katrin.pokemoncatalog.GeneralPokemonRequests;

import java.io.Serializable;
import java.util.List;

public class Pokemon implements Serializable {

    private String name;
    private String url;
    private List<Forms> forms;

    protected int getId() {
        String id = url.replaceAll(".*\\/(\\d+)\\/$", "$1");
        return Integer.parseInt(id);
    }

    String getImageUrl() {
        if (forms != null) {
            url = forms.get(0).url;
        }
        return url.replaceAll(".*\\/(\\d+)\\/$", "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/$1.png");
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    void setUrl(String url) {
        this.url = url;
    }

    private class Forms {
        private String url;
    }
}

// https://pokeapi.co/api/v2/pokemon/8/
// \/(\d+)\/$
