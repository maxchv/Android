package com.example.katrin.pokemoncatalog.GeneralPokemonRequests;


import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface PokemonListService {

    @GET("api/v2/pokemon")
    Call<APIResponseObject> getPokemons(@Query("limit") int limit);

    @GET("api/v2/pokemon/{name}")
    Call<Pokemon> getPokemonByNameOrId(@Path("name") String nameOrId);


}
