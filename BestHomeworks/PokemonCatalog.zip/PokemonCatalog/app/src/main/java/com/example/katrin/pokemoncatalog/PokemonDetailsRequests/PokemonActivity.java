package com.example.katrin.pokemoncatalog.PokemonDetailsRequests;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.example.katrin.pokemoncatalog.GeneralPokemonRequests.PokemonRecycler;
import com.example.katrin.pokemoncatalog.R;
import com.squareup.picasso.Picasso;

import java.util.Observable;
import java.util.Observer;

public class PokemonActivity extends AppCompatActivity implements Observer {

    private static final int DEFAULT_ID = -1;
    private PokemonDetails pokemon;
    private TextView name;
    private ImageView imageView;
    private ProgressBar speed;
    private ProgressBar defense;
    private ProgressBar hp;
    private ProgressBar attack;
    private View loading;
    private View contentView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pokemon);

        name = findViewById(R.id.pokemon_name);
        imageView = findViewById(R.id.pokemon_image);
        speed = findViewById(R.id.pokemon_speed);
        defense = findViewById(R.id.pokemon_defense);
        hp = findViewById(R.id.pokemon_hp);
        attack = findViewById(R.id.pokemon_attack);
        loading = findViewById(R.id.loading_progress_bar);
        contentView = findViewById(R.id.pokemon_content);
        contentView.setVisibility(View.GONE);
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
    }

    @Override
    protected void onPause() {
        PokemonDetailsRegister.getInstance(DEFAULT_ID).deleteObserver(this);
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        int pokemonId = getIntent().getIntExtra(PokemonRecycler.POKEMON_ID, DEFAULT_ID);
        PokemonDetailsRegister.getInstance(pokemonId).addObserver(this);
    }

    @Override
    public void update(Observable observable, Object o) {
        if (o != null) {
            pokemon = (PokemonDetails) o;
            initViewsWithData();
            animateProgress();

        }
    }

    private void animateProgress() {
        contentView.setAlpha(0f);
        contentView.setVisibility(View.VISIBLE);
        contentView.animate()
                .alpha(1f)
                .setDuration(getResources().getInteger(android.R.integer.config_longAnimTime))
                .setListener(null);
        loading.animate()
                .alpha(0f)
                .setDuration(getResources().getInteger(android.R.integer.config_longAnimTime))
                .setListener(new AnimatorListenerAdapter() {
                    @Override
                    public void onAnimationEnd(Animator animation) {
                        loading.setVisibility(View.GONE);
                    }
                });
    }

    private void initViewsWithData() {
        name.setText(pokemon.name);
        Picasso.with(this).load(pokemon.imageUrl).into(imageView);
        speed.setProgress(pokemon.speed);
        defense.setProgress(pokemon.defense);
        hp.setProgress(pokemon.hp);
        attack.setProgress(pokemon.attack);
    }
}
