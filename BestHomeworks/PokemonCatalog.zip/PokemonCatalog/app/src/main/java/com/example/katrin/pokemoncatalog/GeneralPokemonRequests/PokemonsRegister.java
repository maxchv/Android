package com.example.katrin.pokemoncatalog.GeneralPokemonRequests;

import android.support.annotation.NonNull;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;
import java.util.Observable;
import java.util.Observer;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class PokemonsRegister extends Observable {

    private static final int LIMIT = 100;
    private static PokemonsRegister instance;
    private List<Pokemon> pokemons;
    private String pokemonQuery;

    private PokemonsRegister() {
    }

    static PokemonsRegister getInstance() {
        if (instance == null) {
            instance = new PokemonsRegister();
        }
        return instance;
    }

    void setPokemonQuery(String pokemonQuery) {

        if ("".equals(pokemonQuery)) {
            this.pokemonQuery = null;
        } else {
            this.pokemonQuery = pokemonQuery;
            requestPokemonsFromApi(this.pokemonQuery);
        }
    }

    @Override
    public synchronized void addObserver(Observer o) {
        super.addObserver(o);

        if (pokemons != null) {
            o.update(this, pokemons);
        } else {
            requestPokemonsFromApi(null);
        }
    }

    private void requestPokemonsFromApi(final String queryParameter) {

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("http://pokeapi.co")
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        PokemonListService pokemonListService = retrofit.create(PokemonListService.class);

        if (queryParameter == null) {

            pokemonListService.getPokemons(LIMIT).enqueue(new Callback<APIResponseObject>() {
                @Override
                public void onResponse(@NonNull Call<APIResponseObject> call, @NonNull Response<APIResponseObject> response) {

                    if (pokemonQuery != null) {
                        return;
                    }
                    APIResponseObject apiObject = response.body();
                    if (apiObject != null) {
                        pokemons = apiObject.getResults();
                    }
                    setChanged();
                    notifyObservers(pokemons);
                }

                @Override
                public void onFailure(@NonNull Call<APIResponseObject> call, @NonNull Throwable t) {

                }
            });
        } else {

            pokemonListService.getPokemonByNameOrId(queryParameter).enqueue(new Callback<Pokemon>() {
                @Override
                public void onResponse(@NonNull Call<Pokemon> call, @NonNull Response<Pokemon> response) {
                    if (pokemonQuery != null && queryParameter.equals(pokemonQuery)) {
                        Pokemon apiPokemon = response.body();
                        if (apiPokemon != null) {
                            pokemons = new ArrayList<>();
                            pokemons.add(apiPokemon);
                            Log.i("PokemonsRegister", "onResponse: query = " + queryParameter);
                        }
                        setChanged();
                        notifyObservers(pokemons);
                    }
                }

                @Override
                public void onFailure(@NonNull Call<Pokemon> call, @NonNull Throwable t) {

                }
            });
        }
    }
}
