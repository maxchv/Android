package com.example.katrin.pokemoncatalog.PokemonDetailsRequests;

import android.support.annotation.NonNull;

import java.util.Observable;
import java.util.Observer;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class PokemonDetailsRegister extends Observable {

    private static PokemonDetailsRegister detailsRegister;
    private int id;
    private PokemonDetails pokemon;

    static PokemonDetailsRegister getInstance(int id) {


        if (detailsRegister == null) {
            detailsRegister = new PokemonDetailsRegister();
        }

        if (detailsRegister.id > 0 && detailsRegister.id != id) {
            detailsRegister.pokemon = null;
        }


        detailsRegister.id = id;
        return detailsRegister;
    }

    private void requestPokemonsDetailsFromApi(final int id) {

        if (id > 0) {
            Retrofit retrofit = new Retrofit.Builder()
                    .baseUrl("http://pokeapi.co")
                    .addConverterFactory(GsonConverterFactory.create())
                    .build();
            PokemonDetailsService detailsService = retrofit.create(PokemonDetailsService.class);
            detailsService.getPokemonById(id).enqueue(new Callback<ApiResponsePokemonDetails>() {
                @Override
                public void onResponse(@NonNull Call<ApiResponsePokemonDetails> call, @NonNull Response<ApiResponsePokemonDetails> response) {
                    if (PokemonDetailsRegister.this.id != id) {
                        return;
                    }

                    ApiResponsePokemonDetails details = response.body();
                    if (details != null) {
                        pokemon = new PokemonDetails();
                        pokemon.name = details.name;
                        pokemon.imageUrl = details.getImageUrl();
                        for (ApiResponsePokemonDetails.Stats stat : details.stats) {
                            if ("attack".equals(stat.getStatName())) {
                                pokemon.attack = stat.getBaseStat();
                            }
                            if ("defense".equals(stat.getStatName())) {
                                pokemon.defense = stat.getBaseStat();
                            }
                            if ("speed".equals(stat.getStatName())) {
                                pokemon.speed = stat.getBaseStat();
                            }
                            if ("hp".equals(stat.getStatName())) {
                                pokemon.hp = stat.getBaseStat();
                            }
                        }
                    }
                    setChanged();
                    notifyObservers(pokemon);
                }

                @Override
                public void onFailure(@NonNull Call<ApiResponsePokemonDetails> call, @NonNull Throwable t) {

                }
            });

        }
    }

    @Override
    public synchronized void addObserver(Observer o) {
        super.addObserver(o);
        if (pokemon != null) {
            o.update(this, pokemon);
        } else {
            requestPokemonsDetailsFromApi(id);
        }
    }
}
