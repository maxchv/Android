package com.example.katrin.pokemoncatalog.PokemonDetailsRequests;


import com.google.gson.annotations.SerializedName;

import java.util.List;

class ApiResponsePokemonDetails {
    String name;
    List<Stats> stats;
    private Sprites sprites;

    String getImageUrl() {
        return sprites.image;
    }

    class Stats {

        private Stat stat;
        private int base_stat;

        String getStatName() {
            return stat.name;
        }
        int getBaseStat() {
            return base_stat;
        }

        private class Stat {
            String name;
        }
    }

    private class Sprites {
        @SerializedName("front_default")
        String image;
    }
}
