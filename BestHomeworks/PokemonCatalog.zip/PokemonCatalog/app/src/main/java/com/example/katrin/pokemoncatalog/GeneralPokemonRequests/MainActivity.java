package com.example.katrin.pokemoncatalog.GeneralPokemonRequests;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.Menu;
import android.view.View;
import android.widget.SearchView;

import com.example.katrin.pokemoncatalog.R;
import com.jakewharton.rxbinding.widget.RxSearchView;
import com.jakewharton.rxbinding.widget.SearchViewQueryTextEvent;

import java.io.Serializable;
import java.util.List;
import java.util.Observable;
import java.util.Observer;

import rx.Subscription;
import rx.functions.Action1;

public class MainActivity extends AppCompatActivity implements Observer {
    public static final String MODEL = "Model";
    private Model model;
    private PokemonRecycler recycler;
    private RecyclerView recyclerView;
    private Subscription searchViewSubscription;
    private View loading;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        loading = findViewById(R.id.loading_progress_bar_main);
        if (savedInstanceState == null) {
            model = new Model();
        } else {
            model = (Model) savedInstanceState.getSerializable(MODEL);
        }
        PokemonsRegister.getInstance().setPokemonQuery(model.searchQueryText);
        recyclerView = findViewById(R.id.recycler_view);
        recyclerView.setVisibility(View.GONE);
        recycler = new PokemonRecycler(this);
        DividerItemDecoration decoration = new DividerItemDecoration(this, DividerItemDecoration.VERTICAL);
        recyclerView.addItemDecoration(decoration);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(recycler);
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putSerializable(MODEL, model);
    }

    @Override
    protected void onPause() {
        PokemonsRegister.getInstance().deleteObserver(this);
        searchViewSubscription.unsubscribe();
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        PokemonsRegister.getInstance().addObserver(this);
    }

    @Override
    public void update(Observable observable, Object o) {

        List<Pokemon> pokemons = (List<Pokemon>) o;
        recycler.setPokemons(pokemons);

        animateProgress();

    }

    private void animateProgress() {
        recyclerView.setAlpha(0f);
        recyclerView.setVisibility(View.VISIBLE);
        recyclerView.animate()
                .alpha(1f)
                .setDuration(getResources().getInteger(android.R.integer.config_longAnimTime))
                .setListener(null);
        loading.animate()
                .alpha(0f)
                .setDuration(getResources().getInteger(android.R.integer.config_longAnimTime))
                .setListener(new AnimatorListenerAdapter() {
                    @Override
                    public void onAnimationEnd(Animator animation) {
                        loading.setVisibility(View.GONE);
                    }
                });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.search_menu, menu);
        final SearchView searchView = (SearchView) menu.findItem(R.id.app_bar_search).getActionView();

        searchView.setQuery(model.searchQueryText, false);
        if (searchViewSubscription == null) {
            searchViewSubscription = RxSearchView.queryTextChangeEvents(searchView).subscribe(new Action1<SearchViewQueryTextEvent>() {
                @Override
                public void call(SearchViewQueryTextEvent searchViewQueryTextEvent) {

                    String query = searchViewQueryTextEvent.queryText().toString();
                    PokemonsRegister.getInstance().setPokemonQuery(query);
                    model.searchQueryText = query;
                }
            });
        }

        searchView.setOnCloseListener(new SearchView.OnCloseListener() {
            @Override
            public boolean onClose() {
                PokemonsRegister.getInstance().setPokemonQuery(null);
                return true;
            }
        });
        return true;
    }

    private static final class Model implements Serializable {

        String searchQueryText;

    }
}
