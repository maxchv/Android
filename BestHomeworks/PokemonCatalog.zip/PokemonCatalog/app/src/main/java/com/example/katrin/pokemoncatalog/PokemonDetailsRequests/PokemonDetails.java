package com.example.katrin.pokemoncatalog.PokemonDetailsRequests;

import com.example.katrin.pokemoncatalog.GeneralPokemonRequests.Pokemon;

class PokemonDetails extends Pokemon {
    String name;
    String imageUrl;
    int speed;
    int attack;
    int defense;
    int hp;
}

