package com.example.katrin.pokemoncatalog.PokemonDetailsRequests;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Path;

public interface PokemonDetailsService {

    @GET("api/v2/pokemon/{id}")
    Call<ApiResponsePokemonDetails> getPokemonById(@Path("id") int id);
}
