package com.borovskoy.autosale;

import com.borovskoy.autosale.model.Car;

import java.util.ArrayList;
import java.util.List;

public class Garage {
    private static Garage ourInstance;

    private List<Car> mGarage;

    static Garage getInstance() {
        if (ourInstance == null) {
            ourInstance = new Garage();
        }
        return ourInstance;
    }

    private Garage() {
        mGarage = new ArrayList<>();
    }

    public List<Car> getCars() {
        return mGarage;
    }

    public Car getCar(int ind) {
        return mGarage.get(ind);
    }

    public void addCar(Car car) {
        mGarage.add(car);
    }
}
