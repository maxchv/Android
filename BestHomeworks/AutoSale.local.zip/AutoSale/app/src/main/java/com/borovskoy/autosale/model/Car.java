package com.borovskoy.autosale.model;


import android.os.Parcel;
import android.os.Parcelable;

public class Car implements Parcelable {

    private String mBrand;
    private String mModel;
    private String mYear;
    private String mDescription;
    private int mCost;
    private int id;
    private int mPhotoId;
    private static int sCount = 0;

    public Car(String brand, String model, String year, String description, int cost, int photoId) {
        mBrand = brand;
        mModel = model;
        mYear = year;
        mDescription = description;
        mCost = cost;
        mPhotoId = photoId;
        id = sCount++;
    }

    protected Car(Parcel in) {
        mBrand = in.readString();
        mModel = in.readString();
        mYear = in.readString();
        mDescription = in.readString();
        mCost = in.readInt();
        id = in.readInt();
        mPhotoId = in.readInt();
    }

    public static final Creator<Car> CREATOR = new Creator<Car>() {
        @Override
        public Car createFromParcel(Parcel in) {
            return new Car(in);
        }

        @Override
        public Car[] newArray(int size) {
            return new Car[size];
        }
    };

    public String getBrand() {
        return mBrand;
    }

    public String getModel() {
        return mModel;
    }

    public String getYear() {
        return mYear;
    }

    public String getDescription() {
        return mDescription;
    }

    public int getCost() {
        return mCost;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getPhotoId() {
        return mPhotoId;
    }

    @Override
    public String toString() {
        return " " + mBrand + " " + mModel + " " + mYear + " " + mCost;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(mBrand);
        dest.writeString(mModel);
        dest.writeString(mYear);
        dest.writeString(mDescription);
        dest.writeInt(mCost);
        dest.writeInt(id);
        dest.writeInt(mPhotoId);
    }
}
