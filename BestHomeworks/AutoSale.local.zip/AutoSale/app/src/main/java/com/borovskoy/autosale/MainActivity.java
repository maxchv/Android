package com.borovskoy.autosale;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;

import com.borovskoy.autosale.adapter.CarAdapter;
import com.borovskoy.autosale.model.*;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    public static final int REQUEST_CODE = 101;
    private CarAdapter adapter;
    private RecyclerView recyclerView;
    private List<Car> searchCar;
    private Toolbar toolbar;
    private Menu menu;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        toolbar = (Toolbar) findViewById(R.id.toolBar);
        setSupportActionBar(toolbar);

        Garage.getInstance().addCar(new Car("Mersedes", "A180", "2015", "Color - Black", 15000, R.drawable.mers));
        Garage.getInstance().addCar(new Car("Vw", "Beetle", "2009", "Color - Brown", 10000, R.drawable.beetle));
        Garage.getInstance().addCar(new Car("Audi", "A4", "2001", "Color - Black", 5000, R.drawable.a4));
        Garage.getInstance().addCar(new Car("BMW", "X6", "2017", "Color - Blue", 95000, R.drawable.bmw_x6));
        Garage.getInstance().addCar(new Car("Toyota", "Camry", "2017", "Color - White", 35000, R.drawable.camry));
        Garage.getInstance().addCar(new Car("Ford", "Explorer", "2015", "Color - Rad", 47000, R.drawable.explorer));
        Garage.getInstance().addCar(new Car("Lada", "Kalina", "2014", "Color - Black", 7400, R.drawable.kalina));
        Garage.getInstance().addCar(new Car("Mazda", "RX-5", "2015", "Color - Rad, AT", 26000, R.drawable.mazda));
        Garage.getInstance().addCar(new Car("Audi", "A4", "2001", "Color - Black, AT", 5500, R.drawable.a4));
        Garage.getInstance().addCar(new Car("Porsche", "Cayenne", "2011", "Color - White, AT", 32000, R.drawable.porsche));
        Garage.getInstance().addCar(new Car("Renault", "Clio", "2014", "Color - Blue, new rims", 13000, R.drawable.renault));
        Garage.getInstance().addCar(new Car("Porsche", "Cayenne GTS", "2012", "Color - White, 4.4L BiTurbo", 41000, R.drawable.porsche));
        Garage.getInstance().addCar(new Car("BMW", "X6", "2016", "Color - Blue", 75000, R.drawable.bmw_x6));
        Garage.getInstance().addCar(new Car("Skoda", "Roomster", "2007", "Color: Light - Blue, 120000 km", 11500, R.drawable.roomster));
        Garage.getInstance().addCar(new Car("Vw", "Scirocco", "2013", "Color: Dark-blue, AT , chip - tuning", 21000, R.drawable.scirocco));
        Garage.getInstance().addCar(new Car("Skoda", "Fabia Combi", "2017", "Color - White", 19300, R.drawable.skoda));
        Garage.getInstance().addCar(new Car("Suzuki", "Vitara", "2016", "Color: Blue-Black, Spacial edition", 26000, R.drawable.vitara));
        Garage.getInstance().addCar(new Car("Renge - Rover", "Evoque", "2014", "Color: Blue-White", 32700, R.drawable.voque));

        recyclerView = (RecyclerView) findViewById(R.id.recyclerView);
        adapter = new CarAdapter(Garage.getInstance().getCars());
        recyclerView.setAdapter(adapter);

        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        menu = toolbar.getMenu();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.menu_search:
                Intent intent = new Intent(MainActivity.this, CarSearchActivity.class);
                startActivityForResult(intent, REQUEST_CODE);
                break;
            case R.id.menu_cancel:
                changedMenu(false, getString(R.string.app_name));
                adapter.swapList(searchCar, Garage.getInstance().getCars());
            default:
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            switch (requestCode) {
                case REQUEST_CODE:
                    Bundle bundleCarList = data.getExtras();
                    searchCar = new ArrayList<>();

                    searchCar = bundleCarList.getParcelableArrayList(CarSearchActivity.SEARCH_CAR_LIST);

                    System.out.println(searchCar);
                    changedMenu(true, getString(R.string.search_results)
                            + " (" + searchCar.size() + " items)");
                    adapter.swapList(Garage.getInstance().getCars(), searchCar);
                    break;
                default:
                    break;
            }
        }
    }

    private void changedMenu(boolean b, String s) {
        MenuItem itemCancel = menu.findItem(R.id.menu_cancel);
        itemCancel.setVisible(b);
        MenuItem itemSearch = menu.findItem(R.id.menu_search);
        itemSearch.setVisible(!b);
        toolbar.setTitle(s);
    }
}
