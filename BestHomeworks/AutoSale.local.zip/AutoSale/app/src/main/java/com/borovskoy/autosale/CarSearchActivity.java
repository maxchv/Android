package com.borovskoy.autosale;

import android.content.Intent;
import android.os.Parcelable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

import com.borovskoy.autosale.model.Car;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

public class CarSearchActivity extends AppCompatActivity {

    public static final String SEARCH_CAR_LIST = "searchCarList";
    private AutoCompleteTextView mAutoTextBrand;
    private AutoCompleteTextView mAutoTextModel;
    private Spinner mSpinnerYearFrom;
    private Spinner mSpinnerYearTo;
    private EditText mEtextCostTo;
    private EditText mEtextCostFrom;
    private Button mShowSearchAuto;
    private Set<String> mBrandsSet;
    private Set<String> mModelSet;
    private List<String> mYearList;
    private String model = "", brand = "";
    private int costTo = -1, costFrom = -1;
    private String yearFrom = "", yearTo = "";
    private List<Car> searchCarList;
    private List<Car> originalList;
    private Intent mIntent;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_car_search);


        Toolbar toolbar = (Toolbar) findViewById(R.id.toolBar);
        setSupportActionBar(toolbar);

        List<Car> parseList = Garage.getInstance().getCars();
        mBrandsSet = new TreeSet<>();
        mModelSet = new TreeSet<>();
        mYearList = new ArrayList<>();
        searchCarList = new ArrayList<>();
        originalList = Garage.getInstance().getCars();

        mAutoTextBrand = (AutoCompleteTextView) findViewById(R.id.autoTextBrand);
        mAutoTextModel = (AutoCompleteTextView) findViewById(R.id.autoTextModel);
        mEtextCostFrom = (EditText) findViewById(R.id.eTextCostFrom);
        mEtextCostTo = (EditText) findViewById(R.id.eTextCostTo);
        mSpinnerYearTo = (Spinner) findViewById(R.id.spinnerYearTo);
        mSpinnerYearFrom = (Spinner) findViewById(R.id.spinnerYearFrom);
        mShowSearchAuto = (Button) findViewById(R.id.buttonShowSearch);
        mEtextCostFrom = (EditText) findViewById(R.id.eTextCostFrom);
        mEtextCostTo = (EditText) findViewById(R.id.eTextCostTo);

        parseBrandModelYear(parseList);
        Collections.sort(mYearList);
        mYearList.add(0, "");
        System.out.println(mYearList);
        filterCars();

        mAutoTextBrand.setAdapter(new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1, new ArrayList<>(mBrandsSet)));

        mAutoTextBrand.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                brand = s.toString().toLowerCase();
                filterCars();
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });

        mAutoTextModel.setAdapter(new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1, new ArrayList<>(mModelSet)));
        mAutoTextModel.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                model = s.toString().toLowerCase();
                filterCars();
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        final ArrayAdapter<String> spinnerAdapter = new ArrayAdapter(this,
                android.R.layout.simple_spinner_item, mYearList);
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        mSpinnerYearFrom.setAdapter(spinnerAdapter);
        mSpinnerYearFrom.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String year = spinnerAdapter.getItem(position);
                if (!year.isEmpty() && !yearTo.isEmpty()) {
                    if (Integer.parseInt(year) > Integer.parseInt(yearTo)) {
                        mSpinnerYearTo.setSelection(position);
                    }
                }
                yearFrom = spinnerAdapter.getItem(position);
                filterCars();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                yearFrom = (String) mSpinnerYearFrom.getSelectedItem();
                filterCars();
            }
        });

        mSpinnerYearTo.setAdapter(spinnerAdapter);
        mSpinnerYearTo.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String year = spinnerAdapter.getItem(position);
                if (!year.isEmpty() && !yearFrom.isEmpty()) {
                    if (Integer.parseInt(year) < Integer.parseInt(yearFrom)) {
                        mSpinnerYearFrom.setSelection(position);
                    }
                }
                yearTo = spinnerAdapter.getItem(position);
                filterCars();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                yearTo = (String) mSpinnerYearTo.getSelectedItem();
                filterCars();
            }
        });

        yearFrom = (String) mSpinnerYearFrom.getSelectedItem();
        yearTo = (String) mSpinnerYearTo.getSelectedItem();

        mEtextCostFrom.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

                if (s.length() != 0) {
                    costFrom = Integer.parseInt(s.toString());
                } else {
                    costFrom = 0;
                }
                filterCars();
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });

        mEtextCostTo.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (s.length() != 0) {
                    costTo = Integer.parseInt(s.toString());
                } else {
                    costTo = Integer.MAX_VALUE;
                }
                filterCars();
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });

        mShowSearchAuto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                System.out.println(searchCarList);
                mIntent = new Intent();
                Bundle bundle = new Bundle();
                bundle.putParcelableArrayList(SEARCH_CAR_LIST,
                        (ArrayList<? extends Parcelable>) searchCarList);
                mIntent.putExtras(bundle);
                setResult(RESULT_OK, mIntent);
                finish();
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.search_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.cancel:
                mIntent = new Intent();
                setResult(RESULT_CANCELED);
                finish();
                break;
            default:
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    private void parseBrandModelYear(List<Car> parseList) {
        for (int i = 0; i < parseList.size(); i++) {
            String brand = parseList.get(i).getBrand();
            String model = parseList.get(i).getModel();
            String year = parseList.get(i).getYear();
            if (!mYearList.contains(year)) {
                mYearList.add(year);
            }
            mBrandsSet.add(brand);
            mModelSet.add(model);
        }
    }

    private void filterCars() {
        searchCarList.clear();
        searchCarList.addAll(originalList);
        if (!brand.isEmpty()) {
            for (int i = searchCarList.size() - 1; i >= 0; i--) {
                if (searchCarList.get(i).getBrand().toLowerCase().indexOf(brand) == -1) {
                    searchCarList.remove(i);
                }
            }
        }

        if (!model.isEmpty()) {
            for (int i = searchCarList.size() - 1; i >= 0; i--) {
                if (searchCarList.get(i).getModel().toLowerCase().indexOf(model) == -1) {
                    searchCarList.remove(i);
                }
            }
        }
        if (!yearFrom.isEmpty() || !yearTo.isEmpty()) {
            for (int i = searchCarList.size() - 1; i >= 0; i--) {
                Car c = searchCarList.get(i);
                if (!yearFrom.isEmpty() && !yearTo.isEmpty()) {
                    if (Integer.parseInt(c.getYear()) < Integer.parseInt(yearFrom) ||
                            Integer.parseInt(c.getYear()) > Integer.parseInt(yearTo)) {
                        searchCarList.remove(i);
                    }
                } else if (!yearFrom.isEmpty()) {
                    if (Integer.parseInt(c.getYear()) < Integer.parseInt(yearFrom)) {
                        searchCarList.remove(i);
                    }
                } else if (!yearTo.isEmpty()) {
                    if (Integer.parseInt(c.getYear()) > Integer.parseInt(yearTo)) {
                        searchCarList.remove(i);
                    }
                }
            }
        }

        if (costFrom > 0 || costTo > 0) {
            for (int i = searchCarList.size() - 1; i >= 0; i--) {
                if (searchCarList.get(i).getCost() < costFrom || searchCarList.get(i).getCost() > costTo) {
                    searchCarList.remove(i);
                }
            }
        }

        mShowSearchAuto.setText(String.valueOf(searchCarList.size()) + " " + getString(R.string.matches));
    }
}
