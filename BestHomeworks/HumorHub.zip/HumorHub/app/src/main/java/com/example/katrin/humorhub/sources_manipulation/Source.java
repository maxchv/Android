package com.example.katrin.humorhub.sources_manipulation;


import com.google.gson.annotations.SerializedName;

public class Source {

    public String site;
    public String name;
    @SerializedName("desc")
    String description;

    @Override
    public boolean equals(Object obj) {
        if (obj instanceof Source) {
            Source source = (Source) obj;
            return source.name.equals(name) && source.site.equals(site);
        } else {
            return false;
        }
    }
}
