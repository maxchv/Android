package com.example.katrin.humorhub.sources_manipulation;

import android.support.annotation.NonNull;

import java.util.ArrayList;
import java.util.List;
import java.util.Observable;
import java.util.Observer;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.http.GET;


public class AvailableSourcesRegister extends Observable {

    private static AvailableSourcesRegister instance = new AvailableSourcesRegister();

    private List<Source> availableSources;

    private AvailableSourcesRegister() {
        getAvailableSourcesListFromAPI();
    }

    static AvailableSourcesRegister getInstance() {
        return instance;
    }

    private void getAvailableSourcesListFromAPI() {
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("http://umorili.herokuapp.com")
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        GetSourcesService sourcesService = retrofit.create(GetSourcesService.class);

        Call<List<List<Source>>> sourcesList = sourcesService.sourcesList();
        sourcesList.enqueue(new Callback<List<List<Source>>>() {
            @Override
            public void onResponse(@NonNull Call<List<List<Source>>> call, @NonNull Response<List<List<Source>>> response) {

                List<List<Source>> body = response.body();
                if (body != null) {

                    availableSources = new ArrayList<>();
                    for (List<Source> list : body) {
                        availableSources.addAll(list);
                    }

                    setChanged();
                    notifyObservers(availableSources);
                }
            }

            @Override
            public void onFailure(@NonNull Call<List<List<Source>>> call, @NonNull Throwable t) {

                getAvailableSourcesListFromAPI();
            }
        });
    }

    @Override
    public synchronized void addObserver(Observer o) {
        super.addObserver(o);
        o.update(this, availableSources);
    }

    public interface GetSourcesService {

        @GET("api/sources")
        Call<List<List<Source>>> sourcesList();
    }

}
