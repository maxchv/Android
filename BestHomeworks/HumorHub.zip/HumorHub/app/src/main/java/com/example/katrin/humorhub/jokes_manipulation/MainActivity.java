package com.example.katrin.humorhub.jokes_manipulation;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.Menu;
import android.view.MenuItem;

import com.example.katrin.humorhub.R;
import com.example.katrin.humorhub.sources_manipulation.SettingsActivity;

import java.util.List;
import java.util.Observable;
import java.util.Observer;

public class MainActivity extends AppCompatActivity implements Observer {

    private JokesRecycler jokesRecycler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        RecyclerView recyclerView = findViewById(R.id.jokes_recycler);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        DividerItemDecoration itemDivider = new DividerItemDecoration(this, layoutManager.getOrientation());
        recyclerView.addItemDecoration(itemDivider);
        jokesRecycler = new JokesRecycler(this);
        recyclerView.setAdapter(jokesRecycler);
    }

    @Override
    protected void onPause() {
        JokesRegister.getInstance(getApplication()).deleteObserver(this);
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        JokesRegister.getInstance(getApplication()).addObserver(this);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.source_settings, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {
            case R.id.source_settings:
                Intent intent = new Intent(this, SettingsActivity.class);
                startActivity(intent);
                return true;
        }

        return false;
    }

    @Override
    public void update(Observable observable, Object o) {

        List<Joke> jokesList = (List<Joke>) o;

        jokesRecycler.setJokesList(jokesList);
    }

}

