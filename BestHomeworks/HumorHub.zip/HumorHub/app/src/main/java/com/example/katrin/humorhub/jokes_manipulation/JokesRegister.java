package com.example.katrin.humorhub.jokes_manipulation;


import android.annotation.SuppressLint;
import android.app.Application;
import android.support.annotation.NonNull;

import com.example.katrin.humorhub.sources_manipulation.SelectedSourcesRegister;
import com.example.katrin.humorhub.sources_manipulation.Source;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Observable;
import java.util.Observer;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.http.GET;
import retrofit2.http.Query;

public class JokesRegister extends Observable implements Observer {
    @SuppressLint("StaticFieldLeak")
    private static JokesRegister instance;
    private Application context;
    private List<Joke> jokes;

    private JokesRegister(Application context) {
        this.context = context;
        SelectedSourcesRegister.getInstance(context).addObserver(this);
    }

    static JokesRegister getInstance(Application context) {
        if (instance == null) {
            instance = new JokesRegister(context);
        }
        return instance;
    }

    @Override
    public void update(Observable observable, Object o) {

        List<Source> selectedSources = (List<Source>) o;
        jokes = new ArrayList<>();

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("http://umorili.herokuapp.com")
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        GetJokesService service = retrofit.create(GetJokesService.class);

        Callback<List<Joke>> callback = new Callback<List<Joke>>() {
            @Override
            public void onResponse(@NonNull Call<List<Joke>> call, @NonNull Response<List<Joke>> response) {
                List<Joke> body = response.body();
                if (body != null) {
                    jokes.addAll(body);
                    Collections.shuffle(jokes);
                }

                setChanged();
                notifyObservers(jokes);
            }

            @Override
            public void onFailure(@NonNull Call<List<Joke>> call, @NonNull Throwable t) {

            }
        };

        if (selectedSources != null && selectedSources.size() > 0) {
            for (Source selectedSource : selectedSources) {

                Call<List<Joke>> call = service.getJokes(selectedSource.site, selectedSource.name);
                call.enqueue(callback);

            }
        } else {
            Call<List<Joke>> call = service.getJokes();
            call.enqueue(callback);
        }


    }

    @Override
    public synchronized void addObserver(Observer o) {
        super.addObserver(o);
        o.update(this, jokes);
    }

    interface GetJokesService {

        @GET("api/get")
        Call<List<Joke>> getJokes(@Query("site") String site,
                                  @Query("name") String name);

        @GET("api/get")
        Call<List<Joke>> getJokes();
    }
}
