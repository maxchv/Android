package com.example.katrin.humorhub.jokes_manipulation;

import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonParseException;
import com.google.gson.annotations.JsonAdapter;
import com.google.gson.annotations.SerializedName;

import java.lang.reflect.Type;

class Joke {

    @SerializedName("desc")
    String description;

    @JsonAdapter(HtmlFree.class)
    @SerializedName("elementPureHtml")
    String text;

    static class HtmlFree implements JsonDeserializer<String> {

        @Override
        public String deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context) throws JsonParseException {
            String html = json.getAsString();
            if (html != null) {
                return html
                        .replaceAll("<br />", "")
                        .replaceAll("&quot;", "'")
                        .replaceAll("&lt;", "<")
                        .replaceAll("&gt;", ">")
                        .replaceAll("&raquo;", ">>")
                        .replaceAll("&laquo;", "<<")
                        .trim();
            } else {
                return null;
            }
        }
    }
}
