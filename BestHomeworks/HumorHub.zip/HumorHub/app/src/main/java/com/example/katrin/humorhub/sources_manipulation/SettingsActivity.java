package com.example.katrin.humorhub.sources_manipulation;

import android.app.Application;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;

import com.example.katrin.humorhub.R;

import java.io.Serializable;
import java.util.List;
import java.util.Observable;
import java.util.Observer;

public class SettingsActivity extends AppCompatActivity implements Observer {

    private static final String SETTINGS_MODEL = "Settings Model";
    private SourcesRecycler sourcesRecycler;
    private SettingsModel model;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        if (savedInstanceState != null) {
            model = (SettingsModel) savedInstanceState.getSerializable(SETTINGS_MODEL);
        } else {
            model = new SettingsModel(getApplication());
        }
        RecyclerView sourcesRecyclerView = findViewById(R.id.sources_recycler);
        sourcesRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        sourcesRecycler = new SourcesRecycler(this, model.selectedSources);
        sourcesRecyclerView.setAdapter(sourcesRecycler);


        findViewById(R.id.cancel_button).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        findViewById(R.id.save_button).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                SelectedSourcesRegister.getInstance(getApplication()).saveSelectedList(model.selectedSources);
                finish();

            }
        });
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        if (model != null) {
            outState.putSerializable(SETTINGS_MODEL, model);
        }
    }

    @Override
    protected void onPause() {
        AvailableSourcesRegister.getInstance().deleteObserver(this);
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        AvailableSourcesRegister.getInstance().addObserver(this);
    }


    @Override
    public void update(Observable observable, Object o) {

        List<Source> availableSources = (List<Source>) o;
        sourcesRecycler.setAvailableSourcesList(availableSources);
    }

    private static class SettingsModel implements Serializable {

        List<Source> selectedSources;

        SettingsModel(Application context) {
            this.selectedSources = SelectedSourcesRegister.getInstance(context).getSelectedList();
        }
    }
}
