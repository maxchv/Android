package com.example.katrin.humorhub.jokes_manipulation;


import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.katrin.humorhub.R;

import java.util.List;

public class JokesRecycler extends RecyclerView.Adapter<JokesRecycler.ViewHolder> {

    private List<Joke> jokesList;
    private Context context;

    JokesRecycler(Context context) {
        this.context = context;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(context).inflate(R.layout.joke_item_view, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {

        Joke joke = jokesList.get(position);
        holder.text.setText(joke.text);
        holder.source.setText(joke.description);
    }

    @Override
    public int getItemCount() {
        return jokesList == null ? 0 : jokesList.size();
    }

    void setJokesList(List<Joke> jokesList) {
        this.jokesList = jokesList;
        notifyDataSetChanged();
    }

    class ViewHolder extends RecyclerView.ViewHolder {

        TextView text;
        TextView source;

        ViewHolder(View itemView) {
            super(itemView);

            text = itemView.findViewById(R.id.joke_text);
            source = itemView.findViewById(R.id.source_desc);
        }
    }
}
