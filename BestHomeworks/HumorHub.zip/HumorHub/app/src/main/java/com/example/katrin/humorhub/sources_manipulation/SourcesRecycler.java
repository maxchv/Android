package com.example.katrin.humorhub.sources_manipulation;


import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckedTextView;

import com.example.katrin.humorhub.R;

import java.util.List;

public class SourcesRecycler extends RecyclerView.Adapter<SourcesRecycler.ViewHolder> {

    private final List<Source> selectedSources;
    private final Context context;
    private List<Source> availableSourcesList;

    SourcesRecycler(Context context, List<Source> selectedSources) {
        this.context = context;
        this.selectedSources = selectedSources;
    }


    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.source_item_view, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, int position) {
        final Source source = availableSourcesList.get(position);
        holder.sourceView.setText(source.description);
        holder.sourceView.setChecked(selectedSources.contains(source));
        holder.sourceView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (holder.sourceView.isChecked()) {
                    holder.sourceView.setChecked(false);
                    selectedSources.remove(source);
                } else {
                    holder.sourceView.setChecked(true);
                    selectedSources.add(source);
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return availableSourcesList == null ? 0 : availableSourcesList.size();
    }

    void setAvailableSourcesList(List<Source> availableSourcesList) {
        this.availableSourcesList = availableSourcesList;
        notifyDataSetChanged();
    }

    class ViewHolder extends RecyclerView.ViewHolder {
        CheckedTextView sourceView;

        ViewHolder(View itemView) {
            super(itemView);
            sourceView = itemView.findViewById(R.id.source_checked);
        }
    }


}
