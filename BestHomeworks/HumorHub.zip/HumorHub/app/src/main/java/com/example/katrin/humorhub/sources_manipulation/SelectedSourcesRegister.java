package com.example.katrin.humorhub.sources_manipulation;

import android.annotation.SuppressLint;
import android.app.Application;
import android.content.Context;
import android.content.SharedPreferences;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.util.ArrayList;
import java.util.List;
import java.util.Observable;
import java.util.Observer;

public class SelectedSourcesRegister extends Observable {

    private static final String SELECTED_SOURCES = "Selected Sources";
    @SuppressLint("StaticFieldLeak")
    private static SelectedSourcesRegister instance;
    private Application context;

    private SelectedSourcesRegister(Application context) {
        this.context = context;

    }

    public static SelectedSourcesRegister getInstance(Application context) {
        if (instance == null) {
            instance = new SelectedSourcesRegister(context);
        }
        return instance;
    }

    @Override
    public synchronized void addObserver(Observer o) {
        super.addObserver(o);

        o.update(this, getSelectedList());
    }

    List<Source> getSelectedList() {

        SharedPreferences preferences = context.getSharedPreferences(SELECTED_SOURCES, Context.MODE_PRIVATE);
        String json = preferences.getString(SELECTED_SOURCES, null);
        if (json != null) {
            Gson gson = new Gson();
            return gson.fromJson(json, new TypeToken<List<Source>>() {
            }.getType());
        }
        return new ArrayList<>();
    }

    void saveSelectedList(List<Source> sources) {

        Gson gson = new Gson();
        String json = gson.toJson(sources);

        SharedPreferences preferences = context.getSharedPreferences(SELECTED_SOURCES, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putString(SELECTED_SOURCES, json);
        editor.apply();

        setChanged();
        notifyObservers(sources);

    }


}
