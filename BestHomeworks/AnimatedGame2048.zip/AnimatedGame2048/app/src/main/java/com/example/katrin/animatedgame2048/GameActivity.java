package com.example.katrin.animatedgame2048;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.support.v4.graphics.ColorUtils;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

public class GameActivity extends AppCompatActivity {

    private float swipeX1, swipeX2;
    private float swipeY1, swipeY2;
    private ViewGroup rootView;
    private TextView scoreView;

    private GameModel gameModel = GameModel.getInstance();
    private Button[][] gameField;
    private int activityHeight, activityWidth;
    private int fieldOffsetX, fieldOffsetY;
    private int gameFieldSize, fieldCellSize;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);

        scoreView = findViewById(R.id.score);
        rootView = findViewById(R.id.frameLayout);
        rootView.post(new Runnable() {
            @Override
            public void run() {
                activityHeight = rootView.getHeight();
                activityWidth = rootView.getWidth();

                RelativeLayout.LayoutParams lp = (RelativeLayout.LayoutParams) rootView.getLayoutParams();
                if (activityHeight == 0) {
                    activityHeight = lp.height = activityWidth;
                } else if (activityWidth == 0) {
                    activityWidth = lp.width = activityHeight;
                }
                rootView.setLayoutParams(lp);

                gameFieldSize = activityHeight < activityWidth ? activityHeight : activityWidth;    // min(activityHeight, activityWidth)
                fieldOffsetX = (activityWidth - gameFieldSize) / 2;
                fieldOffsetY = (activityHeight - gameFieldSize) / 2;
                fieldCellSize = gameFieldSize / gameModel.getSize();
                init();
                scoreView.setText(String.valueOf(gameModel.getScore()));
            }
        });

    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (!gameModel.animationIsFinished()) {
            return false;
        }
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                swipeX1 = event.getX();
                swipeY1 = event.getY();
                break;
            case MotionEvent.ACTION_UP:
                swipeX2 = event.getX();
                swipeY2 = event.getY();

                if (swipeX1 < swipeX2 && Math.abs(swipeX1 - swipeX2) > Math.abs(swipeY1 - swipeY2)) {
                    gameModel.swipeRight(this);
                }
                if (swipeX1 > swipeX2 && Math.abs(swipeX1 - swipeX2) > Math.abs(swipeY1 - swipeY2)) {
                    gameModel.swipeLeft(this);
                }
                if (swipeY1 < swipeY2 && Math.abs(swipeY1 - swipeY2) > Math.abs(swipeX1 - swipeX2)) {
                    gameModel.swipeDown(this);
                }
                if (swipeY1 > swipeY2 && Math.abs(swipeY1 - swipeY2) > Math.abs(swipeX1 - swipeX2)) {
                    gameModel.swipeUp(this);
                }
                break;
        }
        return false;
    }

    public void init() {
        final int size = gameModel.getSize();
        gameField = new Button[size][size];
        for (int row = 0; row < size; row++) {
            for (int col = 0; col < size; col++) {
                if (gameModel.getCell(row, col) != 0) {
                    createButton(row, col);
                }
            }
        }
    }

    public void createButton(int row, int col) {
        final Button button = gameField[row][col] = new Button(this);
        button.setClickable(false);
        GradientDrawable background = new GradientDrawable();
        background.setShape(GradientDrawable.RECTANGLE);
        background.setCornerRadius(30);
        button.setBackground(background);
        updateButton(row, col);

        button.setScaleX(0.1f);
        button.setScaleY(0.1f);
        button.animate().scaleY(0.9f).scaleX(0.9f).setDuration(GameModel.animationSpeed).start();

        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(fieldCellSize, fieldCellSize);
        lp.topMargin = fieldCellSize * row + fieldOffsetY;
        lp.leftMargin = fieldCellSize * col + fieldOffsetX;

        rootView.addView(button, lp);
    }

    public void animateButton(final int row1, final int col1, final int row2, final int col2, final boolean remove) {

        final Button button = gameField[row1][col1];
        if (remove) {
            gameField[row1][col1] = null;
            gameModel.notifyStartAnimation();
            button.animate().translationX((col2 - col1) * fieldCellSize)
                    .translationY((row2 - row1) * fieldCellSize).setDuration(GameModel.animationSpeed).withEndAction(new Runnable() {
                @Override
                public void run() {
                    rootView.removeView(button);
                    if (gameField[row2][col2] != null) {
                        updateButton(row2, col2);

                    }
                    gameModel.notifyEndAnimation(GameActivity.this);
                }
            }).start();

        } else {
            gameField[row2][col2] = button;
            gameField[row1][col1] = null;
            gameModel.notifyStartAnimation();
            button.animate().translationX((col2 - col1) * fieldCellSize)
                    .translationY((row2 - row1) * fieldCellSize).setDuration(GameModel.animationSpeed).withEndAction(new Runnable() {
                @Override
                public void run() {
                    updateButton(row2, col2);
                    FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) button.getLayoutParams();
                    lp.topMargin = fieldCellSize * row2 + fieldOffsetY;
                    lp.leftMargin = fieldCellSize * col2 + fieldOffsetX;
                    button.setLayoutParams(lp);
                    button.setTranslationX(0);
                    button.setTranslationY(0);
                    gameModel.notifyEndAnimation(GameActivity.this);
                }
            }).start();

        }

        scoreView.setText(String.valueOf(gameModel.getScore()));
    }

    private void updateButton(int row, int col) {
        final Button button = gameField[row][col];
        button.setText(String.valueOf(gameModel.getCell(row, col)));
        float ratio = (float) (Math.log(gameModel.getCell(row, col)) / Math.log(2) / 11);
        int color = ColorUtils.blendARGB(Color.WHITE, getResources().getColor(R.color.colorPrimary), ratio);
        GradientDrawable drawable = (GradientDrawable) button.getBackground();
        drawable.setColor(color);
        button.setBackground(drawable);
    }


    public void onNewGame(View view) {

        gameModel.createField(gameModel.getSize());
        recreate();
    }

    public AlertDialog showGameOverDialog() {

        final AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(this);
        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.game_over_dialog, null);
        dialogBuilder.setView(dialogView);
        Button tryAgain = dialogView.findViewById(R.id.but_again);
        Button quit = dialogView.findViewById(R.id.but_quit);

        tryAgain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gameModel.createField(gameModel.getSize());
                recreate();
                dialogBuilder.create().closeOptionsMenu();
            }
        });
        quit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(GameActivity.this, MainActivity.class);
                startActivity(intent);
                dialogBuilder.create().closeOptionsMenu();
            }
        });

        return dialogBuilder.create();
    }
}
