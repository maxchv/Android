package com.example.katrin.animatedgame2048;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

public class MainActivity extends AppCompatActivity  {


    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.size_four:
                GameModel.getInstance().createField(4);
                break;
            case R.id.size_five:
                GameModel.getInstance().createField(5);
                break;
            case R.id.size_six:
                GameModel.getInstance().createField(6);
                break;
            default:
                break;

        }
        Intent intent = new Intent(MainActivity.this, GameActivity.class);
        startActivity(intent);
    }



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}
