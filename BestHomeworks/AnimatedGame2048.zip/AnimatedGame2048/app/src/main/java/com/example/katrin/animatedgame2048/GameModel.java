package com.example.katrin.animatedgame2048;


import java.util.Random;

class GameModel {
    public static final int animationSpeed = 300;

    private static final GameModel ourInstance = new GameModel();
    private Random random = new Random();
    private int score = 0;
    private int size;
    private int[][] field;
    private int animationCounter = 0;

    private GameModel() {
    }

    static GameModel getInstance() {
        return ourInstance;
    }

    public int getScore() {
        return score;
    }

    public int getSize() {
        return size;
    }

    public void createField(int size) {
        score = 0;
        this.size = size;
        field = new int[size][size];
        insertRandomCell(null);
        insertRandomCell(null);
    }

    public void insertRandomCell(GameActivity activity) {
        if (!existsVacantCell()) {
            return;
        }

        int numberOfVacantCells = 0;
        for (int[] fc : field) {
            for (int c : fc) {
                if (c == 0) {
                    numberOfVacantCells++;
                }
            }
        }

        int numOfRandomCell = random.nextInt(numberOfVacantCells);
        int row;
        int col = 0;
        Outer:
        for (row = 0; row < size; row++) {
            for (col = 0; col < size; col++) {
                if (field[row][col] == 0) {
                    if (numOfRandomCell == 0) {
                        break Outer;
                    }
                    numOfRandomCell--;
                }
            }
        }

        int numProbability = random.nextInt(100);
        if (numProbability <= 10) {
            field[row][col] = 4;
        } else {
            field[row][col] = 2;
        }
        if (activity != null) {
            activity.createButton(row, col);
        }
    }

    private boolean existsVacantCell() {
        for (int[] fc : field) {
            for (int c : fc) {
                if (c == 0) {
                    return true;
                }
            }
        }
        return false;
    }

    public int getCell(int row, int col) {
        return field[row][col];
    }

    public void swipeUp(GameActivity activity) {
        for (int col = 0; col < size; col++) {
            for (int row = 0, priorEmpty = 0, lastMerged = -1; row < size; row++) {
                if (field[row][col] == 0) {
                    continue;
                }
                if (priorEmpty - 1 != lastMerged && field[row][col] == field[priorEmpty - 1][col]) {
                    score += field[row][col] * 2;
                    // кубик row летит в позицию priorEmpty - 1 и исчезает
                    field[priorEmpty - 1][col] = field[priorEmpty - 1][col] + field[row][col];
                    field[row][col] = 0;
                    lastMerged = priorEmpty - 1;
                    if (activity != null) {
                        activity.animateButton(row, col, priorEmpty - 1, col, true);
                    }
                    continue;
                } else if (row != priorEmpty) {
                    // кубик row летит в позицию priorEmpty
                    field[priorEmpty][col] = field[row][col];
                    field[row][col] = 0;
                    if (activity != null) {
                        activity.animateButton(row, col, priorEmpty, col, false);
                    }
                }
                priorEmpty++;
            }
        }
    }

    public void swipeDown(GameActivity activity) {
        for (int col = 0; col < size; col++) {
            for (int row = size - 1, priorEmpty = size - 1, lastMerged = size; row >= 0; row--) {
                if (field[row][col] == 0) {
                    continue;
                }
                if (priorEmpty + 1 != lastMerged && field[row][col] == field[priorEmpty + 1][col]) {
                    score += field[row][col] * 2;
                    // кубик row летит в позицию priorEmpty - 1 и исчезает
                    field[priorEmpty + 1][col] = field[priorEmpty + 1][col] + field[row][col];
                    field[row][col] = 0;
                    lastMerged = priorEmpty + 1;
                    if (activity != null) {
                        activity.animateButton(row, col, priorEmpty + 1, col, true);
                    }

                    continue;
                } else if (row != priorEmpty) {
                    // кубик row летит в позицию priorEmpty
                    field[priorEmpty][col] = field[row][col];
                    field[row][col] = 0;
                    if (activity != null) {
                        activity.animateButton(row, col, priorEmpty, col, false);
                    }
                }
                priorEmpty--;
            }
        }
    }

    public void swipeLeft(GameActivity activity) {
        for (int row = 0; row < size; row++) {
            for (int col = 0, priorEmpty = 0, lastMerged = -1; col < size; col++) {
                if (field[row][col] == 0) {
                    continue;
                }
                if (priorEmpty - 1 != lastMerged && field[row][col] == field[row][priorEmpty - 1]) {
                    score += field[row][col] * 2;
                    // кубик col летит в позицию priorEmpty - 1 и исчезает
                    field[row][priorEmpty - 1] = field[row][priorEmpty - 1] + field[row][col];
                    field[row][col] = 0;
                    lastMerged = priorEmpty - 1;
                    if (activity != null) {
                        activity.animateButton(row, col, row, priorEmpty - 1, true);
                    }
                    continue;
                } else if (col != priorEmpty) {
                    // кубик col летит в позицию priorEmpty
                    field[row][priorEmpty] = field[row][col];
                    field[row][col] = 0;
                    if (activity != null) {
                        activity.animateButton(row, col, row, priorEmpty, false);
                    }

                }
                priorEmpty++;
            }
        }
    }

    public void swipeRight(GameActivity activity) {
        for (int row = 0; row < size; row++) {
            for (int col = size - 1, priorEmpty = size - 1, lastMerged = size; col >= 0; col--) {
                if (field[row][col] == 0) {
                    continue;
                }
                if (priorEmpty + 1 != lastMerged && field[row][col] == field[row][priorEmpty + 1]) {
                    score += field[row][col] * 2;
                    // кубик col летит в позицию priorEmpty - 1 и исчезает
                    field[row][priorEmpty + 1] = field[row][priorEmpty + 1] + field[row][col];
                    field[row][col] = 0;
                    lastMerged = priorEmpty + 1;
                    if (activity != null) {
                        activity.animateButton(row, col, row, priorEmpty + 1, true);
                    }
                    continue;
                } else if (col != priorEmpty) {
                    // кубик col летит в позицию priorEmpty
                    field[row][priorEmpty] = field[row][col];
                    field[row][col] = 0;
                    if (activity != null) {
                        activity.animateButton(row, col, row, priorEmpty, false);
                    }
                }
                priorEmpty--;
            }
        }
    }

    public boolean animationIsFinished() {
        return animationCounter == 0;
    }

    public void notifyStartAnimation() {
        animationCounter++;
    }

    public void notifyEndAnimation(GameActivity activity) {
        animationCounter--;
        if (animationIsFinished()) {
            insertRandomCell(activity);
        }

        if (isGameOver()) {
            activity.showGameOverDialog().show();
        }

    }

    public boolean isGameOver() {

        int row;
        int col;
        for (row = 0; row < field.length; row++) {
            for (col = 0; col < field[0].length; col++) {
                if (field[row][col] == 0) {
                    return false;
                }
            }
        }

        for (row = 0; row < field.length; row++) {
            for (col = 0; col < field[0].length - 1; col++) {
                if (field[row][col] == field[row][col + 1]) {
                    return false;
                }
            }
        }
        for (col = 0; col < field.length; col++) {
            for (row = 0; row < field[0].length - 1; row++) {
                if (field[row][col] == field[row + 1][col]) {
                    return false;
                }
            }
        }

        return true;
    }
}
